/*
  # Add Blood System and Role-based Experience

  1. New Tables
    - `user_stats`
      - `user_id` (uuid, references profiles)
      - `experience` (integer)
      - `level` (integer)
      - `role_type` (enum: judge, observer, executor)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Changes
    - Add blood_points to questions table
    - Add functions for experience gain
    - Add level calculation function
*/

-- Create role type enum
CREATE TYPE user_role_type AS ENUM ('judge', 'observer', 'executor');

-- Create user_stats table
CREATE TABLE IF NOT EXISTS user_stats (
  user_id uuid PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  experience integer DEFAULT 0,
  level integer DEFAULT 1,
  role_type user_role_type DEFAULT 'observer',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add blood points to questions
ALTER TABLE questions
ADD COLUMN IF NOT EXISTS blood_points integer DEFAULT 10;

-- Enable RLS
ALTER TABLE user_stats ENABLE ROW LEVEL SECURITY;

-- Add policies
CREATE POLICY "Users can view stats"
  ON user_stats FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own stats"
  ON user_stats
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create function to calculate required experience for level
CREATE OR REPLACE FUNCTION get_level_exp_requirement(level_num integer)
RETURNS integer AS $$
BEGIN
  -- Experience formula: 100 * (level^1.5)
  RETURN FLOOR(100 * POWER(level_num::float, 1.5))::integer;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Create function to calculate blood points based on level
CREATE OR REPLACE FUNCTION calculate_blood_points(user_level integer)
RETURNS integer AS $$
BEGIN
  -- Base blood points (10) + 2 per level
  RETURN 10 + (2 * user_level);
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Create function to gain experience
CREATE OR REPLACE FUNCTION gain_experience(
  p_user_id uuid,
  p_amount integer
) RETURNS json AS $$
DECLARE
  v_current_exp integer;
  v_current_level integer;
  v_next_level_req integer;
  v_leveled_up boolean := false;
BEGIN
  -- Get current stats
  SELECT experience, level INTO v_current_exp, v_current_level
  FROM user_stats
  WHERE user_id = p_user_id;

  -- Add experience
  v_current_exp := v_current_exp + p_amount;

  -- Check for level up
  LOOP
    v_next_level_req := get_level_exp_requirement(v_current_level + 1);
    
    IF v_current_exp >= v_next_level_req THEN
      v_current_level := v_current_level + 1;
      v_leveled_up := true;
    ELSE
      EXIT;
    END IF;
  END LOOP;

  -- Update stats
  UPDATE user_stats
  SET 
    experience = v_current_exp,
    level = v_current_level,
    updated_at = now()
  WHERE user_id = p_user_id;

  -- Return updated stats
  RETURN json_build_object(
    'experience', v_current_exp,
    'level', v_current_level,
    'leveled_up', v_leveled_up
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to handle content interaction
CREATE OR REPLACE FUNCTION handle_content_interaction(
  p_user_id uuid,
  p_content_type text,
  p_content_id uuid,
  p_interaction_type text
) RETURNS json AS $$
DECLARE
  v_exp_gain integer := 0;
  v_user_role user_role_type;
  v_result json;
BEGIN
  -- Get user's role
  SELECT role_type INTO v_user_role
  FROM user_stats
  WHERE user_id = p_user_id;

  -- Calculate experience gain based on role and interaction
  CASE 
    WHEN v_user_role = 'judge' AND p_interaction_type IN ('upvote', 'comment', 'share') THEN
      -- Judge role: Consume blood points when interacting
      IF p_content_type = 'question' THEN
        UPDATE questions
        SET blood_points = blood_points - 1
        WHERE id = p_content_id AND blood_points > 0;
      END IF;
      v_exp_gain := 5;

    WHEN v_user_role = 'observer' AND p_interaction_type = 'view' THEN
      -- Observer role: Gain experience from viewing
      v_exp_gain := 1;

    WHEN v_user_role = 'executor' AND p_interaction_type = 'create' THEN
      -- Executor role: Gain more blood points for content
      IF p_content_type = 'question' THEN
        UPDATE questions
        SET blood_points = calculate_blood_points(
          (SELECT level FROM user_stats WHERE user_id = p_user_id)
        )
        WHERE id = p_content_id;
      END IF;
      v_exp_gain := 10;
  END CASE;

  -- Grant experience if applicable
  IF v_exp_gain > 0 THEN
    v_result := gain_experience(p_user_id, v_exp_gain);
  END IF;

  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to initialize user_stats
CREATE OR REPLACE FUNCTION initialize_user_stats()
RETURNS trigger AS $$
BEGIN
  INSERT INTO user_stats (user_id, role_type)
  VALUES (NEW.id, 'observer');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER create_user_stats
AFTER INSERT ON profiles
FOR EACH ROW
EXECUTE FUNCTION initialize_user_stats();