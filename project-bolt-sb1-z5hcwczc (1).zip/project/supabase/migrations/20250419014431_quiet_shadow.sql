/*
  # Add Community Features

  1. New Tables
    - `user_groups`
      - Groups/circles for users to join
    - `group_members`
      - Group membership tracking
    - `mentorship_programs`
      - Mentorship program details
    - `mentorship_applications`
      - Applications for mentorship
    - `achievements`
      - User achievements/badges
    - `user_achievements`
      - Track user earned achievements

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create user_groups table
CREATE TABLE IF NOT EXISTS user_groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  avatar_url text,
  created_by uuid REFERENCES profiles(id) ON DELETE SET NULL,
  is_official boolean DEFAULT false,
  member_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create group_members table
CREATE TABLE IF NOT EXISTS group_members (
  group_id uuid REFERENCES user_groups(id) ON DELETE CASCADE,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  role text DEFAULT 'member',
  joined_at timestamptz DEFAULT now(),
  PRIMARY KEY (group_id, user_id)
);

-- Create mentorship_programs table
CREATE TABLE IF NOT EXISTS mentorship_programs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  mentor_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  expertise text[] NOT NULL,
  max_mentees integer DEFAULT 3,
  duration_weeks integer NOT NULL,
  status text DEFAULT 'active',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create mentorship_applications table
CREATE TABLE IF NOT EXISTS mentorship_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  program_id uuid REFERENCES mentorship_programs(id) ON DELETE CASCADE,
  mentee_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  motivation text NOT NULL,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create achievements table
CREATE TABLE IF NOT EXISTS achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL,
  icon text NOT NULL,
  category text NOT NULL,
  points integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create user_achievements table
CREATE TABLE IF NOT EXISTS user_achievements (
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  achievement_id uuid REFERENCES achievements(id) ON DELETE CASCADE,
  earned_at timestamptz DEFAULT now(),
  PRIMARY KEY (user_id, achievement_id)
);

-- Enable RLS
ALTER TABLE user_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE group_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE mentorship_programs ENABLE ROW LEVEL SECURITY;
ALTER TABLE mentorship_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_achievements ENABLE ROW LEVEL SECURITY;

-- Add policies
CREATE POLICY "Anyone can view groups"
  ON user_groups FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create groups"
  ON user_groups FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Group creators can update groups"
  ON user_groups FOR UPDATE
  TO authenticated
  USING (auth.uid() = created_by);

CREATE POLICY "Anyone can view group members"
  ON group_members FOR SELECT
  USING (true);

CREATE POLICY "Users can manage own group membership"
  ON group_members
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Anyone can view mentorship programs"
  ON mentorship_programs FOR SELECT
  USING (true);

CREATE POLICY "Users can create mentorship programs"
  ON mentorship_programs FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = mentor_id);

CREATE POLICY "Mentors can update own programs"
  ON mentorship_programs FOR UPDATE
  TO authenticated
  USING (auth.uid() = mentor_id);

CREATE POLICY "Anyone can view applications"
  ON mentorship_applications FOR SELECT
  USING (true);

CREATE POLICY "Users can create applications"
  ON mentorship_applications FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = mentee_id);

CREATE POLICY "Anyone can view achievements"
  ON achievements FOR SELECT
  USING (true);

CREATE POLICY "Anyone can view user achievements"
  ON user_achievements FOR SELECT
  USING (true);

-- Insert default achievements
INSERT INTO achievements (name, description, icon, category, points) VALUES
  ('First Post', '发布第一个帖子', 'MessageSquare', 'participation', 10),
  ('Helpful Answer', '回答被标记为有帮助', 'ThumbsUp', 'contribution', 20),
  ('Popular Post', '帖子获得100个赞', 'TrendingUp', 'engagement', 30),
  ('Mentor', '成为导师', 'Users', 'mentorship', 50),
  ('Project Creator', '创建第一个项目', 'Rocket', 'creation', 25);

-- Create function to update group member count
CREATE OR REPLACE FUNCTION update_group_member_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE user_groups
    SET member_count = member_count + 1
    WHERE id = NEW.group_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE user_groups
    SET member_count = member_count - 1
    WHERE id = OLD.group_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for group member count
CREATE TRIGGER update_group_member_count
AFTER INSERT OR DELETE ON group_members
FOR EACH ROW
EXECUTE FUNCTION update_group_member_count();

-- Create function to check achievement eligibility
CREATE OR REPLACE FUNCTION check_achievement_eligibility()
RETURNS TRIGGER AS $$
BEGIN
  -- First Post Achievement
  IF TG_TABLE_NAME = 'forum_posts' AND TG_OP = 'INSERT' THEN
    IF NOT EXISTS (
      SELECT 1 FROM forum_posts 
      WHERE author_id = NEW.author_id 
      AND id != NEW.id
    ) THEN
      INSERT INTO user_achievements (user_id, achievement_id)
      SELECT NEW.author_id, id
      FROM achievements
      WHERE name = 'First Post'
      ON CONFLICT DO NOTHING;
    END IF;
  END IF;

  -- Project Creator Achievement
  IF TG_TABLE_NAME = 'innovation_projects' AND TG_OP = 'INSERT' THEN
    IF NOT EXISTS (
      SELECT 1 FROM innovation_projects
      WHERE author_id = NEW.author_id
      AND id != NEW.id
    ) THEN
      INSERT INTO user_achievements (user_id, achievement_id)
      SELECT NEW.author_id, id
      FROM achievements
      WHERE name = 'Project Creator'
      ON CONFLICT DO NOTHING;
    END IF;
  END IF;

  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for achievements
CREATE TRIGGER check_post_achievements
AFTER INSERT ON forum_posts
FOR EACH ROW
EXECUTE FUNCTION check_achievement_eligibility();

CREATE TRIGGER check_project_achievements
AFTER INSERT ON innovation_projects
FOR EACH ROW
EXECUTE FUNCTION check_achievement_eligibility();