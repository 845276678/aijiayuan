/*
  # Add example discussions

  1. Content
    - Add realistic discussions about current AI topics
    - Include questions and detailed answers
    - Add engagement metrics (views, votes)

  2. Topics
    - AI development trends
    - Technical implementations
    - Industry applications
*/

-- Add views_count column to questions table if it doesn't exist
DO $$ BEGIN
  ALTER TABLE questions ADD COLUMN views_count integer DEFAULT 0;
EXCEPTION
  WHEN duplicate_column THEN NULL;
END $$;

-- Insert example discussions and their answers
DO $$ 
DECLARE
  q1_id uuid;
  q2_id uuid;
  admin_id uuid;
BEGIN
  -- Get admin user id
  SELECT id INTO admin_id FROM profiles WHERE username = '845276678' LIMIT 1;

  -- Insert first question
  INSERT INTO questions (title, content, author_id, status, views_count, created_at)
  VALUES (
    '大模型微调有哪些实用技巧？',
    '最近在尝试对LLaMA2进行微调，想请教一下各位有经验的开发者：

1. 如何准备高质量的训练数据？
2. LoRA和QLoRA的选择考虑？
3. 如何避免过拟合问题？
4. 训练资源的优化策略？

希望能得到一些实践经验分享。',
    admin_id,
    'approved',
    156,
    NOW() - INTERVAL '6 hours'
  ) RETURNING id INTO q1_id;

  -- Insert first answer
  INSERT INTO answers (content, question_id, author_id, status, created_at)
  VALUES (
    '基于我们团队的实践经验，分享几点关键技巧：

1. 数据准备：
   - 确保数据质量，手动审核至少20%的样本
   - 构建多样化的数据集，覆盖不同场景
   - 注意数据的分布平衡
   - 实现数据增强和清洗流程

2. LoRA vs QLoRA：
   - 小数据集（<10k）建议使用LoRA
   - 大数据集考虑QLoRA，可以节省显存
   - rank建议从8开始调试
   - adapter_alpha参数对结果影响较大

3. 避免过拟合：
   - 实施早停策略
   - 使用交叉验证
   - 适当增加dropout
   - 监控验证集性能

4. 资源优化：
   - 使用gradient checkpointing
   - 实施混合精度训练
   - 批量大小与显存平衡
   - 使用gradient accumulation

补充建议：记录详细的实验日志，方便复现和优化。',
    q1_id,
    admin_id,
    'approved',
    NOW() - INTERVAL '5.5 hours'
  );

  -- Insert second question
  INSERT INTO questions (title, content, author_id, status, views_count, created_at)
  VALUES (
    'AI Agent开发中的prompt工程实践',
    '在开发AI Agent过程中，prompt设计显得尤为重要。我总结了一些经验，也想听听大家的见解：

1. 如何设计清晰的指令结构
2. 上下文管理的最佳实践
3. 如何处理复杂任务的拆解
4. 错误处理和恢复机制

欢迎讨论和分享！',
    admin_id,
    'approved',
    234,
    NOW() - INTERVAL '4 hours'
  ) RETURNING id INTO q2_id;

  -- Insert second answer
  INSERT INTO answers (content, question_id, author_id, status, created_at)
  VALUES (
    '作为AI Agent开发者，分享一些实践心得：

1. 指令结构设计：
   - 使用明确的角色定义
   - 设置清晰的目标和约束
   - 分层级组织指令
   - 包含示例和反例

2. 上下文管理：
   - 实现滑动窗口机制
   - 保留关键信息摘要
   - 设置优先级策略
   - 定期清理无关信息

3. 任务拆解：
   - 构建任务依赖图
   - 实现子任务调度
   - 设置检查点机制
   - 保持任务原子性

4. 错误处理：
   - 实现重试机制
   - 设置回退策略
   - 记录详细日志
   - 人工干预接口

这些经验来自实际项目，希望对大家有帮助！',
    q2_id,
    admin_id,
    'approved',
    NOW() - INTERVAL '3.5 hours'
  );

  -- Add votes for answers
  INSERT INTO votes (user_id, answer_id, value)
  SELECT 
    admin_id,
    id,
    1
  FROM answers
  WHERE created_at > NOW() - INTERVAL '6 hours';

END $$;