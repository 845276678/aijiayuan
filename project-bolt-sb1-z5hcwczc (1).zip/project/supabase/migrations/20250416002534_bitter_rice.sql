/*
  # Add follow system

  1. New Tables
    - `follows`
      - `follower_id` (uuid, references profiles)
      - `following_id` (uuid, references profiles)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on follows table
    - Add policies for authenticated users
*/

-- Create follows table
CREATE TABLE IF NOT EXISTS follows (
  follower_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  following_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  PRIMARY KEY (follower_id, following_id),
  -- Prevent self-following
  CONSTRAINT no_self_follow CHECK (follower_id != following_id)
);

-- Enable RLS
ALTER TABLE follows ENABLE ROW LEVEL SECURITY;

-- Add policies
CREATE POLICY "Users can view follows"
  ON follows FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can manage own follows"
  ON follows
  FOR ALL
  TO authenticated
  USING (auth.uid() = follower_id)
  WITH CHECK (auth.uid() = follower_id);

-- Create function to follow/unfollow users
CREATE OR REPLACE FUNCTION toggle_follow(target_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_follower_id uuid;
BEGIN
  -- Get current user ID
  v_follower_id := auth.uid();
  
  -- Check if already following
  IF EXISTS (
    SELECT 1 FROM follows
    WHERE follower_id = v_follower_id
    AND following_id = target_user_id
  ) THEN
    -- Unfollow
    DELETE FROM follows
    WHERE follower_id = v_follower_id
    AND following_id = target_user_id;
    RETURN false;
  ELSE
    -- Follow
    INSERT INTO follows (follower_id, following_id)
    VALUES (v_follower_id, target_user_id);
    
    -- Create notification for the target user
    INSERT INTO notifications (
      user_id,
      title,
      content,
      type
    ) VALUES (
      target_user_id,
      '新的关注者',
      (SELECT username FROM profiles WHERE id = v_follower_id) || ' 关注了你',
      'follow'
    );
    
    RETURN true;
  END IF;
END;
$$;

-- Create function to get follow stats
CREATE OR REPLACE FUNCTION get_follow_stats(user_id uuid)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  followers_count integer;
  following_count integer;
BEGIN
  SELECT COUNT(*) INTO followers_count
  FROM follows
  WHERE following_id = user_id;
  
  SELECT COUNT(*) INTO following_count
  FROM follows
  WHERE follower_id = user_id;
  
  RETURN json_build_object(
    'followers_count', followers_count,
    'following_count', following_count
  );
END;
$$;