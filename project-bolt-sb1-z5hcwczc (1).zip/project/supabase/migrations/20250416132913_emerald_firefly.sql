/*
  # Add Innovation Ideas Tables

  1. New Tables
    - `efficiency_ideas`
      - Ideas for using AI tools to improve work efficiency
    - `innovation_projects`
      - Implementable projects with team recruitment
    - `project_members`
      - Project team members
    - `idea_comments`
      - Comments on efficiency ideas

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create efficiency_ideas table
CREATE TABLE IF NOT EXISTS efficiency_ideas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  tool_name text NOT NULL,
  efficiency_gain text NOT NULL,
  author_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  status text DEFAULT 'pending',
  likes_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create innovation_projects table
CREATE TABLE IF NOT EXISTS innovation_projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  required_skills text[] NOT NULL,
  team_size integer NOT NULL,
  status text DEFAULT 'recruiting',
  author_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  likes_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_status CHECK (status IN ('recruiting', 'in_progress', 'completed'))
);

-- Create project_members table
CREATE TABLE IF NOT EXISTS project_members (
  project_id uuid REFERENCES innovation_projects(id) ON DELETE CASCADE,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  role text NOT NULL,
  joined_at timestamptz DEFAULT now(),
  PRIMARY KEY (project_id, user_id)
);

-- Create idea_comments table
CREATE TABLE IF NOT EXISTS idea_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  idea_id uuid REFERENCES efficiency_ideas(id) ON DELETE CASCADE,
  author_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE efficiency_ideas ENABLE ROW LEVEL SECURITY;
ALTER TABLE innovation_projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE idea_comments ENABLE ROW LEVEL SECURITY;

-- Add policies for efficiency_ideas
CREATE POLICY "Anyone can view approved ideas"
  ON efficiency_ideas FOR SELECT
  USING (status = 'approved');

CREATE POLICY "Users can create ideas"
  ON efficiency_ideas FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update own ideas"
  ON efficiency_ideas FOR UPDATE
  TO authenticated
  USING (auth.uid() = author_id);

-- Add policies for innovation_projects
CREATE POLICY "Anyone can view projects"
  ON innovation_projects FOR SELECT
  USING (true);

CREATE POLICY "Users can create projects"
  ON innovation_projects FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update own projects"
  ON innovation_projects FOR UPDATE
  TO authenticated
  USING (auth.uid() = author_id);

-- Add policies for project_members
CREATE POLICY "Anyone can view project members"
  ON project_members FOR SELECT
  USING (true);

CREATE POLICY "Project authors can manage members"
  ON project_members
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM innovation_projects
      WHERE id = project_id
      AND author_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM innovation_projects
      WHERE id = project_id
      AND author_id = auth.uid()
    )
  );

-- Add policies for idea_comments
CREATE POLICY "Anyone can view comments"
  ON idea_comments FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can comment"
  ON idea_comments FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update own comments"
  ON idea_comments FOR UPDATE
  TO authenticated
  USING (auth.uid() = author_id);

-- Create indexes
CREATE INDEX efficiency_ideas_author_id_idx ON efficiency_ideas(author_id);
CREATE INDEX efficiency_ideas_status_idx ON efficiency_ideas(status);
CREATE INDEX innovation_projects_author_id_idx ON innovation_projects(author_id);
CREATE INDEX innovation_projects_status_idx ON innovation_projects(status);
CREATE INDEX project_members_user_id_idx ON project_members(user_id);
CREATE INDEX idea_comments_idea_id_idx ON idea_comments(idea_id);
CREATE INDEX idea_comments_author_id_idx ON idea_comments(author_id);