/*
  # Add content reporting functionality

  1. New Tables
    - `reports`
      - `id` (uuid, primary key)
      - `content_type` (text) - 'question' or 'answer'
      - `content_id` (uuid) - ID of reported content
      - `reporter_id` (uuid) - User who reported
      - `reason` (text) - Report reason
      - `status` (text) - 'pending', 'resolved', 'dismissed'
      - `notes` (text) - Moderator notes
      - `created_at` (timestamptz)
      - `resolved_at` (timestamptz)
      - `resolved_by` (uuid) - Moderator who resolved

  2. Security
    - Enable RLS on `reports` table
    - Add policies for authenticated users to create reports
    - Add policies for moderators to manage reports

  3. Changes
    - Add report count to questions and answers
*/

-- Create reports table
CREATE TABLE IF NOT EXISTS reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content_type text NOT NULL,
  content_id uuid NOT NULL,
  reporter_id uuid NOT NULL REFERENCES users(id),
  reason text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  notes text,
  created_at timestamptz DEFAULT now(),
  resolved_at timestamptz,
  resolved_by uuid REFERENCES users(id),
  CONSTRAINT report_status_check CHECK (status IN ('pending', 'resolved', 'dismissed'))
);

-- Add report counts to content tables
ALTER TABLE questions
ADD COLUMN IF NOT EXISTS reports_count integer DEFAULT 0;

ALTER TABLE answers
ADD COLUMN IF NOT EXISTS reports_count integer DEFAULT 0;

-- Create indexes
CREATE INDEX IF NOT EXISTS reports_content_idx ON reports(content_type, content_id);
CREATE INDEX IF NOT EXISTS reports_status_idx ON reports(status);
CREATE INDEX IF NOT EXISTS reports_reporter_id_idx ON reports(reporter_id);

-- Enable RLS
ALTER TABLE reports ENABLE ROW LEVEL SECURITY;

-- Add policies
CREATE POLICY "Users can create reports"
  ON reports
  FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = reporter_id AND
    status = 'pending'
  );

CREATE POLICY "Users can view own reports"
  ON reports
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() = reporter_id OR
    (auth.jwt() ->> 'role' IN ('moderator', 'admin'))
  );

CREATE POLICY "Moderators can update reports"
  ON reports
  FOR UPDATE
  TO authenticated
  USING (auth.jwt() ->> 'role' IN ('moderator', 'admin'))
  WITH CHECK (auth.jwt() ->> 'role' IN ('moderator', 'admin'));

-- Create function to handle reporting
CREATE OR REPLACE FUNCTION report_content(
  p_content_type text,
  p_content_id uuid,
  p_reason text
) RETURNS uuid AS $$
DECLARE
  v_report_id uuid;
  v_table_name text;
BEGIN
  -- Insert report
  INSERT INTO reports (
    content_type,
    content_id,
    reporter_id,
    reason
  ) VALUES (
    p_content_type,
    p_content_id,
    auth.uid(),
    p_reason
  ) RETURNING id INTO v_report_id;
  
  -- Update report count
  v_table_name := CASE p_content_type
    WHEN 'question' THEN 'questions'
    WHEN 'answer' THEN 'answers'
    ELSE NULL
  END;
  
  EXECUTE format('
    UPDATE %I 
    SET reports_count = reports_count + 1
    WHERE id = $1
  ', v_table_name)
  USING p_content_id;
  
  RETURN v_report_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;