/*
  # Add AI Content Tables

  1. New Tables
    - `ai_content`
      - Common fields for all content types
      - Content type specific fields
      - Moderation fields
    - `ai_content_likes`
      - For tracking likes on AI content
    - `ai_content_comments`
      - For user comments on AI content

  2. Security
    - Enable RLS on all tables
    - Add policies for content access and management
*/

-- Create enum for AI content types
CREATE TYPE ai_content_type AS ENUM ('video', 'image', 'novel');

-- Create AI content table
CREATE TABLE IF NOT EXISTS ai_content (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  content_type ai_content_type NOT NULL,
  author_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  url text NOT NULL,
  thumbnail_url text,
  prompt text,
  tools_used text[],
  status text DEFAULT 'pending',
  likes_count integer DEFAULT 0,
  views_count integer DEFAULT 0,
  moderation_reason text,
  moderated_at timestamptz,
  moderated_by uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  -- Novel specific fields
  word_count integer,
  chapter_count integer,
  genre text,
  -- Video specific fields
  duration text,
  resolution text,
  -- Image specific fields
  width integer,
  height integer,
  style text
);

-- Create likes table
CREATE TABLE IF NOT EXISTS ai_content_likes (
  content_id uuid REFERENCES ai_content(id) ON DELETE CASCADE,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  PRIMARY KEY (content_id, user_id)
);

-- Create comments table
CREATE TABLE IF NOT EXISTS ai_content_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id uuid REFERENCES ai_content(id) ON DELETE CASCADE,
  author_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  comment text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE ai_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_content_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_content_comments ENABLE ROW LEVEL SECURITY;

-- Add policies for ai_content
CREATE POLICY "Anyone can view approved content"
  ON ai_content FOR SELECT
  USING (status = 'approved');

CREATE POLICY "Users can create content"
  ON ai_content FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update own content"
  ON ai_content FOR UPDATE
  TO authenticated
  USING (auth.uid() = author_id);

-- Add policies for likes
CREATE POLICY "Anyone can view likes"
  ON ai_content_likes FOR SELECT
  USING (true);

CREATE POLICY "Users can manage own likes"
  ON ai_content_likes
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Add policies for comments
CREATE POLICY "Anyone can view comments"
  ON ai_content_comments FOR SELECT
  USING (true);

CREATE POLICY "Users can create comments"
  ON ai_content_comments FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update own comments"
  ON ai_content_comments FOR UPDATE
  TO authenticated
  USING (auth.uid() = author_id);

-- Create indexes
CREATE INDEX ai_content_type_idx ON ai_content(content_type);
CREATE INDEX ai_content_author_id_idx ON ai_content(author_id);
CREATE INDEX ai_content_status_idx ON ai_content(status);
CREATE INDEX ai_content_created_at_idx ON ai_content(created_at);
CREATE INDEX ai_content_comments_content_id_idx ON ai_content_comments(content_id);
CREATE INDEX ai_content_comments_author_id_idx ON ai_content_comments(author_id);