/*
  # Add Sample Forum Content and Users

  1. Content
    - Add example users with different expertise
    - Add sample forum posts in different categories
    - Add realistic engagement metrics
    - Create user relationships (follows)

  2. Topics
    - AI development discussions
    - Project showcases
    - Technical questions
    - Industry news
*/

-- Insert sample users
DO $$ 
DECLARE
  user1_id uuid;
  user2_id uuid;
  user3_id uuid;
  tech_cat_id uuid;
  project_cat_id uuid;
  exp_cat_id uuid;
BEGIN
  -- Get category IDs
  SELECT id INTO tech_cat_id FROM forum_categories WHERE slug = 'tech' LIMIT 1;
  SELECT id INTO project_cat_id FROM forum_categories WHERE slug = 'projects' LIMIT 1;
  SELECT id INTO exp_cat_id FROM forum_categories WHERE slug = 'experience' LIMIT 1;

  -- Create sample users
  INSERT INTO profiles (id, username, avatar_url, created_at)
  VALUES 
    (gen_random_uuid(), 'AIExpert', 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5', NOW() - INTERVAL '30 days'),
    (gen_random_uuid(), 'MLEngineer', 'https://images.unsplash.com/photo-1599566150163-29194dcaad36', NOW() - INTERVAL '25 days'),
    (gen_random_uuid(), 'DeepLearner', 'https://images.unsplash.com/photo-1607746882042-944635dfe10e', NOW() - INTERVAL '20 days')
  RETURNING id INTO user1_id;

  -- Create some follows
  INSERT INTO follows (follower_id, following_id)
  SELECT 
    p1.id,
    p2.id
  FROM profiles p1
  CROSS JOIN profiles p2
  WHERE p1.id != p2.id
  LIMIT 5;

  -- Insert forum posts
  INSERT INTO forum_posts (title, content, category_id, author_id, views_count, replies_count, created_at) VALUES
  (
    'GPT-4 API优化实践分享',
    '基于最近的项目经验，分享一些GPT-4 API使用的优化技巧：

1. Token优化
- 合理设置上下文长度
- 使用高效的prompt模板
- 缓存常用响应

2. 成本控制
- 批量处理请求
- 实现重试机制
- 响应结果缓存

3. 性能提升
- 并行请求处理
- 流式响应优化
- 错误处理最佳实践

欢迎讨论交流！',
    tech_cat_id,
    user1_id,
    1256,
    8,
    NOW() - INTERVAL '5 days'
  ),
  (
    '开源项目：AI模型自动化部署平台',
    '很高兴分享我们的开源项目！

主要特性：
1. 支持多种模型格式
2. 自动化部署流程
3. 性能监控面板
4. 负载均衡管理

技术栈：
- 前端：React + TypeScript
- 后端：FastAPI + Celery
- 监控：Prometheus + Grafana

项目地址：[项目链接]

期待你的贡献！',
    project_cat_id,
    user1_id,
    892,
    12,
    NOW() - INTERVAL '3 days'
  ),
  (
    'AI创业经验分享：从0到1的产品成长之路',
    '作为一个AI创业者，分享我们团队的经验：

1. 产品定位
- 市场调研方法
- 用户需求分析
- MVP迭代策略

2. 技术选择
- 开源方案评估
- 自研与外包权衡
- 技术栈选型

3. 团队建设
- 招聘要点
- 技术培训
- 文化建设

4. 商业化
- 定价策略
- 获客渠道
- 用户转化

希望能给想创业的朋友一些启发。',
    exp_cat_id,
    user1_id,
    1567,
    15,
    NOW() - INTERVAL '1 day'
  );

  -- Insert forum replies
  INSERT INTO forum_replies (post_id, content, author_id, created_at)
  SELECT 
    p.id,
    CASE WHEN p.category_id = tech_cat_id THEN
      '非常实用的经验分享！补充几点：
      1. 使用tiktoken优化token计算
      2. 实现请求队列管理
      3. 设置超时重试策略
      
      这些都在生产环境经过验证，效果不错。'
    WHEN p.category_id = project_cat_id THEN
      '项目看起来很棒！几个建议：
      1. 考虑添加A/B测试功能
      2. 支持自动伸缩配置
      3. 添加成本分析报表
      
      如果需要帮助可以联系我。'
    ELSE
      '感谢分享！这些经验对创业者很有价值。
      建议可以多谈谈：
      1. 如何找到第一批种子用户
      2. 早期获客策略
      3. 用户反馈收集方法'
    END,
    user1_id,
    p.created_at + INTERVAL '2 hours'
  FROM forum_posts p;

  -- Update post stats
  UPDATE forum_posts
  SET replies_count = (
    SELECT COUNT(*)
    FROM forum_replies
    WHERE forum_replies.post_id = forum_posts.id
  ),
  last_reply_at = (
    SELECT MAX(created_at)
    FROM forum_replies
    WHERE forum_replies.post_id = forum_posts.id
  );

END $$;