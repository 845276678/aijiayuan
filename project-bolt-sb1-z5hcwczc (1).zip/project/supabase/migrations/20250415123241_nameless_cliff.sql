/*
  # Add User Roles and Permissions

  1. Changes
    - Add role enum type for user roles
    - Add role column to users table
    - Add permissions table
    - Add role_permissions table
    - Add policies for role-based access

  2. Security
    - Enable RLS on new tables
    - Add policies for role-based access control
*/

-- Create role enum
CREATE TYPE user_role AS ENUM ('user', 'moderator', 'admin');

-- Add role column to users table
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS role user_role DEFAULT 'user'::user_role;

-- Create permissions table
CREATE TABLE IF NOT EXISTS permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE permissions ENABLE ROW LEVEL SECURITY;

-- Create role_permissions table
CREATE TABLE IF NOT EXISTS role_permissions (
  role user_role NOT NULL,
  permission_id uuid NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  PRIMARY KEY (role, permission_id)
);

ALTER TABLE role_permissions ENABLE ROW LEVEL SECURITY;

-- Insert default permissions
INSERT INTO permissions (name, description) VALUES
  ('create_question', 'Can create new questions'),
  ('edit_question', 'Can edit questions'),
  ('delete_question', 'Can delete questions'),
  ('create_answer', 'Can create answers'),
  ('edit_answer', 'Can edit answers'),
  ('delete_answer', 'Can delete answers'),
  ('manage_tags', 'Can manage tags'),
  ('manage_categories', 'Can manage categories'),
  ('manage_users', 'Can manage users'),
  ('manage_roles', 'Can manage roles')
ON CONFLICT (name) DO NOTHING;

-- Assign default permissions to roles
INSERT INTO role_permissions (role, permission_id)
SELECT 'user', id FROM permissions WHERE name IN (
  'create_question',
  'create_answer'
);

INSERT INTO role_permissions (role, permission_id)
SELECT 'moderator', id FROM permissions WHERE name IN (
  'create_question',
  'edit_question',
  'create_answer',
  'edit_answer',
  'manage_tags',
  'manage_categories'
);

INSERT INTO role_permissions (role, permission_id)
SELECT 'admin', id FROM permissions;

-- Add policies
CREATE POLICY "Admins can manage permissions"
  ON permissions
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin')
  WITH CHECK (auth.jwt() ->> 'role' = 'admin');

CREATE POLICY "Admins can manage role permissions"
  ON role_permissions
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin')
  WITH CHECK (auth.jwt() ->> 'role' = 'admin');

-- Add function to check if user has permission
CREATE OR REPLACE FUNCTION has_permission(permission_name text)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1
    FROM users u
    JOIN role_permissions rp ON u.role = rp.role
    JOIN permissions p ON rp.permission_id = p.id
    WHERE u.id = auth.uid()
    AND p.name = permission_name
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;