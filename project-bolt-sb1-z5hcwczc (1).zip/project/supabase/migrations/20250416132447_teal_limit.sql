/*
  # Set Admin User

  1. Changes
    - Set admin role for specified user
    - Ensure user exists in profiles table
    - Create user preferences if not exists
*/

DO $$
DECLARE
  v_user_id uuid;
BEGIN
  -- Get user ID from auth.users
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = '845276678@qq.com';

  -- If user doesn't exist, we can't proceed
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'User with email 845276678@qq.com not found. Please ensure the user has registered.';
  END IF;

  -- Set admin role
  INSERT INTO user_roles (user_id, role)
  VALUES (v_user_id, 'admin')
  ON CONFLICT (user_id) 
  DO UPDATE SET 
    role = 'admin',
    updated_at = now();

  -- Ensure user has preferences
  INSERT INTO user_preferences (
    user_id,
    answer_notification,
    comment_notification,
    vote_notification,
    follow_notification,
    email_notification
  )
  VALUES (
    v_user_id,
    true,
    true,
    true,
    true,
    true
  )
  ON CONFLICT (user_id) DO NOTHING;

  -- Grant all permissions to admin
  INSERT INTO role_permissions (role, permission_id)
  SELECT 'admin', id 
  FROM permissions 
  ON CONFLICT (role, permission_id) DO NOTHING;

  RAISE NOTICE 'Successfully set user as admin';
END $$;