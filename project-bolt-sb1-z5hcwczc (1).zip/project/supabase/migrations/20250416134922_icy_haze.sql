/*
  # Add AI News System

  1. New Tables
    - `ai_news`
      - Basic news fields (id, title, content, etc.)
      - Source tracking
      - View and engagement metrics
      - Moderation support
    
    - `ai_news_comments`
      - Comment support for news articles

  2. Security
    - Enable RLS
    - Add appropriate policies
*/

-- Create AI news table
CREATE TABLE IF NOT EXISTS ai_news (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  summary text,
  source_url text,
  source_name text,
  image_url text,
  author_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  category text NOT NULL,
  status text DEFAULT 'pending',
  likes_count integer DEFAULT 0,
  views_count integer DEFAULT 0,
  is_featured boolean DEFAULT false,
  moderation_reason text,
  moderated_at timestamptz,
  moderated_by uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create news comments table
CREATE TABLE IF NOT EXISTS ai_news_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  news_id uuid REFERENCES ai_news(id) ON DELETE CASCADE,
  author_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE ai_news ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_news_comments ENABLE ROW LEVEL SECURITY;

-- Add policies for ai_news
CREATE POLICY "Anyone can view approved news"
  ON ai_news FOR SELECT
  USING (status = 'approved');

CREATE POLICY "Users can create news"
  ON ai_news FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update own news"
  ON ai_news FOR UPDATE
  TO authenticated
  USING (auth.uid() = author_id);

-- Add policies for comments
CREATE POLICY "Anyone can view news comments"
  ON ai_news_comments FOR SELECT
  USING (true);

CREATE POLICY "Users can create comments"
  ON ai_news_comments FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update own comments"
  ON ai_news_comments FOR UPDATE
  TO authenticated
  USING (auth.uid() = author_id);

-- Create indexes
CREATE INDEX ai_news_category_idx ON ai_news(category);
CREATE INDEX ai_news_author_id_idx ON ai_news(author_id);
CREATE INDEX ai_news_status_idx ON ai_news(status);
CREATE INDEX ai_news_created_at_idx ON ai_news(created_at);
CREATE INDEX ai_news_comments_news_id_idx ON ai_news_comments(news_id);
CREATE INDEX ai_news_comments_author_id_idx ON ai_news_comments(author_id);