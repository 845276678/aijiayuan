/*
  # Create Admin User

  1. Changes
    - Create admin user profile
    - Set admin role in user_roles table
    - Create user preferences
*/

-- Create admin user profile
DO $$
DECLARE
  v_user_id uuid;
BEGIN
  -- Get user ID from auth.users
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = '845276678@qq.com';

  -- If user doesn't exist, we can't proceed
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'User with email 845276678@qq.com not found. Please register the user first.';
  END IF;

  -- Create or update profile
  INSERT INTO public.profiles (id, username, avatar_url, created_at)
  VALUES (
    v_user_id,
    '845276678',
    'https://api.dicebear.com/7.x/initials/svg?seed=845276678',
    now()
  )
  ON CONFLICT (id) DO UPDATE
  SET 
    username = EXCLUDED.username,
    avatar_url = EXCLUDED.avatar_url;

  -- Set admin role
  INSERT INTO public.user_roles (user_id, role)
  VALUES (v_user_id, 'admin')
  ON CONFLICT (user_id) DO UPDATE
  SET role = 'admin';

  -- Create user preferences
  INSERT INTO public.user_preferences (
    user_id,
    answer_notification,
    comment_notification,
    vote_notification,
    follow_notification,
    email_notification
  )
  VALUES (
    v_user_id,
    true,
    true,
    true,
    true,
    true
  )
  ON CONFLICT (user_id) DO NOTHING;

END $$;