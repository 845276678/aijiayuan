/*
  # Add Forum System

  1. New Tables
    - `forum_categories`
      - Categories for organizing forum discussions
    - `forum_posts`
      - Forum discussion posts/threads
    - `forum_replies`
      - Replies to forum posts
    - `forum_reactions`
      - Reactions (likes, etc.) on posts and replies

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create forum_categories table
CREATE TABLE IF NOT EXISTS forum_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text,
  icon text,
  sort_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create forum_posts table
CREATE TABLE IF NOT EXISTS forum_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  category_id uuid REFERENCES forum_categories(id) ON DELETE CASCADE,
  author_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  status text DEFAULT 'published',
  is_pinned boolean DEFAULT false,
  views_count integer DEFAULT 0,
  replies_count integer DEFAULT 0,
  last_reply_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create forum_replies table
CREATE TABLE IF NOT EXISTS forum_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid REFERENCES forum_posts(id) ON DELETE CASCADE,
  content text NOT NULL,
  author_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  parent_id uuid REFERENCES forum_replies(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create forum_reactions table
CREATE TABLE IF NOT EXISTS forum_reactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  post_id uuid REFERENCES forum_posts(id) ON DELETE CASCADE,
  reply_id uuid REFERENCES forum_replies(id) ON DELETE CASCADE,
  reaction_type text NOT NULL,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT one_reaction CHECK (
    (post_id IS NOT NULL AND reply_id IS NULL) OR
    (post_id IS NULL AND reply_id IS NOT NULL)
  )
);

-- Enable RLS
ALTER TABLE forum_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_replies ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_reactions ENABLE ROW LEVEL SECURITY;

-- Add policies
CREATE POLICY "Anyone can view categories"
  ON forum_categories FOR SELECT
  USING (true);

CREATE POLICY "Anyone can view posts"
  ON forum_posts FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create posts"
  ON forum_posts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update own posts"
  ON forum_posts FOR UPDATE
  TO authenticated
  USING (auth.uid() = author_id);

CREATE POLICY "Anyone can view replies"
  ON forum_replies FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create replies"
  ON forum_replies FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update own replies"
  ON forum_replies FOR UPDATE
  TO authenticated
  USING (auth.uid() = author_id);

CREATE POLICY "Anyone can view reactions"
  ON forum_reactions FOR SELECT
  USING (true);

CREATE POLICY "Users can manage own reactions"
  ON forum_reactions
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes
CREATE INDEX forum_posts_category_id_idx ON forum_posts(category_id);
CREATE INDEX forum_posts_author_id_idx ON forum_posts(author_id);
CREATE INDEX forum_posts_created_at_idx ON forum_posts(created_at);
CREATE INDEX forum_replies_post_id_idx ON forum_replies(post_id);
CREATE INDEX forum_replies_author_id_idx ON forum_replies(author_id);
CREATE INDEX forum_reactions_post_id_idx ON forum_reactions(post_id);
CREATE INDEX forum_reactions_reply_id_idx ON forum_reactions(reply_id);

-- Insert default categories
INSERT INTO forum_categories (name, slug, description, icon, sort_order) VALUES
  ('技术讨论', 'tech', '讨论AI技术实现和最佳实践', 'Code', 1),
  ('项目展示', 'projects', '分享你的AI项目', 'Rocket', 2),
  ('经验分享', 'experience', '分享AI开发和应用经验', 'BookOpen', 3),
  ('求助问答', 'help', '寻求技术帮助', 'HelpCircle', 4),
  ('行业动态', 'news', '讨论AI行业最新动态', 'Newspaper', 5);

-- Create function to update post reply counts
CREATE OR REPLACE FUNCTION update_post_reply_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE forum_posts
    SET 
      replies_count = replies_count + 1,
      last_reply_at = NEW.created_at
    WHERE id = NEW.post_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE forum_posts
    SET replies_count = replies_count - 1
    WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for reply count
CREATE TRIGGER update_post_reply_count
AFTER INSERT OR DELETE ON forum_replies
FOR EACH ROW
EXECUTE FUNCTION update_post_reply_count();