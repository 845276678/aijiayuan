/*
  # Add sample content

  1. Changes
    - Add views_count column to questions
    - Insert sample tags
    - Insert sample questions and answers
    - Create question-tag relationships
*/

-- Add views_count column to questions table if it doesn't exist
DO $$ BEGIN
  ALTER TABLE questions ADD COLUMN views_count integer DEFAULT 0;
EXCEPTION
  WHEN duplicate_column THEN NULL;
END $$;

-- Create question_tags table if it doesn't exist
CREATE TABLE IF NOT EXISTS question_tags (
  question_id uuid REFERENCES questions(id) ON DELETE CASCADE,
  tag_id uuid REFERENCES tags(id) ON DELETE CASCADE,
  PRIMARY KEY (question_id, tag_id)
);

-- Insert sample tags
INSERT INTO tags (name, slug, description) VALUES
  ('ChatGPT', 'chatgpt', 'OpenAI的ChatGPT相关讨论'),
  ('机器学习', 'machine-learning', '机器学习基础与应用'),
  ('深度学习', 'deep-learning', '深度学习技术与框架'),
  ('AI应用', 'ai-applications', 'AI在各领域的实际应用'),
  ('编程技巧', 'programming-tips', '开发AI应用的编程技巧')
ON CONFLICT (name) DO NOTHING;

-- Insert sample questions and their answers in separate transactions
DO $$ 
DECLARE
  q1_id uuid;
  q2_id uuid;
  q3_id uuid;
  admin_id uuid;
BEGIN
  -- Get admin user id
  SELECT id INTO admin_id FROM profiles WHERE username = '845276678' LIMIT 1;

  -- Insert first question
  INSERT INTO questions (title, content, author_id, status, views_count, created_at)
  VALUES (
    'ChatGPT API 如何处理长文本输入？',
    '我在开发一个基于ChatGPT的文档分析工具，需要处理较长的文本输入。目前遇到了token限制的问题，想请教大家有什么好的解决方案？

具体问题：
1. 如何有效地分割长文本？
2. 如何保持上下文的连贯性？
3. 有什么成熟的最佳实践可以参考？

希望有经验的开发者能分享一下经验。',
    admin_id,
    'approved',
    128,
    NOW() - INTERVAL '2 days'
  ) RETURNING id INTO q1_id;

  -- Insert first answer
  INSERT INTO answers (content, question_id, author_id, status, created_at)
  VALUES (
    '基于实践经验，我建议以下解决方案：

1. 文本分割策略：
   - 使用滑动窗口方法，确保上下文重叠
   - 按段落或自然段落分割
   - 使用LangChain等工具辅助处理

2. 保持上下文：
   - 维护一个上下文缓存
   - 使用文本嵌入存储关键信息
   - 实现会话管理机制

3. 最佳实践：
   - 实现异步处理机制
   - 使用队列管理请求
   - 做好错误处理和重试机制

希望这些建议对你有帮助！',
    q1_id,
    admin_id,
    'approved',
    NOW() - INTERVAL '47 hours'
  );

  -- Insert second question
  INSERT INTO questions (title, content, author_id, status, views_count, created_at)
  VALUES (
    '深度学习模型部署到生产环境的最佳实践',
    '最近在做一个计算机视觉项目，需要将训练好的深度学习模型部署到生产环境。想听听大家在模型部署方面的经验。

主要关注以下几点：
1. 模型压缩和优化
2. 服务器端部署架构
3. 性能监控和调优
4. 成本控制

欢迎分享你们的实践经验！',
    admin_id,
    'approved',
    256,
    NOW() - INTERVAL '1 day'
  ) RETURNING id INTO q2_id;

  -- Insert second answer
  INSERT INTO answers (content, question_id, author_id, status, created_at)
  VALUES (
    '分享一下我们的部署经验：

1. 模型优化：
   - 使用TensorRT进行推理优化
   - 模型量化（INT8/FP16）
   - 模型剪枝和蒸馏

2. 部署架构：
   - 使用Docker容器化部署
   - Kubernetes进行编排
   - 实现A/B测试机制

3. 监控方案：
   - Prometheus + Grafana监控性能
   - 日志集中管理
   - 设置告警机制

4. 成本优化：
   - 自动扩缩容
   - GPU资源池管理
   - 批处理优化

这些方案在我们的生产环境运行良好，供参考。',
    q2_id,
    admin_id,
    'approved',
    NOW() - INTERVAL '23 hours'
  );

  -- Insert third question
  INSERT INTO questions (title, content, author_id, status, views_count, created_at)
  VALUES (
    '使用Stable Diffusion生成的图片能用于商业用途吗？',
    '我们团队正在开发一个AI辅助设计工具，计划使用Stable Diffusion生成图片。但对于生成图片的版权和商业使用存在一些疑问：

1. 生成的图片版权归属问题
2. 商业使用的法律风险
3. 如何避免侵权问题

希望了解下大家的看法和建议。',
    admin_id,
    'approved',
    512,
    NOW()
  ) RETURNING id INTO q3_id;

  -- Insert third answer
  INSERT INTO answers (content, question_id, author_id, status, created_at)
  VALUES (
    '关于AI生成图片的商业使用，建议：

1. 版权问题：
   - 查看模型的许可协议
   - 与法律顾问确认使用范围
   - 保留生成记录和参数

2. 风险控制：
   - 建立图片审核机制
   - 避免生成敏感内容
   - 制定清晰的使用规范

3. 合规建议：
   - 在产品中明确说明AI生成
   - 建立用户反馈机制
   - 保留人工审核环节

建议在正式商用前咨询法律专家，确保合规。',
    q3_id,
    admin_id,
    'approved',
    NOW() - INTERVAL '30 minutes'
  );

  -- Link questions with tags
  INSERT INTO question_tags (question_id, tag_id)
  SELECT 
    q.id,
    t.id
  FROM (VALUES (q1_id), (q2_id), (q3_id)) AS q(id)
  CROSS JOIN tags t
  WHERE t.name IN ('ChatGPT', 'AI应用', '编程技巧')
  LIMIT 3;

END $$;