/*
  # Add Content Moderation System

  1. Changes
    - Add status and moderation fields to questions and answers
    - Add moderation_logs table for tracking moderation actions
    - Add moderation policies
    - Add moderation helper functions

  2. Security
    - Enable RLS on new tables
    - Add policies for moderators and admins
*/

-- Add moderation fields to questions
ALTER TABLE questions
ADD COLUMN IF NOT EXISTS status text DEFAULT 'pending'::text,
ADD COLUMN IF NOT EXISTS moderation_reason text,
ADD COLUMN IF NOT EXISTS moderated_at timestamptz,
ADD COLUMN IF NOT EXISTS moderated_by uuid REFERENCES users(id);

-- Add moderation fields to answers
ALTER TABLE answers
ADD COLUMN IF NOT EXISTS status text DEFAULT 'pending'::text,
ADD COLUMN IF NOT EXISTS moderation_reason text,
ADD COLUMN IF NOT EXISTS moderated_at timestamptz,
ADD COLUMN IF NOT EXISTS moderated_by uuid REFERENCES users(id);

-- Create moderation_logs table
CREATE TABLE IF NOT EXISTS moderation_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content_type text NOT NULL, -- 'question' or 'answer'
  content_id uuid NOT NULL,
  action text NOT NULL, -- 'approve', 'reject', 'flag'
  reason text,
  moderator_id uuid NOT NULL REFERENCES users(id),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE moderation_logs ENABLE ROW LEVEL SECURITY;

-- Add status check constraint
ALTER TABLE questions
ADD CONSTRAINT questions_status_check
CHECK (status IN ('pending', 'approved', 'rejected', 'flagged'));

ALTER TABLE answers
ADD CONSTRAINT answers_status_check
CHECK (status IN ('pending', 'approved', 'rejected', 'flagged'));

-- Create indexes
CREATE INDEX IF NOT EXISTS questions_status_idx ON questions(status);
CREATE INDEX IF NOT EXISTS answers_status_idx ON answers(status);
CREATE INDEX IF NOT EXISTS moderation_logs_content_idx ON moderation_logs(content_type, content_id);

-- Add policies
CREATE POLICY "Moderators can view all content"
  ON questions
  FOR SELECT
  TO authenticated
  USING (
    (auth.jwt() ->> 'role' IN ('moderator', 'admin'))
    OR
    status = 'approved'
    OR
    auth.uid() = author_id
  );

CREATE POLICY "Moderators can view all answers"
  ON answers
  FOR SELECT
  TO authenticated
  USING (
    (auth.jwt() ->> 'role' IN ('moderator', 'admin'))
    OR
    status = 'approved'
    OR
    auth.uid() = author_id
  );

CREATE POLICY "Moderators can update content status"
  ON questions
  FOR UPDATE
  TO authenticated
  USING (auth.jwt() ->> 'role' IN ('moderator', 'admin'))
  WITH CHECK (auth.jwt() ->> 'role' IN ('moderator', 'admin'));

CREATE POLICY "Moderators can update answer status"
  ON answers
  FOR UPDATE
  TO authenticated
  USING (auth.jwt() ->> 'role' IN ('moderator', 'admin'))
  WITH CHECK (auth.jwt() ->> 'role' IN ('moderator', 'admin'));

CREATE POLICY "Moderators can view moderation logs"
  ON moderation_logs
  FOR SELECT
  TO authenticated
  USING (auth.jwt() ->> 'role' IN ('moderator', 'admin'));

CREATE POLICY "Moderators can create moderation logs"
  ON moderation_logs
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.jwt() ->> 'role' IN ('moderator', 'admin'));

-- Add moderation helper functions
CREATE OR REPLACE FUNCTION moderate_content(
  p_content_type text,
  p_content_id uuid,
  p_action text,
  p_reason text DEFAULT NULL
) RETURNS void AS $$
DECLARE
  v_table_name text;
  v_moderator_id uuid;
BEGIN
  -- Get moderator ID
  SELECT auth.uid() INTO v_moderator_id;
  
  -- Determine table name
  v_table_name := CASE p_content_type
    WHEN 'question' THEN 'questions'
    WHEN 'answer' THEN 'answers'
    ELSE NULL
  END;
  
  -- Update content status
  EXECUTE format('
    UPDATE %I 
    SET status = $1,
        moderation_reason = $2,
        moderated_at = now(),
        moderated_by = $3
    WHERE id = $4
  ', v_table_name)
  USING p_action, p_reason, v_moderator_id, p_content_id;
  
  -- Log moderation action
  INSERT INTO moderation_logs (
    content_type,
    content_id,
    action,
    reason,
    moderator_id
  ) VALUES (
    p_content_type,
    p_content_id,
    p_action,
    p_reason,
    v_moderator_id
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;