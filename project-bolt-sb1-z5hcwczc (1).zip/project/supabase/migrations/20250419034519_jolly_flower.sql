/*
  # Add Sample Forum Content

  1. Content
    - Add example forum posts in different categories
    - Add realistic replies and engagement metrics
    - Add sample tags and categories

  2. Topics
    - AI development discussions
    - Project showcases
    - Technical questions
    - Industry news
*/

-- Insert sample forum posts
DO $$ 
DECLARE
  tech_cat_id uuid;
  project_cat_id uuid;
  exp_cat_id uuid;
  help_cat_id uuid;
  news_cat_id uuid;
  admin_id uuid;
BEGIN
  -- Get category IDs
  SELECT id INTO tech_cat_id FROM forum_categories WHERE slug = 'tech' LIMIT 1;
  SELECT id INTO project_cat_id FROM forum_categories WHERE slug = 'projects' LIMIT 1;
  SELECT id INTO exp_cat_id FROM forum_categories WHERE slug = 'experience' LIMIT 1;
  SELECT id INTO help_cat_id FROM forum_categories WHERE slug = 'help' LIMIT 1;
  SELECT id INTO news_cat_id FROM forum_categories WHERE slug = 'news' LIMIT 1;

  -- Get admin user id
  SELECT id INTO admin_id FROM profiles WHERE username = '845276678' LIMIT 1;

  -- Insert posts in technical discussion category
  INSERT INTO forum_posts (title, content, category_id, author_id, views_count, created_at) VALUES
  (
    'LLaMA 2微调实践经验分享',
    '最近在做LLaMA 2的微调项目，分享一些实践经验：

1. 数据准备
- 高质量训练数据的重要性
- 数据清洗和预处理流程
- 数据增强技巧

2. 训练策略
- LoRA vs QLoRA的选择
- 超参数调优经验
- 训练资源优化

3. 常见问题及解决方案
- 显存优化
- 过拟合处理
- 推理加速

欢迎交流讨论！',
    tech_cat_id,
    admin_id,
    256,
    NOW() - INTERVAL '2 days'
  ),
  (
    'Stable Diffusion模型部署优化',
    '分享一下我们在部署SD模型时的优化经验：

1. 模型优化
- 模型量化
- 模型剪枝
- KD知识蒸馏

2. 推理优化
- TensorRT加速
- 批处理优化
- 动态批处理

3. 部署架构
- 负载均衡
- 缓存策略
- 监控告警

希望对大家有帮助！',
    tech_cat_id,
    admin_id,
    189,
    NOW() - INTERVAL '1 day'
  );

  -- Insert posts in project showcase category
  INSERT INTO forum_posts (title, content, category_id, author_id, views_count, created_at) VALUES
  (
    '开源项目：AI辅助代码生成工具',
    '很高兴向大家介绍我的开源项目：

项目特点：
1. 基于最新LLM模型
2. 支持多种编程语言
3. VSCode插件集成
4. 本地部署方案

技术栈：
- 前端：React + TypeScript
- 后端：FastAPI
- 模型：LLaMA 2

项目地址：[GitHub链接]

欢迎大家使用和贡献！',
    project_cat_id,
    admin_id,
    342,
    NOW() - INTERVAL '12 hours'
  );

  -- Insert posts in experience sharing category
  INSERT INTO forum_posts (title, content, category_id, author_id, views_count, created_at) VALUES
  (
    'AI创业一年的经验总结',
    '作为一个AI创业者，分享一下这一年的经验：

1. 产品定位
- 找准市场痛点
- MVP快速迭代
- 用户反馈收集

2. 技术选择
- 开源vs自研
- 成本控制
- 技术债务管理

3. 团队建设
- 招聘策略
- 技术培训
- 文化建设

4. 商业化
- 定价策略
- 获客渠道
- 用户留存

希望能给想创业的朋友一些参考。',
    exp_cat_id,
    admin_id,
    567,
    NOW() - INTERVAL '5 hours'
  );

  -- Insert posts in help category
  INSERT INTO forum_posts (title, content, category_id, author_id, views_count, created_at) VALUES
  (
    'ChatGPT API 使用问题求助',
    '在使用ChatGPT API时遇到几个问题，希望有经验的朋友帮忙：

1. 如何有效管理token限制？
2. 流式响应如何处理断连？
3. 上下文管理最佳实践？
4. 费用优化建议？

已尝试的方案：
[详细描述]

报错信息：
[错误日志]

感谢帮助！',
    help_cat_id,
    admin_id,
    234,
    NOW() - INTERVAL '3 hours'
  );

  -- Insert posts in news category
  INSERT INTO forum_posts (title, content, category_id, author_id, views_count, created_at) VALUES
  (
    'GPT-5最新消息汇总',
    '整理了一下关于GPT-5的最新消息：

1. 技术突破
- 多模态能力增强
- 推理能力提升
- 知识更新机制

2. 应用场景
- 代码生成升级
- 多语言优化
- 创意创作增强

3. 行业影响
- 商业模式变革
- 就业市场影响
- 教育领域应用

信息来源：[官方博客]、[研究论文]等',
    news_cat_id,
    admin_id,
    789,
    NOW()
  );

  -- Add some replies
  INSERT INTO forum_replies (post_id, content, author_id, created_at)
  SELECT 
    posts.id,
    '感谢分享！这些经验非常有价值。我也补充几点：

1. [补充内容]
2. [实践经验]
3. [注意事项]

希望能帮助到其他人。',
    admin_id,
    posts.created_at + INTERVAL '1 hour'
  FROM forum_posts posts
  WHERE posts.created_at < NOW() - INTERVAL '1 hour';

  -- Update reply counts
  UPDATE forum_posts
  SET replies_count = (
    SELECT COUNT(*)
    FROM forum_replies
    WHERE forum_replies.post_id = forum_posts.id
  );

END $$;