import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import morgan from 'morgan';
import { createServer } from 'http';
import { createClient } from '@supabase/supabase-js';
import { logger } from './utils/logger.js';
import { setupCronJobs } from './cron/index.js';
import { apiRouter } from './routes/api.js';
import { errorHandler } from './middleware/errorHandler.js';
import { limiter } from './middleware/rateLimit.js';
import { initializeWebSocket } from './utils/websocket.js';
import config from './config/production.js';
import './utils/loadEnv.js';

const app = express();
const httpServer = createServer(app);
const isProd = process.env.NODE_ENV === 'production';

// Initialize WebSocket server
const wss = initializeWebSocket(httpServer);

// Initialize Supabase client
export const supabase = createClient(
  config.supabaseUrl,
  config.supabaseKey
);

// Middleware
app.use(cors(config.cors));
app.use(helmet());
app.use(compression());
app.use(express.json());
app.use(limiter);

// Logging
if (isProd) {
  app.use(morgan('combined', { stream: { write: message => logger.info(message.trim()) } }));
} else {
  app.use(morgan('dev'));
}

// Health check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV
  });
});

// Routes
app.use('/api', apiRouter);

// Error handling
app.use(errorHandler);

// Start server
const server = httpServer.listen(config.port, () => {
  logger.info(`Server running in ${process.env.NODE_ENV} mode on port ${config.port}`);
  setupCronJobs();
});

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('SIGTERM signal received. Closing server...');
  server.close(() => {
    logger.info('Server closed');
    process.exit(0);
  });
});