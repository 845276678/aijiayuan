import NodeCache from 'node-cache';

// Create cache instance with 5 minute TTL by default
export const cache = new NodeCache({
  stdTTL: 300,
  checkperiod: 60,
});

export function cacheMiddleware(key, ttl = 300) {
  return (req, res, next) => {
    const cacheKey = typeof key === 'function' ? key(req) : key;
    const cachedData = cache.get(cacheKey);

    if (cachedData) {
      return res.json(cachedData);
    }

    const originalJson = res.json;
    res.json = function(data) {
      cache.set(cacheKey, data, ttl);
      originalJson.call(this, data);
    };

    next();
  };
}