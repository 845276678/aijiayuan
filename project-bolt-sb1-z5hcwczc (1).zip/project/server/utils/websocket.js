import { WebSocketServer } from 'ws';
import { logger } from './logger.js';

let wss;

export function initializeWebSocket(server) {
  wss = new WebSocketServer({ server });

  wss.on('connection', (ws) => {
    ws.isAlive = true;

    ws.on('pong', () => {
      ws.isAlive = true;
    });

    ws.on('error', (error) => {
      logger.error('WebSocket error:', error);
    });
  });

  // Heartbeat to clean up dead connections
  const interval = setInterval(() => {
    wss.clients.forEach((ws) => {
      if (ws.isAlive === false) {
        return ws.terminate();
      }
      ws.isAlive = false;
      ws.ping();
    });
  }, 30000);

  wss.on('close', () => {
    clearInterval(interval);
  });

  return wss;
}

export function broadcastToModerators(data) {
  if (!wss) return;

  wss.clients.forEach((client) => {
    if (client.moderator && client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(data));
    }
  });
}