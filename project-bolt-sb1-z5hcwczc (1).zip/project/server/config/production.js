export default {
  port: process.env.PORT || 3000,
  supabaseUrl: process.env.VITE_SUPABASE_URL,
  supabaseKey: process.env.VITE_SUPABASE_SERVICE_ROLE_KEY,
  cors: {
    origin: process.env.FRONTEND_URL || 'https://aijiayuan.top',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true,
  },
  rateLimit: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // limit each IP to 100 requests per windowMs
  },
  security: {
    bcryptRounds: 12,
    jwtSecret: process.env.JWT_SECRET,
    jwtExpiry: '7d',
  },
};