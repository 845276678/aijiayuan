import cron from 'node-cron';
import { supabase } from '../index.js';
import { logger } from '../utils/logger.js';

// Clean up old notifications
async function cleanupNotifications() {
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  try {
    const { error } = await supabase
      .from('notifications')
      .delete()
      .lt('created_at', thirtyDaysAgo.toISOString())
      .eq('read', true);

    if (error) throw error;
    logger.info('Cleaned up old notifications');
  } catch (error) {
    logger.error('Error cleaning up notifications:', error);
  }
}

// Update trending scores
async function updateTrendingScores() {
  try {
    const { error } = await supabase.rpc('update_trending_scores');
    if (error) throw error;
    logger.info('Updated trending scores');
  } catch (error) {
    logger.error('Error updating trending scores:', error);
  }
}

// Check for inactive users
async function checkInactiveUsers() {
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  try {
    const { data, error } = await supabase
      .from('users')
      .select('id, email')
      .lt('last_activity', thirtyDaysAgo.toISOString());

    if (error) throw error;

    // Log inactive users for review
    if (data?.length > 0) {
      logger.info('Found inactive users:', {
        count: data.length,
        users: data.map(u => u.id)
      });
    }
  } catch (error) {
    logger.error('Error checking inactive users:', error);
  }
}

export function setupCronJobs() {
  // Run daily at 3 AM
  cron.schedule('0 3 * * *', cleanupNotifications);

  // Run every hour
  cron.schedule('0 * * * *', updateTrendingScores);

  // Run weekly on Sunday at 4 AM
  cron.schedule('0 4 * * 0', checkInactiveUsers);

  logger.info('Cron jobs scheduled');
}