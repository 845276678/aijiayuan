import { Router } from 'express';
import { supabase } from '../index.js';
import { logger } from '../utils/logger.js';

export const apiRouter = Router();

// Health check endpoint
apiRouter.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Get system stats
apiRouter.get('/stats', async (req, res, next) => {
  try {
    const [
      { count: usersCount } = { count: 0 },
      { count: questionsCount } = { count: 0 },
      { count: answersCount } = { count: 0 }
    ] = await Promise.all([
      supabase.from('users').select('*', { count: 'exact', head: true }),
      supabase.from('questions').select('*', { count: 'exact', head: true }),
      supabase.from('answers').select('*', { count: 'exact', head: true })
    ]);

    res.json({
      users: usersCount,
      questions: questionsCount,
      answers: answersCount,
      lastChecked: new Date().toISOString()
    });
  } catch (error) {
    next(error);
  }
});

// Get moderation queue stats
apiRouter.get('/moderation/stats', async (req, res, next) => {
  try {
    const [
      { count: pendingQuestions } = { count: 0 },
      { count: pendingAnswers } = { count: 0 },
      { count: pendingReports } = { count: 0 }
    ] = await Promise.all([
      supabase.from('questions').select('*', { count: 'exact', head: true }).eq('status', 'pending'),
      supabase.from('answers').select('*', { count: 'exact', head: true }).eq('status', 'pending'),
      supabase.from('reports').select('*', { count: 'exact', head: true }).eq('status', 'pending')
    ]);

    res.json({
      pendingQuestions,
      pendingAnswers,
      pendingReports,
      lastChecked: new Date().toISOString()
    });
  } catch (error) {
    next(error);
  }
});

// Get user activity stats
apiRouter.get('/activity', async (req, res, next) => {
  try {
    const { days = 7 } = req.query;
    const date = new Date();
    date.setDate(date.getDate() - parseInt(days));

    const [questions, answers, votes] = await Promise.all([
      supabase.from('questions')
        .select('created_at')
        .gte('created_at', date.toISOString())
        .order('created_at'),
      supabase.from('answers')
        .select('created_at')
        .gte('created_at', date.toISOString())
        .order('created_at'),
      supabase.from('votes')
        .select('created_at')
        .gte('created_at', date.toISOString())
        .order('created_at')
    ]);

    res.json({
      questions: questions.data || [],
      answers: answers.data || [],
      votes: votes.data || [],
      period: {
        start: date.toISOString(),
        end: new Date().toISOString()
      }
    });
  } catch (error) {
    next(error);
  }
});