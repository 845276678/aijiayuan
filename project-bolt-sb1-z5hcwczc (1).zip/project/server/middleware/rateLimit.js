import rateLimit from 'express-rate-limit';
import config from '../config/production.js';

export const limiter = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.max,
  message: {
    error: {
      message: 'Too many requests, please try again later.',
      status: 429,
    },
  },
});