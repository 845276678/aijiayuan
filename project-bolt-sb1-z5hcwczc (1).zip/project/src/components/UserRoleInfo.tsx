import React from 'react';
import { Gavel, Eye, Zap } from 'lucide-react';
import type { UserRoleType } from '../lib/types';

interface UserRoleInfoProps {
  roleType: UserRoleType;
  experience: number;
  level: number;
}

const roleIcons = {
  judge: Gavel,
  observer: Eye,
  executor: Zap
};

const roleDescriptions = {
  judge: '可以消耗血条为内容投票，每次评判获得更多经验',
  observer: '通过浏览内容获得经验值',
  executor: '发布内容时获得更多血条，创作获得更多经验'
};

export default function UserRoleInfo({ roleType, experience, level }: UserRoleInfoProps) {
  const Icon = roleIcons[roleType];
  const nextLevelExp = Math.floor(100 * Math.pow(level + 1, 1.5));
  const progress = (experience / nextLevelExp) * 100;

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm">
      <div className="flex items-center mb-4">
        <Icon className="h-6 w-6 text-primary-500" />
        <div className="ml-3">
          <h3 className="font-semibold capitalize">{roleType}</h3>
          <p className="text-sm text-gray-600">{roleDescriptions[roleType]}</p>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span>等级 {level}</span>
          <span>{experience} / {nextLevelExp} XP</span>
        </div>
        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
          <div 
            className="h-full bg-primary-500 transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </div>
  );
}