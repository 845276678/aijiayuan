import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface TagSelectorProps {
  selectedTags: string[];
  onChange: (tags: string[]) => void;
}

export default function TagSelector({ selectedTags, onChange }: TagSelectorProps) {
  const [tags, setTags] = useState<string[]>([]);
  const [input, setInput] = useState('');
  const [suggestions, setSuggestions] = useState<string[]>([]);

  useEffect(() => {
    loadTags();
  }, []);

  async function loadTags() {
    const { data } = await supabase
      .from('tags')
      .select('name')
      .order('name');
    
    if (data) {
      setTags(data.map(tag => tag.name));
    }
  }

  function handleInputChange(e: React.ChangeEvent<HTMLInputElement>) {
    const value = e.target.value;
    setInput(value);

    if (value.trim()) {
      const filtered = tags.filter(tag => 
        tag.toLowerCase().includes(value.toLowerCase()) &&
        !selectedTags.includes(tag)
      );
      setSuggestions(filtered);
    } else {
      setSuggestions([]);
    }
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Enter' && input.trim()) {
      e.preventDefault();
      addTag(input.trim());
    }
  }

  function addTag(tag: string) {
    if (!selectedTags.includes(tag)) {
      const newTags = [...selectedTags, tag];
      onChange(newTags);
    }
    setInput('');
    setSuggestions([]);
  }

  function removeTag(tag: string) {
    const newTags = selectedTags.filter(t => t !== tag);
    onChange(newTags);
  }

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-2 mb-2">
        {selectedTags.map(tag => (
          <span
            key={tag}
            className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-sm flex items-center"
          >
            {tag}
            <button
              onClick={() => removeTag(tag)}
              className="ml-2 hover:text-blue-800"
            >
              <X className="h-4 w-4" />
            </button>
          </span>
        ))}
      </div>
      <div className="relative">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          placeholder="输入标签并按回车添加"
          className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        {suggestions.length > 0 && (
          <div className="absolute z-10 w-full mt-1 bg-white border rounded-lg shadow-lg">
            {suggestions.map(tag => (
              <button
                key={tag}
                onClick={() => addTag(tag)}
                className="block w-full px-4 py-2 text-left hover:bg-gray-50"
              >
                {tag}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}