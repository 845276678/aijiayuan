import React from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, ThumbsUp, Eye, Clock } from 'lucide-react';
import type { ForumPost as ForumPostType } from '../lib/types';

interface ForumPostProps {
  post: ForumPostType;
}

export default function ForumPost({ post }: ForumPostProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden">
      <div className="p-6">
        <div className="flex items-center gap-2 mb-3">
          <Link
            to={`/forum/category/${post.category?.slug}`}
            className="text-sm font-medium px-3 py-1 rounded-full bg-blue-50 text-blue-600 hover:bg-blue-100"
          >
            {post.category?.name}
          </Link>
          {post.is_pinned && (
            <span className="text-sm font-medium px-3 py-1 rounded-full bg-orange-50 text-orange-600">
              置顶
            </span>
          )}
        </div>

        <Link to={`/forum/post/${post.id}`}>
          <h3 className="text-xl font-semibold text-gray-900 hover:text-blue-600 mb-2">
            {post.title}
          </h3>
        </Link>

        <p className="text-gray-600 mb-4 line-clamp-2">
          {post.content.replace(/<[^>]*>/g, '').substring(0, 200)}...
        </p>

        <div className="flex items-center justify-between text-sm text-gray-500">
          <div className="flex items-center gap-4">
            <Link to={`/user/${post.author?.username}`} className="flex items-center hover:text-gray-700">
              <img
                src={post.author?.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${post.author?.username}`}
                alt={post.author?.username}
                className="w-6 h-6 rounded-full mr-2"
              />
              <span>{post.author?.username}</span>
            </Link>
            <span className="flex items-center">
              <Clock className="w-4 h-4 mr-1" />
              {new Date(post.created_at).toLocaleDateString()}
            </span>
          </div>
          
          <div className="flex items-center gap-4">
            <span className="flex items-center">
              <Eye className="w-4 h-4 mr-1" />
              {post.views_count}
            </span>
            <span className="flex items-center">
              <MessageSquare className="w-4 h-4 mr-1" />
              {post.replies_count}
            </span>
            <span className="flex items-center">
              <ThumbsUp className="w-4 h-4 mr-1" />
              {post.likes_count || 0}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}