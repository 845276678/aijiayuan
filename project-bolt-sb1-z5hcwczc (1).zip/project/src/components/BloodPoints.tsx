import React from 'react';
import { Heart } from 'lucide-react';

interface BloodPointsProps {
  points: number;
  maxPoints: number;
}

export default function BloodPoints({ points, maxPoints }: BloodPointsProps) {
  const percentage = (points / maxPoints) * 100;
  
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center">
          <Heart className={`h-5 w-5 ${points > 0 ? 'text-red-500' : 'text-gray-400'}`} fill="currentColor" />
          <span className="ml-2 font-medium">血条</span>
        </div>
        <span className="text-sm text-gray-600">{points}/{maxPoints}</span>
      </div>
      <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
        <div 
          className="h-full bg-red-500 transition-all duration-300"
          style={{ width: `${percentage}%` }}
        />
      </div>
      <p className="mt-2 text-sm text-gray-600">
        用于评判内容和互动，每天自动恢复
      </p>
    </div>
  );
}