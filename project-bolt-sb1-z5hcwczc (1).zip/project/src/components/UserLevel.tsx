import React from 'react';
import { Award, Eye, Gavel, Zap } from 'lucide-react';
import type { UserRoleType } from '../lib/supabase';

interface UserLevelProps {
  level: number;
  experience: number;
  nextLevelExp: number;
  roleType: UserRoleType;
}

export default function UserLevel({ level, experience, nextLevelExp, roleType }: UserLevelProps) {
  const percentage = (experience / nextLevelExp) * 100;
  
  const roleIcons = {
    judge: Gavel,
    observer: Eye,
    executor: Zap
  };

  const RoleIcon = roleIcons[roleType];

  return (
    <div className="flex items-center space-x-4">
      <div className="flex items-center">
        <Award className="h-6 w-6 text-yellow-500 mr-2" />
        <span className="text-lg font-semibold">Lv.{level}</span>
      </div>
      
      <div className="flex-1">
        <div className="flex items-center justify-between text-sm text-gray-600 mb-1">
          <span>{experience} XP</span>
          <span>{nextLevelExp} XP</span>
        </div>
        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
          <div 
            className="h-full bg-blue-500 transition-all duration-300"
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>

      <div className="flex items-center bg-gray-100 px-3 py-1 rounded-full">
        <RoleIcon className="h-4 w-4 mr-2" />
        <span className="text-sm font-medium capitalize">{roleType}</span>
      </div>
    </div>
  );
}