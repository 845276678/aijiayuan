import React, { useState, useEffect } from 'react';
import { UserPlus, UserMinus } from 'lucide-react';
import { toggleFollow, checkIsFollowing } from '../lib/supabase';

interface FollowButtonProps {
  userId: string;
  onFollowChange?: (isFollowing: boolean) => void;
}

export default function FollowButton({ userId, onFollowChange }: FollowButtonProps) {
  const [isFollowing, setIsFollowing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    loadFollowStatus();
  }, [userId]);

  async function loadFollowStatus() {
    const following = await checkIsFollowing(userId);
    setIsFollowing(following);
  }

  async function handleToggleFollow() {
    setIsLoading(true);
    try {
      const result = await toggleFollow(userId);
      setIsFollowing(result);
      onFollowChange?.(result);
    } catch (error) {
      console.error('Error toggling follow:', error);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <button
      onClick={handleToggleFollow}
      disabled={isLoading}
      className={`flex items-center px-4 py-2 rounded-full transition-colors ${
        isFollowing
          ? 'bg-gray-100 text-gray-800 hover:bg-gray-200'
          : 'bg-blue-500 text-white hover:bg-blue-600'
      } ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
      {isFollowing ? (
        <>
          <UserMinus className="h-4 w-4 mr-2" />
          取消关注
        </>
      ) : (
        <>
          <UserPlus className="h-4 w-4 mr-2" />
          关注
        </>
      )}
    </button>
  );
}