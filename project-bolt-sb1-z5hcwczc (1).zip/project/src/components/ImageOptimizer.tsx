import React from 'react';
import LazyImage from './LazyImage';

interface ImageOptimizerProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  quality?: number;
}

export default function ImageOptimizer({ 
  src, 
  alt,
  width,
  height,
  quality = 75,
  ...props 
}: ImageOptimizerProps) {
  // Optimize Unsplash images
  if (src.includes('images.unsplash.com')) {
    const url = new URL(src);
    if (width) url.searchParams.set('w', width.toString());
    if (height) url.searchParams.set('h', height.toString());
    url.searchParams.set('q', quality.toString());
    url.searchParams.set('auto', 'format');
    src = url.toString();
  }

  return (
    <LazyImage
      src={src}
      alt={alt}
      width={width}
      height={height}
      loading="lazy"
      decoding="async"
      {...props}
    />
  );
}