import { analytics } from './analytics';

interface PerformanceMetrics {
  fcp: number | null;
  lcp: number | null;
  fid: number | null;
  cls: number | null;
  ttfb: number | null;
}

class PerformanceMonitor {
  private metrics: PerformanceMetrics = {
    fcp: null,
    lcp: null,
    fid: null,
    cls: null,
    ttfb: null
  };

  constructor() {
    this.initObservers();
  }

  private initObservers() {
    // First Contentful Paint
    const paintObserver = new PerformanceObserver((entries) => {
      for (const entry of entries.getEntries()) {
        if (entry.name === 'first-contentful-paint') {
          this.metrics.fcp = entry.startTime;
          analytics.trackPerformance('FCP', entry.startTime);
        }
      }
    });
    paintObserver.observe({ entryTypes: ['paint'] });

    // Largest Contentful Paint
    const lcpObserver = new PerformanceObserver((entries) => {
      const lastEntry = entries.getEntries().pop();
      if (lastEntry) {
        this.metrics.lcp = lastEntry.startTime;
        analytics.trackPerformance('LCP', lastEntry.startTime);
      }
    });
    lcpObserver.observe({ entryTypes: ['largest-contentful-paint'] });

    // First Input Delay
    const fidObserver = new PerformanceObserver((entries) => {
      for (const entry of entries.getEntries()) {
        if (entry.name === 'first-input') {
          this.metrics.fid = entry.processingStart - entry.startTime;
          analytics.trackPerformance('FID', this.metrics.fid);
        }
      }
    });
    fidObserver.observe({ entryTypes: ['first-input'] });

    // Cumulative Layout Shift
    const clsObserver = new PerformanceObserver((entries) => {
      let clsValue = 0;
      for (const entry of entries.getEntries()) {
        if (!entry.hadRecentInput) {
          clsValue += (entry as any).value;
        }
      }
      this.metrics.cls = clsValue;
      analytics.trackPerformance('CLS', clsValue);
    });
    clsObserver.observe({ entryTypes: ['layout-shift'] });

    // Time to First Byte
    const navigationObserver = new PerformanceObserver((entries) => {
      const navigationEntry = entries.getEntries()[0];
      this.metrics.ttfb = navigationEntry.responseStart - navigationEntry.requestStart;
      analytics.trackPerformance('TTFB', this.metrics.ttfb);
    });
    navigationObserver.observe({ entryTypes: ['navigation'] });
  }

  getMetrics(): PerformanceMetrics {
    return { ...this.metrics };
  }
}

export const performanceMonitor = new PerformanceMonitor();