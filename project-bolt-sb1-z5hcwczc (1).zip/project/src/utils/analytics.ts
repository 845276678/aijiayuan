export interface AnalyticsEvent {
  category: string;
  action: string;
  label?: string;
  value?: number;
}

class Analytics {
  private static instance: Analytics;
  
  private constructor() {}

  static getInstance(): Analytics {
    if (!Analytics.instance) {
      Analytics.instance = new Analytics();
    }
    return Analytics.instance;
  }

  trackEvent({ category, action, label, value }: AnalyticsEvent) {
    // 这里可以集成实际的分析服务
    console.log('Track Event:', { category, action, label, value });
  }

  trackError(error: Error, context?: string) {
    // 这里可以集成错误上报服务
    console.error('Error:', error, 'Context:', context);
  }

  trackPerformance(metric: string, value: number) {
    // 这里可以集成性能监控服务
    console.log('Performance:', metric, value);
  }
}

export const analytics = Analytics.getInstance();