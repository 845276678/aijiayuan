import * as Sentry from "@sentry/browser";
import { BrowserTracing } from "@sentry/tracing";
import { analytics } from './analytics';
import { getCLS, getFID, getLCP } from 'web-vitals';

export function initializeMonitoring() {
  // Initialize Sentry
  Sentry.init({
    dsn: import.meta.env.VITE_SENTRY_DSN,
    integrations: [new BrowserTracing()],
    tracesSampleRate: 1.0,
    environment: import.meta.env.MODE,
  });

  // Track web vitals
  getCLS(metric => {
    analytics.trackPerformance('CLS', metric.value);
  });

  getFID(metric => {
    analytics.trackPerformance('FID', metric.value);
  });

  getLCP(metric => {
    analytics.trackPerformance('LCP', metric.value);
  });
}

export function trackError(error: Error, context?: string) {
  Sentry.captureException(error, {
    extra: { context }
  });
  analytics.trackError(error, context);
}

export function trackPageView(path: string) {
  analytics.trackEvent({
    category: 'Navigation',
    action: 'Page View',
    label: path
  });
}