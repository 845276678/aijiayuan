import { cache } from './cache';

export async function prefetchData(url: string): Promise<any> {
  const cachedData = cache.get(url);
  if (cachedData) return cachedData;

  try {
    const response = await fetch(url);
    const data = await response.json();
    cache.set(url, data);
    return data;
  } catch (error) {
    console.error('Error prefetching data:', error);
    throw error;
  }
}

export function prefetchImage(url: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve();
    img.onerror = reject;
    img.src = url;
  });
}

export function prefetchComponent(path: string): Promise<void> {
  return import(/* @vite-ignore */ path).catch(error => {
    console.error('Error prefetching component:', error);
  });
}