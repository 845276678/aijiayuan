import { trackError } from '../utils/monitoring';

export async function errorMiddleware(error: Error, req: Request) {
  // Track the error
  trackError(error, `${req.method} ${req.url}`);

  // Return appropriate error response
  return new Response(
    JSON.stringify({
      error: {
        message: process.env.NODE_ENV === 'production' 
          ? '服务器出现错误，请稍后重试'
          : error.message
      }
    }),
    {
      status: 500,
      headers: {
        'Content-Type': 'application/json'
      }
    }
  );
}