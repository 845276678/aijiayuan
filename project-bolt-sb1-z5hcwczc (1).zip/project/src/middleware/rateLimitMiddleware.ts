const RATE_LIMIT_WINDOW = 60000; // 1 minute
const MAX_REQUESTS = 100;

const requestCounts = new Map<string, { count: number; timestamp: number }>();

export function rateLimitMiddleware(req: Request): Response | null {
  const clientIP = req.headers.get('x-forwarded-for') || 'unknown';
  const now = Date.now();

  // Get or initialize request count for this IP
  let record = requestCounts.get(clientIP);
  if (!record || (now - record.timestamp) > RATE_LIMIT_WINDOW) {
    record = { count: 0, timestamp: now };
  }

  // Check if rate limit exceeded
  if (record.count >= MAX_REQUESTS) {
    return new Response(
      JSON.stringify({
        error: {
          message: '请求过于频繁，请稍后重试'
        }
      }),
      {
        status: 429,
        headers: {
          'Content-Type': 'application/json',
          'Retry-After': '60'
        }
      }
    );
  }

  // Update request count
  record.count++;
  requestCounts.set(clientIP, record);

  return null;
}