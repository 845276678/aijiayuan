import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, AlertTriangle, Shield, MessageSquare } from 'lucide-react';

export default function ForumRules() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pt-28">
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center mb-6">
          <Shield className="h-8 w-8 text-blue-500 mr-3" />
          <h1 className="text-2xl font-bold">社区规则和指南</h1>
        </div>

        <p className="text-gray-700 mb-6">
          欢迎来到AI家园论坛！为了维护一个积极、专业的技术交流社区，请遵守以下规则：
        </p>

        <div className="space-y-8">
          <div className="bg-blue-50 p-6 rounded-lg">
            <div className="flex items-center mb-4">
              <BookOpen className="h-6 w-6 text-blue-500 mr-2" />
              <h2 className="text-xl font-semibold">基本准则</h2>
            </div>
            <ul className="space-y-2 text-gray-600">
              <li className="flex items-center">
                <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                保持友善和专业的交流态度
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                避免人身攻击、骚扰或歧视行为
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                不发布不当、冒犯性或违法内容
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                尊重知识产权，标明引用来源
              </li>
            </ul>
          </div>

          <div className="bg-green-50 p-6 rounded-lg">
            <div className="flex items-center mb-4">
              <MessageSquare className="h-6 w-6 text-green-500 mr-2" />
              <h2 className="text-xl font-semibold">内容规范</h2>
            </div>
            <ul className="space-y-2 text-gray-600">
              <li className="flex items-center">
                <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                发布与AI技术相关的高质量内容
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                提供准确、可靠的技术信息
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                清晰标注原创内容或他人作品
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                避免重复发布相同内容
              </li>
              <li className="flex items-center">
                <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                使用适当的格式和排版
              </li>
            </ul>
          </div>

          <div className="bg-red-50 p-6 rounded-lg">
            <div className="flex items-center mb-4">
              <AlertTriangle className="h-6 w-6 text-red-500 mr-2" />
              <h2 className="text-xl font-semibold">违规处理</h2>
            </div>
            <div className="text-gray-600">
              <p className="mb-4">违反社区规则可能导致以下处理：</p>
              <ul className="space-y-2">
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-red-500 rounded-full mr-2"></span>
                  警告提醒
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-red-500 rounded-full mr-2"></span>
                  暂时禁言
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-red-500 rounded-full mr-2"></span>
                  永久封禁
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-8 p-4 bg-gray-50 rounded-lg">
          <p className="text-gray-600">
            如有任何问题或建议，请联系社区管理员。我们致力于维护一个友善、专业的技术交流环境。
          </p>
        </div>

        <div className="mt-6">
          <Link
            to="/forum"
            className="inline-flex items-center text-blue-500 hover:text-blue-600"
          >
            <MessageSquare className="h-5 w-5 mr-2" />
            返回论坛
          </Link>
        </div>
      </div>
    </div>
  );
}