import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import type { Profile } from '../lib/supabase';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/Tabs';

export default function Settings() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [username, setUsername] = useState('');
  const [bio, setBio] = useState('');
  const [website, setWebsite] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [notificationPreferences, setNotificationPreferences] = useState({
    answer_notification: true,
    comment_notification: true,
    vote_notification: true,
    follow_notification: true,
    email_notification: true,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    loadProfile();
  }, []);

  async function loadProfile() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate('/login');
        return;
      }

      const { data: profile } = await supabase
        .from('profiles')
        .select('*, notification_preferences:user_preferences(*)')
        .eq('id', user.id)
        .single();

      if (profile) {
        setProfile(profile);
        setUsername(profile.username);
        setBio(profile.bio || '');
        setWebsite(profile.website || '');
        setAvatarUrl(profile.avatar_url || '');
        if (profile.notification_preferences) {
          setNotificationPreferences(profile.notification_preferences);
        }
      }
    } catch (error) {
      console.error('Error loading profile:', error);
    } finally {
      setIsLoading(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!profile) return;

    setIsSaving(true);
    setError('');
    setSuccessMessage('');

    try {
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          username,
          bio,
          website,
          avatar_url: avatarUrl,
          updated_at: new Date().toISOString()
        })
        .eq('id', profile.id);

      if (profileError) throw profileError;

      const { error: preferencesError } = await supabase
        .from('user_preferences')
        .upsert({
          user_id: profile.id,
          ...notificationPreferences
        });

      if (preferencesError) throw preferencesError;

      setSuccessMessage('设置已更新');
    } catch (err) {
      console.error('Error updating settings:', err);
      setError('更新设置时出错');
    } finally {
      setIsSaving(false);
    }
  }

  async function handleAvatarUpload(e: React.ChangeEvent<HTMLInputElement>) {
    if (!e.target.files || !e.target.files[0]) return;

    const file = e.target.files[0];
    const fileExt = file.name.split('.').pop();
    const filePath = `${profile?.id}/${Math.random()}.${fileExt}`;

    try {
      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      setAvatarUrl(publicUrl);
    } catch (error) {
      console.error('Error uploading avatar:', error);
    }
  }

  if (isLoading) {
    return <div className="text-center py-8">Loading...</div>;
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-8 pt-28">
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="bg-gray-50 border-b px-6">
            <TabsTrigger value="profile">个人资料</TabsTrigger>
            <TabsTrigger value="notifications">通知设置</TabsTrigger>
          </TabsList>

          <div className="p-6">
            <TabsContent value="profile">
              <form onSubmit={handleSubmit}>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      头像
                    </label>
                    <div className="flex items-center">
                      <img
                        src={avatarUrl || `https://api.dicebear.com/7.x/initials/svg?seed=${username}`}
                        alt="Avatar"
                        className="w-20 h-20 rounded-full"
                      />
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleAvatarUpload}
                        className="ml-4"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-2">
                      用户名
                    </label>
                    <input
                      type="text"
                      id="username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label htmlFor="bio" className="block text-sm font-medium text-gray-700 mb-2">
                      个人简介
                    </label>
                    <textarea
                      id="bio"
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      rows={3}
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label htmlFor="website" className="block text-sm font-medium text-gray-700 mb-2">
                      个人网站
                    </label>
                    <input
                      type="url"
                      id="website"
                      value={website}
                      onChange={(e) => setWebsite(e.target.value)}
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </form>
            </TabsContent>

            <TabsContent value="notifications">
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">通知偏好设置</h3>
                  <div className="space-y-4">
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={notificationPreferences.answer_notification}
                        onChange={(e) => setNotificationPreferences(prev => ({
                          ...prev,
                          answer_notification: e.target.checked
                        }))}
                        className="h-4 w-4 text-blue-500 rounded border-gray-300 focus:ring-blue-500"
                      />
                      <span className="ml-3">当有人回答我的问题时通知我</span>
                    </label>

                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={notificationPreferences.comment_notification}
                        onChange={(e) => setNotificationPreferences(prev => ({
                          ...prev,
                          comment_notification: e.target.checked
                        }))}
                        className="h-4 w-4 text-blue-500 rounded border-gray-300 focus:ring-blue-500"
                      />
                      <span className="ml-3">当有人评论我的回答时通知我</span>
                    </label>

                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={notificationPreferences.vote_notification}
                        onChange={(e) => setNotificationPreferences(prev => ({
                          ...prev,
                          vote_notification: e.target.checked
                        }))}
                        className="h-4 w-4 text-blue-500 rounded border-gray-300 focus:ring-blue-500"
                      />
                      <span className="ml-3">当有人赞同我的回答时通知我</span>
                    </label>

                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={notificationPreferences.follow_notification}
                        onChange={(e) => setNotificationPreferences(prev => ({
                          ...prev,
                          follow_notification: e.target.checked
                        }))}
                        className="h-4 w-4 text-blue-500 rounded border-gray-300 focus:ring-blue-500"
                      />
                      <span className="ml-3">当有人关注我时通知我</span>
                    </label>

                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={notificationPreferences.email_notification}
                        onChange={(e) => setNotificationPreferences(prev => ({
                          ...prev,
                          email_notification: e.target.checked
                        }))}
                        className="h-4 w-4 text-blue-500 rounded border-gray-300 focus:ring-blue-500"
                      />
                      <span className="ml-3">同时发送邮件通知</span>
                    </label>
                  </div>
                </div>
              </div>
            </TabsContent>

            {error && (
              <div className="mt-4 p-4 text-red-700 bg-red-100 rounded-lg">
                {error}
              </div>
            )}

            {successMessage && (
              <div className="mt-4 p-4 text-green-700 bg-green-100 rounded-lg">
                {successMessage}
              </div>
            )}

            <div className="mt-6 flex justify-end">
              <button
                type="submit"
                onClick={handleSubmit}
                disabled={isSaving}
                className={`px-6 py-2 rounded-full text-white ${
                  isSaving
                    ? 'bg-blue-400 cursor-not-allowed'
                    : 'bg-blue-500 hover:bg-blue-600'
                }`}
              >
                {isSaving ? '保存中...' : '保存更改'}
              </button>
            </div>
          </div>
        </Tabs>
      </div>
    </div>
  );
}