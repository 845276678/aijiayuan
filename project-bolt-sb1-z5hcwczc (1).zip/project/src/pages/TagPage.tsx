import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import type { Tag, Question } from '../lib/supabase';

export default function TagPage() {
  const { slug } = useParams<{ slug: string }>();
  const [tag, setTag] = useState<Tag | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (slug) {
      loadTagAndQuestions();
    }
  }, [slug]);

  async function loadTagAndQuestions() {
    setIsLoading(true);
    try {
      // Load tag
      const { data: tagData } = await supabase
        .from('tags')
        .select('*')
        .eq('slug', slug)
        .single();

      if (tagData) {
        setTag(tagData);

        // Load questions with this tag
        const { data: questionsData } = await supabase
          .from('questions')
          .select(`
            *,
            author:profiles(*),
            answers(count)
          `)
          .eq('tags.tag_id', tagData.id)
          .order('created_at', { ascending: false });

        setQuestions(questionsData || []);
      }
    } catch (error) {
      console.error('Error loading tag and questions:', error);
    } finally {
      setIsLoading(false);
    }
  }

  if (isLoading) {
    return <div className="text-center py-8">Loading...</div>;
  }

  if (!tag) {
    return <div className="text-center py-8">Tag not found</div>;
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pt-28">
      <div className="bg-white rounded-lg p-6 shadow-sm mb-8">
        <h1 className="text-3xl font-bold text-gray-900">#{tag.name}</h1>
        <p className="mt-2 text-gray-600">{tag.description}</p>
        <div className="mt-4 text-sm text-gray-500">
          {questions.length} 个相关问题
        </div>
      </div>

      <div className="space-y-4">
        {questions.map(question => (
          <Link key={question.id} to={`/question/${question.id}`}>
            <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <h2 className="text-xl font-semibold text-gray-900">{question.title}</h2>
              <p className="mt-2 text-gray-600">{question.content.substring(0, 200)}...</p>
              <div className="mt-4 flex items-center text-sm text-gray-500">
                <img
                  src={question.author?.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${question.author?.username}`}
                  alt={question.author?.username}
                  className="w-6 h-6 rounded-full"
                />
                <span className="ml-2">{question.author?.username}</span>
                <span className="mx-2">•</span>
                <span>{new Date(question.created_at).toLocaleDateString()}</span>
                <span className="mx-2">•</span>
                <span>{question.answers?.length || 0} 回答</span>
              </div>
            </div>
          </Link>
        ))}

        {questions.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            暂无相关问题
          </div>
        )}
      </div>
    </div>
  );
}