import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Settings, LogOut, User, Bell, BookOpen, MessageSquare } from 'lucide-react';
import type { Profile } from '../lib/types';
import UserRoleInfo from '../components/UserRoleInfo';
import BloodPoints from '../components/BloodPoints';

export default function UserCenter() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [userStats, setUserStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProfile();
  }, []);

  async function loadProfile() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate('/auth');
        return;
      }

      const [profileData, statsData] = await Promise.all([
        supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single(),
        supabase
          .from('user_stats')
          .select('*')
          .eq('user_id', user.id)
          .single()
      ]);

      setProfile(profileData.data);
      setUserStats(statsData.data);
    } catch (error) {
      console.error('Error loading profile:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    navigate('/auth');
  }

  if (loading) {
    return <div className="text-center py-8">加载中...</div>;
  }

  if (!profile || !userStats) {
    return <div className="text-center py-8">请先登录</div>;
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pt-28">
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="relative h-32 bg-gradient-to-r from-primary-500 to-primary-600">
          <button 
            onClick={() => navigate('/settings')}
            className="absolute top-4 right-4 bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-full flex items-center"
          >
            <Settings className="h-4 w-4 mr-2" />
            编辑资料
          </button>
        </div>
        
        <div className="px-6 pb-6">
          <div className="flex items-end -mt-12">
            <img
              src={profile.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${profile.username}`}
              alt={profile.username}
              className="w-24 h-24 rounded-full border-4 border-white bg-white"
            />
            <div className="ml-4 mb-2 flex-1">
              <h1 className="text-2xl font-bold">{profile.username}</h1>
              <p className="text-gray-600">{profile.bio || '这个用户很懒，还没有写简介'}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
            <UserRoleInfo
              roleType={userStats.role_type}
              experience={userStats.experience}
              level={userStats.level}
            />
            <BloodPoints
              points={userStats.blood_points || 0}
              maxPoints={10 + (2 * userStats.level)}
            />
          </div>
        </div>

        <div className="border-t">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
            <div 
              onClick={() => navigate('/my/questions')}
              className="flex items-center p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100"
            >
              <MessageSquare className="h-8 w-8 text-primary-500" />
              <div className="ml-4">
                <h3 className="font-semibold">我的提问</h3>
                <p className="text-sm text-gray-600">查看我发布的所有问题</p>
              </div>
            </div>

            <div 
              onClick={() => navigate('/my/answers')}
              className="flex items-center p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100"
            >
              <BookOpen className="h-8 w-8 text-green-500" />
              <div className="ml-4">
                <h3 className="font-semibold">我的回答</h3>
                <p className="text-sm text-gray-600">查看我的所有回答</p>
              </div>
            </div>

            <div 
              onClick={() => navigate('/notifications')}
              className="flex items-center p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100"
            >
              <Bell className="h-8 w-8 text-yellow-500" />
              <div className="ml-4">
                <h3 className="font-semibold">消息通知</h3>
                <p className="text-sm text-gray-600">查看我的所有通知</p>
              </div>
            </div>

            <div 
              onClick={() => navigate('/settings')}
              className="flex items-center p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100"
            >
              <User className="h-8 w-8 text-purple-500" />
              <div className="ml-4">
                <h3 className="font-semibold">个人设置</h3>
                <p className="text-sm text-gray-600">修改个人信息和偏好设置</p>
              </div>
            </div>
          </div>

          <div className="p-6 border-t">
            <button
              onClick={handleLogout}
              className="flex items-center text-red-600 hover:text-red-700"
            >
              <LogOut className="h-5 w-5 mr-2" />
              退出登录
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}