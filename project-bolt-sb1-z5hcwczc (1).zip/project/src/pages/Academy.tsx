import React, { useState } from 'react';
import { BookOpen, Star, Users, Clock, ChevronRight, Play, Award, PenTool as Tool, Wand2, Brain, Image, MessageSquare, Code, Sparkles, Bot, Pencil, Video, Music, FileText } from 'lucide-react';
import { Link } from 'react-router-dom';
import { updateMetaTags } from '../lib/seo';

// 课程分类数据
const categories = [
  { id: 'ai-basics', name: 'AI基础', count: 12 },
  { id: 'machine-learning', name: '机器学习', count: 15 },
  { id: 'deep-learning', name: '深度学习', count: 18 },
  { id: 'nlp', name: '自然语言处理', count: 10 },
  { id: 'computer-vision', name: '计算机视觉', count: 8 },
  { id: 'ai-engineering', name: 'AI工程化', count: 14 }
];

// 精选课程数据
const featuredCourses = [
  {
    id: 1,
    title: 'ChatGPT应用开发实战',
    description: '从零开始学习如何开发ChatGPT应用，掌握API调用、Prompt设计等核心技能',
    image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995',
    instructor: '张教授',
    rating: 4.8,
    students: 1234,
    duration: '12小时',
    level: '中级',
    price: 299
  },
  {
    id: 2,
    title: '机器学习算法精讲',
    description: '系统学习机器学习核心算法，包括监督学习、无监督学习、强化学习等',
    image: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485',
    instructor: '李博士',
    rating: 4.9,
    students: 2345,
    duration: '16小时',
    level: '进阶',
    price: 399
  },
  {
    id: 3,
    title: '深度学习框架实践',
    description: '主流深度学习框架PyTorch使用教程，从基础到高级特性全面覆盖',
    image: 'https://images.unsplash.com/photo-1555949963-ff9fe0c870eb',
    instructor: '王教授',
    rating: 4.7,
    students: 1567,
    duration: '14小时',
    level: '高级',
    price: 499
  }
];

// 最新课程数据
const newCourses = [
  {
    id: 4,
    title: 'AI模型部署与优化',
    description: '学习如何将AI模型部署到生产环境，优化性能和资源使用',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71',
    instructor: '刘工程师',
    rating: 4.6,
    students: 890,
    duration: '10小时',
    level: '中级',
    price: 299
  },
  {
    id: 5,
    title: 'AI安全与隐私保护',
    description: '了解AI系统中的安全威胁和隐私保护技术，掌握防护措施',
    image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3',
    instructor: '陈专家',
    rating: 4.8,
    students: 678,
    duration: '8小时',
    level: '进阶',
    price: 259
  }
];

export default function Academy() {
  const [selectedCategory, setSelectedCategory] = useState('all');

  // 更新页面元信息
  React.useEffect(() => {
    updateMetaTags(
      'AI学院 - 专业的AI技术学习平台',
      '提供AI基础、机器学习、深度学习等领域的专业课程，助力AI开发者成长',
      'AI教程,机器学习,深度学习,ChatGPT,编程培训'
    );
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 pt-28">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          开启您的AI学习之旅
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          专业的AI技术学习平台，助您掌握前沿技术，成为AI领域专家
        </p>
        <div className="flex justify-center gap-4">
          <button className="bg-blue-500 text-white px-6 py-3 rounded-full hover:bg-blue-600">
            开始学习
          </button>
          <button className="bg-gray-100 text-gray-800 px-6 py-3 rounded-full hover:bg-gray-200">
            免费试听
          </button>
        </div>
      </div>

      {/* AI Tools Navigation */}
      <div className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">AI工具导航</h2>
          <div className="text-sm text-gray-500">已收录 36 个优质AI工具</div>
        </div>

        {/* 对话助手 */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-4 flex items-center">
            <Bot className="h-6 w-6 text-blue-500 mr-2" />
            对话助手
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <a href="https://chat.openai.com" target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <MessageSquare className="h-6 w-6 text-green-500" />
                <h4 className="text-lg font-medium ml-2">ChatGPT</h4>
              </div>
              <p className="text-sm text-gray-600">OpenAI开发的大语言模型，支持自然对话</p>
            </a>
            
            <a href="https://claude.ai" target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <Brain className="h-6 w-6 text-purple-500" />
                <h4 className="text-lg font-medium ml-2">Claude</h4>
              </div>
              <p className="text-sm text-gray-600">Anthropic开发的AI助手，擅长分析和写作</p>
            </a>

            <a href="https://bard.google.com" target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <Sparkles className="h-6 w-6 text-yellow-500" />
                <h4 className="text-lg font-medium ml-2">Bard</h4>
              </div>
              <p className="text-sm text-gray-600">Google的AI助手，支持多语言对话</p>
            </a>
          </div>
        </div>

        {/* 图像创作 */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-4 flex items-center">
            <Image className="h-6 w-6 text-pink-500 mr-2" />
            图像创作
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <a href="https://www.midjourney.com" target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <Wand2 className="h-6 w-6 text-indigo-500" />
                <h4 className="text-lg font-medium ml-2">Midjourney</h4>
              </div>
              <p className="text-sm text-gray-600">AI艺术创作工具，生成高质量图像</p>
            </a>

            <a href="https://www.dall-e.com" target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <Pencil className="h-6 w-6 text-orange-500" />
                <h4 className="text-lg font-medium ml-2">DALL·E</h4>
              </div>
              <p className="text-sm text-gray-600">OpenAI的AI绘画工具，擅长创意作图</p>
            </a>

            <a href="https://stability.ai" target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <Image className="h-6 w-6 text-red-500" />
                <h4 className="text-lg font-medium ml-2">Stable Diffusion</h4>
              </div>
              <p className="text-sm text-gray-600">开源图像生成模型，支持本地部署</p>
            </a>
          </div>
        </div>

        {/* 开发工具 */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-4 flex items-center">
            <Code className="h-6 w-6 text-green-500 mr-2" />
            开发工具
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <a href="https://github.com/features/copilot" target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <Code className="h-6 w-6 text-blue-500" />
                <h4 className="text-lg font-medium ml-2">GitHub Copilot</h4>
              </div>
              <p className="text-sm text-gray-600">AI编程助手，提供代码补全和建议</p>
            </a>

            <a href="https://aws.amazon.com/codewhisperer" target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <Tool className="h-6 w-6 text-yellow-500" />
                <h4 className="text-lg font-medium ml-2">CodeWhisperer</h4>
              </div>
              <p className="text-sm text-gray-600">亚马逊的AI编程助手，支持多种语言</p>
            </a>

            <a href="https://tabnine.com" target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <Tool className="h-6 w-6 text-purple-500" />
                <h4 className="text-lg font-medium ml-2">Tabnine</h4>
              </div>
              <p className="text-sm text-gray-600">AI代码补全工具，支持本地运行</p>
            </a>
          </div>
        </div>

        {/* 音视频创作 */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-4 flex items-center">
            <Video className="h-6 w-6 text-red-500 mr-2" />
            音视频创作
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <a href="https://runwayml.com" target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <Video className="h-6 w-6 text-blue-500" />
                <h4 className="text-lg font-medium ml-2">Runway</h4>
              </div>
              <p className="text-sm text-gray-600">AI视频生成和编辑工具</p>
            </a>

            <a href="https://elevenlabs.io" target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <Music className="h-6 w-6 text-indigo-500" />
                <h4 className="text-lg font-medium ml-2">ElevenLabs</h4>
              </div>
              <p className="text-sm text-gray-600">AI语音合成工具，支持多种语言</p>
            </a>

            <a href="https://www.synthesia.io" target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <Video className="h-6 w-6 text-green-500" />
                <h4 className="text-lg font-medium ml-2">Synthesia</h4>
              </div>
              <p className="text-sm text-gray-600">AI视频制作平台，支持多语言配音</p>
            </a>
          </div>
        </div>

        {/* 写作助手 */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-4 flex items-center">
            <FileText className="h-6 w-6 text-blue-500 mr-2" />
            写作助手
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <a href="https://www.notion.so/ai" target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <FileText className="h-6 w-6 text-gray-500" />
                <h4 className="text-lg font-medium ml-2">Notion AI</h4>
              </div>
              <p className="text-sm text-gray-600">集成在Notion中的AI写作助手</p>
            </a>

            <a href="https://www.grammarly.com" target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <FileText className="h-6 w-6 text-green-500" />
                <h4 className="text-lg font-medium ml-2">Grammarly</h4>
              </div>
              <p className="text-sm text-gray-600">AI写作改进和语法检查工具</p>
            </a>

            <a href="https://www.jasper.ai" target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center mb-3">
                <FileText className="h-6 w-6 text-orange-500" />
                <h4 className="text-lg font-medium ml-2">Jasper</h4>
              </div>
              <p className="text-sm text-gray-600">AI内容创作平台，支持多种文体</p>
            </a>
          </div>
        </div>
      </div>

      {/* 课程分类 */}
      <div className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">课程分类</h2>
          <Link to="/courses" className="text-blue-500 hover:text-blue-600 flex items-center">
            查看全部 <ChevronRight className="h-4 w-4 ml-1" />
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map(category => (
            <div
              key={category.id}
              className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => setSelectedCategory(category.id)}
            >
              <h3 className="font-semibold mb-2">{category.name}</h3>
              <p className="text-sm text-gray-500">{category.count} 门课程</p>
            </div>
          ))}
        </div>
      </div>

      {/* 精选课程 */}
      <div className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">精选课程</h2>
          <Link to="/featured" className="text-blue-500 hover:text-blue-600 flex items-center">
            更多精选 <ChevronRight className="h-4 w-4 ml-1" />
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredCourses.map(course => (
            <div key={course.id} className="bg-white rounded-lg shadow-sm overflow-hidden">
              <img src={course.image} alt={course.title} className="w-full h-48 object-cover" />
              <div className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-blue-500">{course.level}</span>
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="ml-1 text-sm text-gray-600">{course.rating}</span>
                  </div>
                </div>
                <h3 className="text-xl font-semibold mb-2">{course.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{course.description}</p>
                <div className="flex items-center text-sm text-gray-500 mb-4">
                  <Users className="h-4 w-4 mr-1" />
                  <span className="mr-4">{course.students} 名学员</span>
                  <Clock className="h-4 w-4 mr-1" />
                  <span>{course.duration}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <img
                      src={`https://api.dicebear.com/7.x/initials/svg?seed=${course.instructor}`}
                      alt={course.instructor}
                      className="w-6 h-6 rounded-full mr-2"
                    />
                    <span className="text-sm text-gray-600">{course.instructor}</span>
                  </div>
                  <span className="text-xl font-bold text-blue-500">¥{course.price}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 最新课程 */}
      <div className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">最新课程</h2>
          <Link to="/new" className="text-blue-500 hover:text-blue-600 flex items-center">
            查看更多 <ChevronRight className="h-4 w-4 ml-1" />
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {newCourses.map(course => (
            <div key={course.id} className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="flex">
                <img src={course.image} alt={course.title} className="w-48 h-48 object-cover" />
                <div className="p-6 flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-blue-500">{course.level}</span>
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <span className="ml-1 text-sm text-gray-600">{course.rating}</span>
                    </div>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{course.title}</h3>
                  <p className="text-gray-600 text-sm mb-4">{course.description}</p>
                  <div className="flex items-center justify-between mt-4">
                    <div className="flex items-center">
                      <img
                        src={`https://api.dicebear.com/7.x/initials/svg?seed=${course.instructor}`}
                        alt={course.instructor}
                        className="w-6 h-6 rounded-full mr-2"
                      />
                      <span className="text-sm text-gray-600">{course.instructor}</span>
                    </div>
                    <span className="text-xl font-bold text-blue-500">¥{course.price}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 学习路径 */}
      <div className="bg-white rounded-lg shadow-sm p-8">
        <h2 className="text-2xl font-bold mb-6">推荐学习路径</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="border rounded-lg p-6">
            <div className="flex items-center mb-4">
              <BookOpen className="h-8 w-8 text-blue-500" />
              <h3 className="text-xl font-semibold ml-3">AI开发入门</h3>
            </div>
            <p className="text-gray-600 mb-4">适合AI零基础学习者，循序渐进掌握AI开发基础知识</p>
            <ul className="space-y-2 mb-6">
              <li className="flex items-center text-gray-600">
                <Play className="h-4 w-4 mr-2" /> Python编程基础
              </li>
              <li className="flex items-center text-gray-600">
                <Play className="h-4 w-4 mr-2" /> 机器学习入门
              </li>
              <li className="flex items-center text-gray-600">
                <Play className="h-4 w-4 mr-2" /> 深度学习基础
              </li>
            </ul>
            <button className="w-full bg-blue-500 text-white py-2 rounded-full hover:bg-blue-600">
              开始学习
            </button>
          </div>

          <div className="border rounded-lg p-6">
            <div className="flex items-center mb-4">
              <Award className="h-8 w-8 text-green-500" />
              <h3 className="text-xl font-semibold ml-3">AI工程师进阶</h3>
            </div>
            <p className="text-gray-600 mb-4">面向有基础的开发者，提升AI开发实战能力</p>
            <ul className="space-y-2 mb-6">
              <li className="flex items-center text-gray-600">
                <Play className="h-4 w-4 mr-2" /> 模型训练与优化
              </li>
              <li className="flex items-center text-gray-600">
                <Play className="h-4 w-4 mr-2" /> 深度学习框架
              </li>
              <li className="flex items-center text-gray-600">
                <Play className="h-4 w-4 mr-2" /> AI系统设计
              </li>
            </ul>
            <button className="w-full bg-green-500 text-white py-2 rounded-full hover:bg-green-600">
              开始进阶
            </button>
          </div>

          <div className="border rounded-lg p-6">
            <div className="flex items-center mb-4">
              <Star className="h-8 w-8 text-yellow-500" />
              <h3 className="text-xl font-semibold ml-3">AI专家养成</h3>
            </div>
            <p className="text-gray-600 mb-4">针对资深开发者，掌握AI前沿技术与最佳实践</p>
            <ul className="space-y-2 mb-6">
              <li className="flex items-center text-gray-600">
                <Play className="h-4 w-4 mr-2" /> 大模型开发
              </li>
              <li className="flex items-center text-gray-600">
                <Play className="h-4 w-4 mr-2" /> AI系统优化
              </li>
              <li className="flex items-center text-gray-600">
                <Play className="h-4 w-4 mr-2" /> 前沿技术研究
              </li>
            </ul>
            <button className="w-full bg-yellow-500 text-white py-2 rounded-full hover:bg-yellow-600">
              成为专家
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}