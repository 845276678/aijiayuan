import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Newspaper, TrendingUp, MessageSquare, Plus, ExternalLink } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { updateMetaTags } from '../../lib/seo';

interface AINews {
  id: string;
  title: string;
  content: string;
  summary: string;
  source_url: string;
  source_name: string;
  image_url: string;
  category: string;
  author: {
    username: string;
    avatar_url: string;
  };
  likes_count: number;
  views_count: number;
  is_featured: boolean;
  created_at: string;
}

export default function NewsPage() {
  const [news, setNews] = useState<AINews[]>([]);
  const [featuredNews, setFeaturedNews] = useState<AINews[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(true);

  const categories = [
    { id: 'all', name: '全部' },
    { id: 'technology', name: '技术进展' },
    { id: 'business', name: '商业应用' },
    { id: 'research', name: '研究动态' },
    { id: 'policy', name: '政策法规' },
    { id: 'events', name: '行业活动' }
  ];

  useEffect(() => {
    updateMetaTags(
      'AI新闻 - 全球人工智能新闻资讯',
      '及时了解全球AI领域最新动态、技术进展、商业应用等新闻资讯',
      'AI新闻,人工智能,技术进展,商业应用,研究动态'
    );
    loadNews();
  }, [selectedCategory]);

  async function loadNews() {
    setIsLoading(true);
    try {
      // Load featured news
      const { data: featuredData } = await supabase
        .from('ai_news')
        .select(`
          *,
          author:profiles!ai_news_author_id_fkey(*)
        `)
        .eq('status', 'approved')
        .eq('is_featured', true)
        .order('created_at', { ascending: false })
        .limit(3);

      setFeaturedNews(featuredData || []);

      // Load regular news
      let query = supabase
        .from('ai_news')
        .select(`
          *,
          author:profiles!ai_news_author_id_fkey(*)
        `)
        .eq('status', 'approved')
        .eq('is_featured', false)
        .order('created_at', { ascending: false });

      if (selectedCategory !== 'all') {
        query = query.eq('category', selectedCategory);
      }

      const { data } = await query;
      setNews(data || []);
    } catch (error) {
      console.error('Error loading news:', error);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 pt-28">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          AI新闻资讯
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          及时了解全球AI领域最新动态
        </p>
        <div className="flex justify-center gap-4">
          <Link
            to="/news/submit"
            className="bg-blue-500 text-white px-6 py-3 rounded-full hover:bg-blue-600 flex items-center"
          >
            <Plus className="h-5 w-5 mr-2" />
            提交新闻
          </Link>
        </div>
      </div>

      {/* Featured News */}
      {featuredNews.length > 0 && (
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">热门报道</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredNews.map(item => (
              <Link key={item.id} to={`/news/${item.id}`}>
                <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow h-full">
                  <img
                    src={item.image_url}
                    alt={item.title}
                    className="w-full h-48 object-cover rounded-t-lg"
                  />
                  <div className="p-4">
                    <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                    <p className="text-gray-600 text-sm mb-4">{item.summary}</p>
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <div className="flex items-center">
                        <img
                          src={item.author.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${item.author.username}`}
                          alt={item.author.username}
                          className="w-6 h-6 rounded-full mr-2"
                        />
                        <span>{item.author.username}</span>
                      </div>
                      <span>{new Date(item.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Category Filter */}
      <div className="flex justify-center mb-8">
        <div className="flex space-x-2 bg-gray-100 p-1 rounded-full">
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-6 py-2 rounded-full ${
                selectedCategory === category.id
                  ? 'bg-white text-blue-500 shadow'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>
      </div>

      {/* News List */}
      {isLoading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-500">加载中...</p>
        </div>
      ) : news.length === 0 ? (
        <div className="text-center py-12">
          <Newspaper className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500">暂无相关新闻</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6">
          {news.map(item => (
            <Link key={item.id} to={`/news/${item.id}`}>
              <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow p-6">
                <div className="flex">
                  {item.image_url && (
                    <img
                      src={item.image_url}
                      alt={item.title}
                      className="w-48 h-32 object-cover rounded-lg mr-6"
                    />
                  )}
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                    <p className="text-gray-600 mb-4">{item.summary}</p>
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center">
                          <img
                            src={item.author.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${item.author.username}`}
                            alt={item.author.username}
                            className="w-6 h-6 rounded-full mr-2"
                          />
                          <span>{item.author.username}</span>
                        </div>
                        {item.source_name && (
                          <div className="flex items-center">
                            <ExternalLink className="h-4 w-4 mr-1" />
                            <span>{item.source_name}</span>
                          </div>
                        )}
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center">
                          <TrendingUp className="h-4 w-4 mr-1" />
                          <span>{item.views_count}</span>
                        </div>
                        <div className="flex items-center">
                          <MessageSquare className="h-4 w-4 mr-1" />
                          <span>{item.likes_count}</span>
                        </div>
                        <span>{new Date(item.created_at).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}