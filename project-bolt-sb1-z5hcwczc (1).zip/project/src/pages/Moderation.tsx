import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { usePermission } from '../hooks/usePermissions';
import { useModeration } from '../hooks/useModeration';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/Tabs';
import { AlertTriangle, CheckCircle, XCircle, Flag } from 'lucide-react';
import type { Question, Answer, ModerationLog, ContentStatus } from '../lib/supabase';

type PendingContent = (Question | Answer) & {
  type: 'question' | 'answer';
};

export default function Moderation() {
  const navigate = useNavigate();
  const { hasPermission, loading: permissionLoading } = usePermission('moderate_content');
  const { moderateContent, isLoading: moderationLoading } = useModeration();
  const [pendingContent, setPendingContent] = useState<PendingContent[]>([]);
  const [moderationLogs, setModerationLogs] = useState<ModerationLog[]>([]);
  const [selectedContent, setSelectedContent] = useState<PendingContent | null>(null);
  const [moderationReason, setModerationReason] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!permissionLoading && !hasPermission) {
      navigate('/');
      return;
    }
    loadContent();
    loadModerationLogs();
  }, [permissionLoading, hasPermission]);

  async function loadContent() {
    setIsLoading(true);
    try {
      // Load pending questions
      const { data: questions } = await supabase
        .from('questions')
        .select(`
          *,
          author:profiles(*)
        `)
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      // Load pending answers
      const { data: answers } = await supabase
        .from('answers')
        .select(`
          *,
          author:profiles(*),
          question:questions(*)
        `)
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      const pendingQuestions = (questions || []).map(q => ({ ...q, type: 'question' as const }));
      const pendingAnswers = (answers || []).map(a => ({ ...a, type: 'answer' as const }));
      
      setPendingContent([...pendingQuestions, ...pendingAnswers]);
    } catch (error) {
      console.error('Error loading pending content:', error);
    } finally {
      setIsLoading(false);
    }
  }

  async function loadModerationLogs() {
    try {
      const { data } = await supabase
        .from('moderation_logs')
        .select(`
          *,
          moderator:profiles(*)
        `)
        .order('created_at', { ascending: false })
        .limit(50);

      setModerationLogs(data || []);
    } catch (error) {
      console.error('Error loading moderation logs:', error);
    }
  }

  async function handleModeration(action: ContentStatus) {
    if (!selectedContent || moderationLoading) return;

    const success = await moderateContent(
      selectedContent.type,
      selectedContent.id,
      action,
      moderationReason
    );

    if (success) {
      await loadContent();
      await loadModerationLogs();
      setSelectedContent(null);
      setModerationReason('');
    }
  }

  function getStatusBadge(status: ContentStatus) {
    const badges = {
      pending: { icon: AlertTriangle, class: 'bg-yellow-100 text-yellow-800' },
      approved: { icon: CheckCircle, class: 'bg-green-100 text-green-800' },
      rejected: { icon: XCircle, class: 'bg-red-100 text-red-800' },
      flagged: { icon: Flag, class: 'bg-orange-100 text-orange-800' }
    };

    const { icon: Icon, class: className } = badges[status];
    
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${className}`}>
        <Icon className="w-4 h-4 mr-1" />
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  }

  if (permissionLoading) {
    return <div className="text-center py-8">Loading...</div>;
  }

  if (!hasPermission) {
    return null;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 pt-28">
      <h1 className="text-3xl font-bold mb-8">Content Moderation</h1>

      <Tabs defaultValue="pending" className="w-full">
        <TabsList>
          <TabsTrigger value="pending">
            Pending Review ({pendingContent.length})
          </TabsTrigger>
          <TabsTrigger value="history">
            Moderation History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending">
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-4">
              {isLoading ? (
                <div className="text-center py-8">Loading pending content...</div>
              ) : pendingContent.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No content pending review
                </div>
              ) : (
                pendingContent.map(content => (
                  <div
                    key={content.id}
                    className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                      selectedContent?.id === content.id
                        ? 'border-blue-500 bg-blue-50'
                        : 'hover:bg-gray-50'
                    }`}
                    onClick={() => setSelectedContent(content)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-500">
                        {content.type.toUpperCase()}
                      </span>
                      {getStatusBadge(content.status)}
                    </div>
                    <h3 className="font-medium">
                      {content.type === 'question' 
                        ? content.title 
                        : `Answer to: ${(content as Answer).question?.title}`}
                    </h3>
                    <p className="text-sm text-gray-600 mt-2">
                      {content.content.substring(0, 150)}...
                    </p>
                    <div className="mt-2 text-sm text-gray-500">
                      By {content.author?.username} • {new Date(content.created_at).toLocaleDateString()}
                    </div>
                  </div>
                ))
              )}
            </div>

            {selectedContent && (
              <div className="border rounded-lg p-6">
                <h2 className="text-xl font-bold mb-4">Review Content</h2>
                <div className="mb-4">
                  <h3 className="font-medium">
                    {selectedContent.type === 'question'
                      ? selectedContent.title
                      : `Answer to: ${(selectedContent as Answer).question?.title}`}
                  </h3>
                  <div className="mt-2 prose max-w-none" dangerouslySetInnerHTML={{ __html: selectedContent.content }} />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Moderation Reason
                  </label>
                  <textarea
                    value={moderationReason}
                    onChange={(e) => setModerationReason(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows={3}
                    placeholder="Enter reason for moderation action..."
                  />
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => handleModeration('approved')}
                    disabled={moderationLoading}
                    className="flex-1 bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 disabled:opacity-50"
                  >
                    Approve
                  </button>
                  <button
                    onClick={() => handleModeration('rejected')}
                    disabled={moderationLoading}
                    className="flex-1 bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 disabled:opacity-50"
                  >
                    Reject
                  </button>
                  <button
                    onClick={() => handleModeration('flagged')}
                    disabled={moderationLoading}
                    className="flex-1 bg-orange-500 text-white px-4 py-2 rounded-lg hover:bg-orange-600 disabled:opacity-50"
                  >
                    Flag
                  </button>
                </div>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="history">
          <div className="space-y-4">
            {moderationLogs.map(log => (
              <div key={log.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-500">
                    {log.content_type.toUpperCase()}
                  </span>
                  {getStatusBadge(log.action as ContentStatus)}
                </div>
                {log.reason && (
                  <p className="text-gray-600 mt-2">{log.reason}</p>
                )}
                <div className="mt-2 text-sm text-gray-500">
                  By {log.moderator?.username} • {new Date(log.created_at).toLocaleDateString()}
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}