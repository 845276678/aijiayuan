import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import { Lightbulb } from 'lucide-react';

export default function NewIdeaPage() {
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [toolName, setToolName] = useState('');
  const [efficiencyGain, setEfficiencyGain] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim() || !description.trim() || !toolName.trim() || !efficiencyGain.trim()) {
      setError('请填写所有必填字段');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setError('请先登录');
        return;
      }

      const { error: submitError } = await supabase
        .from('efficiency_ideas')
        .insert({
          title: title.trim(),
          description: description.trim(),
          tool_name: toolName.trim(),
          efficiency_gain: efficiencyGain.trim(),
          author_id: user.id
        });

      if (submitError) throw submitError;

      navigate('/ideas');
    } catch (err) {
      setError('提交失败，请稍后重试');
      console.error('Error submitting idea:', err);
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-8 pt-28">
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center mb-6">
          <Lightbulb className="h-8 w-8 text-blue-500 mr-3" />
          <h1 className="text-2xl font-bold">分享效率工具</h1>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-2">
              标题 *
            </label>
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="简短描述你的效率工具"
              maxLength={100}
            />
          </div>

          <div>
            <label htmlFor="toolName" className="block text-sm font-medium text-gray-700 mb-2">
              工具名称 *
            </label>
            <input
              type="text"
              id="toolName"
              value={toolName}
              onChange={(e) => setToolName(e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="使用的AI工具名称"
            />
          </div>

          <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
              详细描述 *
            </label>
            <textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="详细描述如何使用这个工具提升效率"
            />
          </div>

          <div>
            <label htmlFor="efficiencyGain" className="block text-sm font-medium text-gray-700 mb-2">
              效率提升 *
            </label>
            <input
              type="text"
              id="efficiencyGain"
              value={efficiencyGain}
              onChange={(e) => setEfficiencyGain(e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="例如：节省50%的时间"
            />
          </div>

          {error && (
            <div className="p-4 text-red-700 bg-red-100 rounded-lg">
              {error}
            </div>
          )}

          <div className="flex justify-end gap-4">
            <button
              type="button"
              onClick={() => navigate('/ideas')}
              className="px-6 py-2 text-gray-600 hover:text-gray-900"
            >
              取消
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className={`px-6 py-2 rounded-lg text-white ${
                isSubmitting
                  ? 'bg-blue-400 cursor-not-allowed'
                  : 'bg-blue-500 hover:bg-blue-600'
              }`}
            >
              {isSubmitting ? '提交中...' : '发布'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}