import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import { Users, ThumbsUp, Edit, Trash2, AlertTriangle } from 'lucide-react';

export default function ProjectDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [project, setProject] = useState<any>(null);
  const [members, setMembers] = useState<any[]>([]);
  const [isAuthor, setIsAuthor] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isMember, setIsMember] = useState(false);
  const [isJoining, setIsJoining] = useState(false);

  useEffect(() => {
    loadProject();
  }, [id]);

  async function loadProject() {
    if (!id) return;

    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      const { data: project } = await supabase
        .from('innovation_projects')
        .select(`
          *,
          author:profiles(*)
        `)
        .eq('id', id)
        .single();

      if (project) {
        setProject(project);
        setIsAuthor(user?.id === project.author_id);
        loadMembers();
        
        if (user) {
          const { data: memberData } = await supabase
            .from('project_members')
            .select('*')
            .eq('project_id', id)
            .eq('user_id', user.id)
            .single();
          
          setIsMember(!!memberData);
        }
      }
    } catch (error) {
      console.error('Error loading project:', error);
    } finally {
      setIsLoading(false);
    }
  }

  async function loadMembers() {
    const { data } = await supabase
      .from('project_members')
      .select(`
        *,
        user:profiles(*)
      `)
      .eq('project_id', id)
      .order('joined_at', { ascending: true });

    setMembers(data || []);
  }

  async function handleJoinProject() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate('/auth');
      return;
    }

    setIsJoining(true);
    try {
      const { error } = await supabase
        .from('project_members')
        .insert({
          project_id: id,
          user_id: user.id,
          role: '成员'
        });

      if (error) throw error;
      
      setIsMember(true);
      loadMembers();
    } catch (error) {
      console.error('Error joining project:', error);
    } finally {
      setIsJoining(false);
    }
  }

  async function handleDelete() {
    setIsDeleting(true);
    try {
      const { error } = await supabase
        .from('innovation_projects')
        .delete()
        .eq('id', id);

      if (error) throw error;
      navigate('/ideas?tab=projects');
    } catch (error) {
      console.error('Error deleting project:', error);
    } finally {
      setIsDeleting(false);
    }
  }

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8 pt-28">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-3/4 mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-1/3"></div>
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8 pt-28">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900">项目不存在</h2>
          <p className="mt-2 text-gray-600">该项目可能已被删除或移动</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pt-28">
      <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <img
              src={project.author.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${project.author.username}`}
              alt={project.author.username}
              className="w-12 h-12 rounded-full"
            />
            <div className="ml-4">
              <h2 className="text-xl font-bold">{project.title}</h2>
              <p className="text-gray-500">
                由 {project.author.username} 发布于 {new Date(project.created_at).toLocaleDateString()}
              </p>
            </div>
          </div>
          {isAuthor && (
            <div className="flex items-center space-x-2">
              <button
                onClick={() => navigate(`/projects/${id}/edit`)}
                className="p-2 text-gray-600 hover:text-blue-500"
              >
                <Edit className="h-5 w-5" />
              </button>
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="p-2 text-gray-600 hover:text-red-500"
              >
                <Trash2 className="h-5 w-5" />
              </button>
            </div>
          )}
        </div>

        <div className="prose max-w-none mb-6">
          <p className="text-gray-600">{project.description}</p>
        </div>

        <div className="flex flex-wrap gap-2 mb-6">
          {project.required_skills.map((skill: string) => (
            <span
              key={skill}
              className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-sm"
            >
              {skill}
            </span>
          ))}
        </div>

        <div className="flex items-center justify-between border-t pt-4">
          <div className="flex items-center text-sm text-gray-500">
            <div className="flex items-center mr-6">
              <Users className="h-5 w-5 mr-1" />
              <span>{members.length}/{project.team_size} 成员</span>
            </div>
            <div className="flex items-center">
              <ThumbsUp className="h-5 w-5 mr-1" />
              <span>{project.likes_count || 0} 赞同</span>
            </div>
          </div>
          {!isAuthor && !isMember && project.status === 'recruiting' && (
            <button
              onClick={handleJoinProject}
              disabled={isJoining}
              className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 disabled:opacity-50"
            >
              {isJoining ? '加入中...' : '加入项目'}
            </button>
          )}
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="text-lg font-semibold mb-4">项目成员</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {members.map(member => (
            <div key={member.id} className="flex items-center p-4 border rounded-lg">
              <img
                src={member.user.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${member.user.username}`}
                alt={member.user.username}
                className="w-10 h-10 rounded-full"
              />
              <div className="ml-3">
                <div className="font-medium">{member.user.username}</div>
                <div className="text-sm text-gray-500">{member.role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <div className="flex items-center mb-4">
              <AlertTriangle className="h-6 w-6 text-red-500 mr-2" />
              <h3 className="text-xl font-bold">确认删除</h3>
            </div>
            <p className="text-gray-600 mb-6">
              确定要删除这个项目吗？此操作无法撤销。
            </p>
            <div className="flex justify-end gap-4">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 text-gray-600 hover:text-gray-900"
              >
                取消
              </button>
              <button
                onClick={handleDelete}
                disabled={isDeleting}
                className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 disabled:opacity-50"
              >
                {isDeleting ? '删除中...' : '确认删除'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}