import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import { MessageSquare, ThumbsUp, Edit, Trash2, AlertTriangle } from 'lucide-react';

export default function IdeaDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [idea, setIdea] = useState<any>(null);
  const [comments, setComments] = useState<any[]>([]);
  const [newComment, setNewComment] = useState('');
  const [isAuthor, setIsAuthor] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    loadIdea();
  }, [id]);

  async function loadIdea() {
    if (!id) return;

    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      const { data: idea } = await supabase
        .from('efficiency_ideas')
        .select(`
          *,
          author:profiles(*)
        `)
        .eq('id', id)
        .single();

      if (idea) {
        setIdea(idea);
        setIsAuthor(user?.id === idea.author_id);
        loadComments();
      }
    } catch (error) {
      console.error('Error loading idea:', error);
    } finally {
      setIsLoading(false);
    }
  }

  async function loadComments() {
    const { data } = await supabase
      .from('idea_comments')
      .select(`
        *,
        author:profiles(*)
      `)
      .eq('idea_id', id)
      .order('created_at', { ascending: true });

    setComments(data || []);
  }

  async function handleSubmitComment(e: React.FormEvent) {
    e.preventDefault();
    if (!newComment.trim()) return;

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate('/auth');
      return;
    }

    try {
      await supabase
        .from('idea_comments')
        .insert({
          idea_id: id,
          content: newComment.trim(),
          author_id: user.id
        });

      setNewComment('');
      loadComments();
    } catch (error) {
      console.error('Error submitting comment:', error);
    }
  }

  async function handleDelete() {
    setIsDeleting(true);
    try {
      const { error } = await supabase
        .from('efficiency_ideas')
        .delete()
        .eq('id', id);

      if (error) throw error;
      navigate('/ideas');
    } catch (error) {
      console.error('Error deleting idea:', error);
    } finally {
      setIsDeleting(false);
    }
  }

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8 pt-28">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-3/4 mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-1/3"></div>
        </div>
      </div>
    );
  }

  if (!idea) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8 pt-28">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900">内容不存在</h2>
          <p className="mt-2 text-gray-600">该效率工具可能已被删除或移动</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pt-28">
      <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <img
              src={idea.author.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${idea.author.username}`}
              alt={idea.author.username}
              className="w-12 h-12 rounded-full"
            />
            <div className="ml-4">
              <h2 className="text-xl font-bold">{idea.title}</h2>
              <p className="text-gray-500">
                由 {idea.author.username} 发布于 {new Date(idea.created_at).toLocaleDateString()}
              </p>
            </div>
          </div>
          {isAuthor && (
            <div className="flex items-center space-x-2">
              <button
                onClick={() => navigate(`/ideas/${id}/edit`)}
                className="p-2 text-gray-600 hover:text-blue-500"
              >
                <Edit className="h-5 w-5" />
              </button>
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="p-2 text-gray-600 hover:text-red-500"
              >
                <Trash2 className="h-5 w-5" />
              </button>
            </div>
          )}
        </div>

        <div className="prose max-w-none mb-6">
          <p className="text-gray-600">{idea.description}</p>
        </div>

        <div className="border-t pt-4">
          <div className="flex items-center text-sm text-gray-500">
            <div className="flex items-center mr-6">
              <ThumbsUp className="h-5 w-5 mr-1" />
              <span>{idea.likes_count || 0} 赞同</span>
            </div>
            <div className="flex items-center">
              <MessageSquare className="h-5 w-5 mr-1" />
              <span>{comments.length} 评论</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="text-lg font-semibold mb-4">评论</h3>
        
        <form onSubmit={handleSubmitComment} className="mb-6">
          <textarea
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="写下你的想法..."
            className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            rows={3}
          />
          <div className="mt-2 flex justify-end">
            <button
              type="submit"
              disabled={!newComment.trim()}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50"
            >
              发表评论
            </button>
          </div>
        </form>

        <div className="space-y-4">
          {comments.map(comment => (
            <div key={comment.id} className="border-b last:border-0 pb-4">
              <div className="flex items-center mb-2">
                <img
                  src={comment.author.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${comment.author.username}`}
                  alt={comment.author.username}
                  className="w-8 h-8 rounded-full"
                />
                <div className="ml-3">
                  <span className="font-medium">{comment.author.username}</span>
                  <span className="text-gray-500 text-sm ml-2">
                    {new Date(comment.created_at).toLocaleString()}
                  </span>
                </div>
              </div>
              <p className="text-gray-600">{comment.content}</p>
            </div>
          ))}
        </div>
      </div>

      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <div className="flex items-center mb-4">
              <AlertTriangle className="h-6 w-6 text-red-500 mr-2" />
              <h3 className="text-xl font-bold">确认删除</h3>
            </div>
            <p className="text-gray-600 mb-6">
              确定要删除这个效率工具分享吗？此操作无法撤销。
            </p>
            <div className="flex justify-end gap-4">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 text-gray-600 hover:text-gray-900"
              >
                取消
              </button>
              <button
                onClick={handleDelete}
                disabled={isDeleting}
                className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 disabled:opacity-50"
              >
                {isDeleting ? '删除中...' : '确认删除'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}