import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Lightbulb, Users, ArrowRight, TrendingUp, MessageSquare } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { updateMetaTags } from '../../lib/seo';

interface IdeaPost {
  id: string;
  title: string;
  description: string;
  tool_name: string;
  efficiency_gain: string;
  author: {
    username: string;
    avatar_url: string;
  };
  likes_count: number;
  comments_count: number;
  created_at: string;
}

interface ProjectPost {
  id: string;
  title: string;
  description: string;
  required_skills: string[];
  team_size: number;
  status: 'recruiting' | 'in_progress' | 'completed';
  author: {
    username: string;
    avatar_url: string;
  };
  members_count: number;
  likes_count: number;
  created_at: string;
}

export default function IdeasPage() {
  const [activeTab, setActiveTab] = useState<'ideas' | 'projects'>('ideas');
  const [ideas, setIdeas] = useState<IdeaPost[]>([]);
  const [projects, setProjects] = useState<ProjectPost[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    updateMetaTags(
      '创新想法 - AI效率工具分享与项目招募',
      '分享AI工具提升工作效率的方法，发布可实施的创新项目并招募团队成员',
      'AI工具,效率提升,项目招募,创新想法'
    );
    loadContent();
  }, []);

  async function loadContent() {
    setIsLoading(true);
    try {
      // Load efficiency ideas
      const { data: ideasData } = await supabase
        .from('efficiency_ideas')
        .select(`
          *,
          author:profiles!efficiency_ideas_author_id_fkey(*),
          likes_count,
          comments:idea_comments(count)
        `)
        .eq('status', 'approved')
        .order('created_at', { ascending: false });

      if (ideasData) {
        setIdeas(ideasData);
      }

      // Load innovation projects
      const { data: projectsData } = await supabase
        .from('innovation_projects')
        .select(`
          *,
          author:profiles!innovation_projects_author_id_fkey(*),
          members:project_members(count),
          likes_count
        `)
        .eq('status', 'approved')
        .order('created_at', { ascending: false });

      if (projectsData) {
        setProjects(projectsData);
      }
    } catch (error) {
      console.error('Error loading content:', error);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 pt-28">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          创新想法
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          分享AI效率工具，发起创新项目，寻找志同道合的伙伴
        </p>
        <div className="flex justify-center gap-4">
          <Link
            to="/ideas/new"
            className="bg-blue-500 text-white px-6 py-3 rounded-full hover:bg-blue-600 flex items-center"
          >
            <Lightbulb className="h-5 w-5 mr-2" />
            分享效率工具
          </Link>
          <Link
            to="/projects/new"
            className="bg-green-500 text-white px-6 py-3 rounded-full hover:bg-green-600 flex items-center"
          >
            <Users className="h-5 w-5 mr-2" />
            发起创新项目
          </Link>
        </div>
      </div>

      <div className="flex justify-center mb-8">
        <div className="flex space-x-2 bg-gray-100 p-1 rounded-full">
          <button
            onClick={() => setActiveTab('ideas')}
            className={`px-6 py-2 rounded-full ${
              activeTab === 'ideas'
                ? 'bg-white text-blue-500 shadow'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            效率工具
          </button>
          <button
            onClick={() => setActiveTab('projects')}
            className={`px-6 py-2 rounded-full ${
              activeTab === 'projects'
                ? 'bg-white text-blue-500 shadow'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            创新项目
          </button>
        </div>
      </div>

      {isLoading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-500">加载中...</p>
        </div>
      ) : activeTab === 'ideas' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {ideas.map(idea => (
            <Link key={idea.id} to={`/ideas/${idea.id}`}>
              <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow p-6">
                <div className="flex items-center mb-4">
                  <img
                    src={idea.author.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${idea.author.username}`}
                    alt={idea.author.username}
                    className="w-10 h-10 rounded-full"
                  />
                  <div className="ml-3">
                    <h3 className="font-medium">{idea.author.username}</h3>
                    <p className="text-sm text-gray-500">
                      {new Date(idea.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <h2 className="text-xl font-semibold mb-2">{idea.title}</h2>
                <p className="text-gray-600 mb-4">{idea.description}</p>
                <div className="flex items-center text-sm text-gray-500">
                  <div className="flex items-center mr-4">
                    <TrendingUp className="h-4 w-4 mr-1" />
                    <span>效率提升: {idea.efficiency_gain}</span>
                  </div>
                  <div className="flex items-center mr-4">
                    <MessageSquare className="h-4 w-4 mr-1" />
                    <span>{idea.comments_count} 评论</span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {projects.map(project => (
            <Link key={project.id} to={`/projects/${project.id}`}>
              <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow p-6">
                <div className="flex items-center mb-4">
                  <img
                    src={project.author.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${project.author.username}`}
                    alt={project.author.username}
                    className="w-10 h-10 rounded-full"
                  />
                  <div className="ml-3">
                    <h3 className="font-medium">{project.author.username}</h3>
                    <p className="text-sm text-gray-500">
                      {new Date(project.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <h2 className="text-xl font-semibold mb-2">{project.title}</h2>
                <p className="text-gray-600 mb-4">{project.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.required_skills.map(skill => (
                    <span
                      key={skill}
                      className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-sm"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center text-gray-500">
                    <Users className="h-4 w-4 mr-1" />
                    <span>{project.members_count}/{project.team_size} 成员</span>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm ${
                    project.status === 'recruiting'
                      ? 'bg-green-50 text-green-600'
                      : project.status === 'in_progress'
                      ? 'bg-blue-50 text-blue-600'
                      : 'bg-gray-50 text-gray-600'
                  }`}>
                    {project.status === 'recruiting' ? '招募中' :
                     project.status === 'in_progress' ? '进行中' : '已完成'}
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}