import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import type { Category, Question } from '../lib/supabase';

export default function CategoryPage() {
  const { slug } = useParams<{ slug: string }>();
  const [category, setCategory] = useState<Category | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [subcategories, setSubcategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (slug) {
      loadCategoryAndQuestions();
    }
  }, [slug]);

  async function loadCategoryAndQuestions() {
    setIsLoading(true);
    try {
      // Load category
      const { data: categoryData } = await supabase
        .from('categories')
        .select('*')
        .eq('slug', slug)
        .single();

      if (categoryData) {
        setCategory(categoryData);

        // Load subcategories
        const { data: subcategoriesData } = await supabase
          .from('categories')
          .select('*')
          .eq('parent_id', categoryData.id)
          .order('name');

        setSubcategories(subcategoriesData || []);

        // Load questions in this category
        const { data: questionsData } = await supabase
          .from('questions')
          .select(`
            *,
            author:profiles(*),
            answers(count)
          `)
          .eq('category_id', categoryData.id)
          .order('created_at', { ascending: false });

        setQuestions(questionsData || []);
      }
    } catch (error) {
      console.error('Error loading category and questions:', error);
    } finally {
      setIsLoading(false);
    }
  }

  if (isLoading) {
    return <div className="text-center py-8">Loading...</div>;
  }

  if (!category) {
    return <div className="text-center py-8">Category not found</div>;
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pt-28">
      <div className="bg-white rounded-lg p-6 shadow-sm mb-8">
        <h1 className="text-3xl font-bold text-gray-900">{category.name}</h1>
        <p className="mt-2 text-gray-600">{category.description}</p>
        <div className="mt-4 text-sm text-gray-500">
          {questions.length} 个问题
        </div>
      </div>

      {subcategories.length > 0 && (
        <div className="bg-white rounded-lg p-6 shadow-sm mb-8">
          <h2 className="text-xl font-semibold mb-4">子分类</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {subcategories.map(subcat => (
              <Link
                key={subcat.id}
                to={`/category/${subcat.slug}`}
                className="p-4 border rounded-lg hover:bg-gray-50 transition-colors"
              >
                <h3 className="font-medium text-gray-900">{subcat.name}</h3>
                <p className="text-sm text-gray-500 mt-1">{subcat.description}</p>
              </Link>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-4">
        {questions.map(question => (
          <Link key={question.id} to={`/question/${question.id}`}>
            <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <h2 className="text-xl font-semibold text-gray-900">{question.title}</h2>
              <p className="mt-2 text-gray-600">{question.content.substring(0, 200)}...</p>
              <div className="mt-4 flex items-center text-sm text-gray-500">
                <img
                  src={question.author?.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${question.author?.username}`}
                  alt={question.author?.username}
                  className="w-6 h-6 rounded-full"
                />
                <span className="ml-2">{question.author?.username}</span>
                <span className="mx-2">•</span>
                <span>{new Date(question.created_at).toLocaleDateString()}</span>
                <span className="mx-2">•</span>
                <span>{question.answers?.length || 0} 回答</span>
              </div>
            </div>
          </Link>
        ))}

        {questions.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            暂无相关问题
          </div>
        )}
      </div>
    </div>
  );
}