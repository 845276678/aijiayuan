import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Newspaper, TrendingUp, MessageSquare, Star, MessageCircle } from 'lucide-react';
import { updateMetaTags } from '../lib/seo';

export default function HomePage() {
  const [latestNews, setLatestNews] = useState<any[]>([]);
  const [featuredNews, setFeaturedNews] = useState<any[]>([]);
  const [latestPosts, setLatestPosts] = useState<any[]>([]);
  const [latestQuestions, setLatestQuestions] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    updateMetaTags(
      'AI家园 - 专业的人工智能技术交流社区',
      '发现、学习和分享最新的AI技术，连接AI开发者社区',
      'AI,人工智能,机器学习,深度学习,ChatGPT,技术社区'
    );
    loadContent();
  }, []);

  async function loadContent() {
    setIsLoading(true);
    try {
      // Load latest forum posts
      const { data: posts } = await supabase
        .from('forum_posts')
        .select(`
          *,
          author:profiles(*),
          category:forum_categories(*)
        `)
        .eq('status', 'published')
        .order('created_at', { ascending: false })
        .limit(5);

      setLatestPosts(posts || []);

      // Load latest questions
      const { data: questions } = await supabase
        .from('questions')
        .select(`
          *,
          author:profiles(*),
          answers(count)
        `)
        .eq('status', 'approved')
        .order('created_at', { ascending: false })
        .limit(5);

      setLatestQuestions(questions || []);

      // Load featured news
      const { data: featured } = await supabase
        .from('ai_news')
        .select(`
          *,
          author:profiles!ai_news_author_id_fkey(*)
        `)
        .eq('status', 'approved')
        .eq('is_featured', true)
        .order('created_at', { ascending: false })
        .limit(3);

      setFeaturedNews(featured || []);

      // Load latest news
      const { data: latest } = await supabase
        .from('ai_news')
        .select(`
          *,
          author:profiles!ai_news_author_id_fkey(*)
        `)
        .eq('status', 'approved')
        .order('created_at', { ascending: false })
        .limit(6);

      setLatestNews(latest || []);
    } catch (error) {
      console.error('Error loading content:', error);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 pt-28">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          探索AI的无限可能
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          加入AI家园，与开发者一起学习、分享和创新
        </p>
        <div className="flex justify-center gap-4">
          <Link
            to="/forum"
            className="bg-primary-500 text-white px-6 py-3 rounded-full hover:bg-primary-600"
          >
            进入论坛
          </Link>
          <Link
            to="/academy"
            className="bg-gray-100 text-gray-800 px-6 py-3 rounded-full hover:bg-gray-200"
          >
            学习课程
          </Link>
        </div>
      </div>

      {/* Featured News */}
      {/* Latest Content */}
      <div className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">最新内容</h2>
        </div>
        <div className="grid grid-cols-1 gap-6">
          {/* Latest Forum Posts */}
          {latestPosts.map(post => (
            <Link key={post.id} to={`/forum/post/${post.id}`}>
              <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center mb-2">
                  <MessageCircle className="h-5 w-5 text-blue-500 mr-2" />
                  <span className="text-sm text-blue-500">{post.category?.name || '论坛'}</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">{post.title}</h3>
                <div className="flex items-center text-sm text-gray-500">
                  <img
                    src={post.author?.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${post.author?.username}`}
                    alt={post.author?.username}
                    className="w-6 h-6 rounded-full mr-2"
                  />
                  <span>{post.author?.username}</span>
                  <span className="mx-2">•</span>
                  <span>{new Date(post.created_at).toLocaleDateString()}</span>
                  <span className="mx-2">•</span>
                  <span>{post.replies_count || 0} 回复</span>
                </div>
              </div>
            </Link>
          ))}

          {/* Latest Questions */}
          {latestQuestions.map(question => (
            <Link key={question.id} to={`/question/${question.id}`}>
              <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center mb-2">
                  <MessageSquare className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-sm text-green-500">问答</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">{question.title}</h3>
                <div className="flex items-center text-sm text-gray-500">
                  <img
                    src={question.author?.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${question.author?.username}`}
                    alt={question.author?.username}
                    className="w-6 h-6 rounded-full mr-2"
                  />
                  <span>{question.author?.username}</span>
                  <span className="mx-2">•</span>
                  <span>{new Date(question.created_at).toLocaleDateString()}</span>
                  <span className="mx-2">•</span>
                  <span>{question.answers?.length || 0} 回答</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {featuredNews.length > 0 && (
        <div className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">热门报道</h2>
            <Link to="/news" className="text-primary-500 hover:text-primary-600 flex items-center">
              更多新闻
              <TrendingUp className="h-4 w-4 ml-1" />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredNews.map(news => (
              <Link key={news.id} to={`/news/${news.id}`}>
                <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow h-full">
                  <img
                    src={news.image_url}
                    alt={news.title}
                    className="w-full h-48 object-cover rounded-t-lg"
                  />
                  <div className="p-4">
                    <h3 className="text-xl font-semibold mb-2">{news.title}</h3>
                    <p className="text-gray-600 text-sm mb-4">{news.summary}</p>
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <div className="flex items-center">
                        <img
                          src={news.author.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${news.author.username}`}
                          alt={news.author.username}
                          className="w-6 h-6 rounded-full mr-2"
                        />
                        <span>{news.author.username}</span>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center">
                          <Star className="h-4 w-4 mr-1" />
                          <span>{news.likes_count || 0}</span>
                        </div>
                        <div className="flex items-center">
                          <MessageSquare className="h-4 w-4 mr-1" />
                          <span>{news.views_count || 0}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Latest News */}
      <div className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">最新动态</h2>
          <Link to="/news" className="text-primary-500 hover:text-primary-600 flex items-center">
            查看全部
            <Newspaper className="h-4 w-4 ml-1" />
          </Link>
        </div>
        <div className="grid grid-cols-1 gap-6">
          {latestNews.map(news => (
            <Link key={news.id} to={`/news/${news.id}`}>
              <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow p-6">
                <div className="flex">
                  {news.image_url && (
                    <img
                      src={news.image_url}
                      alt={news.title}
                      className="w-48 h-32 object-cover rounded-lg mr-6"
                    />
                  )}
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold mb-2">{news.title}</h3>
                    <p className="text-gray-600 mb-4">{news.summary}</p>
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <div className="flex items-center">
                        <img
                          src={news.author.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${news.author.username}`}
                          alt={news.author.username}
                          className="w-6 h-6 rounded-full mr-2"
                        />
                        <span>{news.author.username}</span>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center">
                          <Star className="h-4 w-4 mr-1" />
                          <span>{news.likes_count || 0}</span>
                        </div>
                        <div className="flex items-center">
                          <MessageSquare className="h-4 w-4 mr-1" />
                          <span>{news.views_count || 0}</span>
                        </div>
                        <span>{new Date(news.created_at).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Quick Links */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link to="/academy" className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
          <h3 className="text-xl font-semibold mb-2">AI学院</h3>
          <p className="text-gray-600">系统学习AI开发技能，提升专业能力</p>
        </Link>
        <Link to="/ideas" className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
          <h3 className="text-xl font-semibold mb-2">创新想法</h3>
          <p className="text-gray-600">分享AI效率工具，发起创新项目</p>
        </Link>
        <Link to="/content" className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
          <h3 className="text-xl font-semibold mb-2">AI创作</h3>
          <p className="text-gray-600">展示AI生成的视频、图片和小说</p>
        </Link>
      </div>
    </div>
  );
}