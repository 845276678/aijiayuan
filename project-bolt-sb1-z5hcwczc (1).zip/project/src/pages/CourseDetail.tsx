import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Play, BookOpen, Clock, Users, Star, CheckCircle, Lock } from 'lucide-react';
import { supabase } from '../lib/supabase';
import LoadingSpinner from '../components/LoadingSpinner';
import { updateMetaTags } from '../lib/seo';

interface Chapter {
  id: string;
  title: string;
  description: string;
  duration: string;
  isLocked: boolean;
}

interface Course {
  id: string;
  title: string;
  description: string;
  image: string;
  instructor: string;
  rating: number;
  students: number;
  duration: string;
  level: string;
  price: number;
  chapters: Chapter[];
}

export default function CourseDetail() {
  const { courseId } = useParams<{ courseId: string }>();
  const [course, setCourse] = useState<Course | null>(null);
  const [selectedChapter, setSelectedChapter] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isEnrolled, setIsEnrolled] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCourse();
  }, [courseId]);

  useEffect(() => {
    if (course) {
      updateMetaTags(
        `${course.title} - AI学院课程`,
        course.description,
        `AI课程,${course.title},${course.level},在线学习`
      );
    }
  }, [course]);

  async function loadCourse() {
    try {
      // 这里应该从API获取课程详情
      // 目前使用模拟数据
      const mockCourse: Course = {
        id: courseId!,
        title: 'ChatGPT应用开发实战',
        description: '从零开始学习如何开发ChatGPT应用，掌握API调用、Prompt设计等核心技能',
        image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995',
        instructor: '张教授',
        rating: 4.8,
        students: 1234,
        duration: '12小时',
        level: '中级',
        price: 299,
        chapters: [
          {
            id: '1',
            title: '课程介绍',
            description: '了解课程目标和学习路径',
            duration: '10分钟',
            isLocked: false
          },
          {
            id: '2',
            title: 'ChatGPT API基础',
            description: '学习API的基本使用方法',
            duration: '45分钟',
            isLocked: false
          },
          {
            id: '3',
            title: 'Prompt工程实践',
            description: '掌握高效的Prompt设计技巧',
            duration: '60分钟',
            isLocked: true
          },
          {
            id: '4',
            title: '应用架构设计',
            description: '设计可扩展的应用架构',
            duration: '90分钟',
            isLocked: true
          }
        ]
      };

      setCourse(mockCourse);
      
      // 检查用户是否已购买课程
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data } = await supabase
          .from('course_enrollments')
          .select('*')
          .eq('user_id', user.id)
          .eq('course_id', courseId)
          .single();
        
        setIsEnrolled(!!data);
      }
    } catch (error) {
      console.error('Error loading course:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleEnroll() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        // 重定向到登录页面
        window.location.href = `/auth?redirect=/course/${courseId}`;
        return;
      }

      // 这里应该集成支付功能
      // 暂时直接标记为已购买
      const { error } = await supabase
        .from('course_enrollments')
        .insert({
          user_id: user.id,
          course_id: courseId,
          purchased_at: new Date().toISOString()
        });

      if (error) throw error;
      setIsEnrolled(true);
    } catch (error) {
      console.error('Error enrolling in course:', error);
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (!course) {
    return (
      <div className="text-center py-8">
        课程不存在
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 pt-28">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* 课程内容 */}
        <div className="lg:col-span-2">
          {/* 视频播放区域 */}
          <div className="relative bg-black aspect-video rounded-lg overflow-hidden mb-8">
            {selectedChapter ? (
              isPlaying ? (
                <video
                  className="w-full h-full"
                  controls
                  autoPlay
                  src={`/api/courses/${courseId}/chapters/${selectedChapter}/video`}
                />
              ) : (
                <div className="absolute inset-0 flex items-center justify-center">
                  <button
                    onClick={() => setIsPlaying(true)}
                    className="bg-white/10 hover:bg-white/20 p-4 rounded-full"
                  >
                    <Play className="h-12 w-12 text-white" />
                  </button>
                </div>
              )
            ) : (
              <img
                src={course.image}
                alt={course.title}
                className="w-full h-full object-cover"
              />
            )}
          </div>

          {/* 课程信息 */}
          <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
            <h1 className="text-3xl font-bold mb-4">{course.title}</h1>
            <div className="flex items-center text-sm text-gray-500 mb-4">
              <div className="flex items-center mr-4">
                <Star className="h-4 w-4 text-yellow-400 fill-current mr-1" />
                <span>{course.rating}</span>
              </div>
              <div className="flex items-center mr-4">
                <Users className="h-4 w-4 mr-1" />
                <span>{course.students} 名学员</span>
              </div>
              <div className="flex items-center mr-4">
                <Clock className="h-4 w-4 mr-1" />
                <span>{course.duration}</span>
              </div>
              <div className="flex items-center">
                <BookOpen className="h-4 w-4 mr-1" />
                <span>{course.level}</span>
              </div>
            </div>
            <p className="text-gray-600">{course.description}</p>
          </div>

          {/* 课程目录 */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-bold mb-4">课程目录</h2>
            <div className="space-y-4">
              {course.chapters.map(chapter => (
                <div
                  key={chapter.id}
                  className={`p-4 rounded-lg ${
                    selectedChapter === chapter.id
                      ? 'bg-blue-50 border-blue-200'
                      : 'bg-gray-50 hover:bg-gray-100'
                  } cursor-pointer`}
                  onClick={() => {
                    if (!chapter.isLocked || isEnrolled) {
                      setSelectedChapter(chapter.id);
                      setIsPlaying(false);
                    }
                  }}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      {chapter.isLocked && !isEnrolled ? (
                        <Lock className="h-5 w-5 text-gray-400 mr-2" />
                      ) : (
                        <Play className="h-5 w-5 text-blue-500 mr-2" />
                      )}
                      <div>
                        <h3 className="font-medium">{chapter.title}</h3>
                        <p className="text-sm text-gray-500">{chapter.description}</p>
                      </div>
                    </div>
                    <span className="text-sm text-gray-500">{chapter.duration}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 购买卡片 */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm p-6 sticky top-24">
            <div className="text-center mb-6">
              <div className="text-3xl font-bold mb-2">¥{course.price}</div>
              {isEnrolled ? (
                <div className="flex items-center justify-center text-green-500">
                  <CheckCircle className="h-5 w-5 mr-2" />
                  已购买
                </div>
              ) : (
                <button
                  onClick={handleEnroll}
                  className="w-full bg-blue-500 text-white py-3 rounded-full hover:bg-blue-600"
                >
                  立即购买
                </button>
              )}
            </div>

            <div className="space-y-4">
              <div className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                <span>终身学习权限</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                <span>随时随地学习</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                <span>课程更新永久有效</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                <span>专属学习社群</span>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t">
              <div className="flex items-center mb-4">
                <img
                  src={`https://api.dicebear.com/7.x/initials/svg?seed=${course.instructor}`}
                  alt={course.instructor}
                  className="w-12 h-12 rounded-full mr-4"
                />
                <div>
                  <div className="font-medium">{course.instructor}</div>
                  <div className="text-sm text-gray-500">资深AI专家</div>
                </div>
              </div>
              <p className="text-sm text-gray-600">
                拥有多年AI开发和教学经验，曾任职于多家知名科技公司，
                擅长深度学习、自然语言处理等领域。
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}