import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import RichTextEditor from '../components/RichTextEditor';

export default function AskQuestion() {
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    
    if (!title.trim() || !content.trim()) {
      setError('请填写标题和内容');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        setError('请先登录');
        return;
      }

      const { data, error: submitError } = await supabase
        .from('questions')
        .insert({
          title: title.trim(),
          content,
          author_id: user.id
        })
        .select()
        .single();

      if (submitError) throw submitError;

      // Handle content interaction for executor role
      await supabase.rpc('handle_content_interaction', {
        p_content_type: 'question',
        p_content_id: data.id,
        p_interaction_type: 'create'
      });

      navigate(`/question/${data.id}`);
    } catch (err) {
      setError('提交问题时出错，请稍后重试');
      console.error('Error submitting question:', err);
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pt-28">
      <div className="bg-white rounded-lg p-6 shadow-sm">
        <h1 className="text-2xl font-bold mb-6">提出问题</h1>
        
        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-2">
              问题标题
            </label>
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="请用一句话描述你的问题"
              className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              maxLength={150}
            />
            <p className="mt-2 text-sm text-gray-500">
              还可以输入 {150 - title.length} 个字符
            </p>
          </div>

          <div className="mb-6">
            <label htmlFor="content" className="block text-sm font-medium text-gray-700 mb-2">
              问题详情
            </label>
            <RichTextEditor
              content={content}
              onChange={setContent}
              placeholder="详细描述你的问题..."
            />
          </div>

          {error && (
            <div className="mb-4 p-4 text-red-700 bg-red-100 rounded-lg">
              {error}
            </div>
          )}

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isSubmitting}
              className={`px-6 py-2 rounded-full text-white ${
                isSubmitting
                  ? 'bg-blue-400 cursor-not-allowed'
                  : 'bg-blue-500 hover:bg-blue-600'
              }`}
            >
              {isSubmitting ? '提交中...' : '发布问题'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}