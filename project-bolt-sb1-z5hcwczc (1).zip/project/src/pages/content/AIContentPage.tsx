import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Video, Image, Book, TrendingUp, MessageSquare, Plus } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { updateMetaTags } from '../../lib/seo';

interface AIContent {
  id: string;
  title: string;
  description: string;
  content_type: 'video' | 'image' | 'novel';
  url: string;
  thumbnail_url: string;
  author: {
    username: string;
    avatar_url: string;
  };
  likes_count: number;
  views_count: number;
  created_at: string;
}

export default function AIContentPage() {
  const [activeTab, setActiveTab] = useState<'video' | 'image' | 'novel'>('video');
  const [content, setContent] = useState<AIContent[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    updateMetaTags(
      'AI创作空间 - 分享AI生成的视频、图片和小说',
      '展示和分享使用AI创作的视频、图片和小说作品',
      'AI创作,AI视频,AI图片,AI小说'
    );
    loadContent();
  }, [activeTab]);

  async function loadContent() {
    setIsLoading(true);
    try {
      const { data } = await supabase
        .from('ai_content')
        .select(`
          *,
          author:profiles(*)
        `)
        .eq('content_type', activeTab)
        .eq('status', 'approved')
        .order('created_at', { ascending: false });

      setContent(data || []);
    } catch (error) {
      console.error('Error loading content:', error);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 pt-28">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          AI创作空间
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          展示和分享你的AI创作作品
        </p>
        <div className="flex justify-center gap-4">
          <Link
            to="/content/new"
            className="bg-blue-500 text-white px-6 py-3 rounded-full hover:bg-blue-600 flex items-center"
          >
            <Plus className="h-5 w-5 mr-2" />
            上传作品
          </Link>
        </div>
      </div>

      <div className="flex justify-center mb-8">
        <div className="flex space-x-2 bg-gray-100 p-1 rounded-full">
          <button
            onClick={() => setActiveTab('video')}
            className={`px-6 py-2 rounded-full flex items-center ${
              activeTab === 'video'
                ? 'bg-white text-blue-500 shadow'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Video className="h-4 w-4 mr-2" />
            视频
          </button>
          <button
            onClick={() => setActiveTab('image')}
            className={`px-6 py-2 rounded-full flex items-center ${
              activeTab === 'image'
                ? 'bg-white text-blue-500 shadow'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Image className="h-4 w-4 mr-2" />
            图片
          </button>
          <button
            onClick={() => setActiveTab('novel')}
            className={`px-6 py-2 rounded-full flex items-center ${
              activeTab === 'novel'
                ? 'bg-white text-blue-500 shadow'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Book className="h-4 w-4 mr-2" />
            小说
          </button>
        </div>
      </div>

      {isLoading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-500">加载中...</p>
        </div>
      ) : content.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500">暂无内容</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {content.map(item => (
            <Link key={item.id} to={`/content/${item.id}`}>
              <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <div className="aspect-video relative">
                  <img
                    src={item.thumbnail_url || item.url}
                    alt={item.title}
                    className="w-full h-full object-cover rounded-t-lg"
                  />
                  {item.content_type === 'video' && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-16 h-16 bg-black bg-opacity-50 rounded-full flex items-center justify-center">
                        <Video className="h-8 w-8 text-white" />
                      </div>
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                  <p className="text-gray-600 text-sm mb-4">{item.description}</p>
                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <div className="flex items-center">
                      <img
                        src={item.author.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${item.author.username}`}
                        alt={item.author.username}
                        className="w-6 h-6 rounded-full mr-2"
                      />
                      <span>{item.author.username}</span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center">
                        <TrendingUp className="h-4 w-4 mr-1" />
                        <span>{item.views_count}</span>
                      </div>
                      <div className="flex items-center">
                        <MessageSquare className="h-4 w-4 mr-1" />
                        <span>{item.likes_count}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}