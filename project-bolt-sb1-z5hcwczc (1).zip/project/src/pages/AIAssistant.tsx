import React, { useState } from 'react';
import { Send, Code, FileText, Loader } from 'lucide-react';
import { generateCode, generateContent } from '../lib/deepseek';

export default function AIAssistant() {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');
  const [mode, setMode] = useState<'chat' | 'code'>('chat');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!prompt.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);

    try {
      const result = mode === 'code' 
        ? await generateCode(prompt)
        : await generateContent(prompt);
      
      setResponse(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : '生成内容时出错');
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pt-28">
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">DeepSeek AI 助手</h1>
          <div className="flex gap-2">
            <button
              onClick={() => setMode('chat')}
              className={`px-4 py-2 rounded-lg flex items-center gap-2 ${
                mode === 'chat'
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-100 text-gray-700'
              }`}
            >
              <FileText className="h-5 w-5" />
              内容生成
            </button>
            <button
              onClick={() => setMode('code')}
              className={`px-4 py-2 rounded-lg flex items-center gap-2 ${
                mode === 'code'
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-100 text-gray-700'
              }`}
            >
              <Code className="h-5 w-5" />
              代码助手
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={mode === 'code' ? '描述你需要的代码功能...' : '输入你的问题或需求...'}
              className="w-full h-32 px-4 py-2 rounded-lg border focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {error && (
            <div className="p-4 bg-red-50 text-red-700 rounded-lg">
              {error}
            </div>
          )}

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isLoading || !prompt.trim()}
              className={`px-6 py-2 rounded-lg text-white flex items-center gap-2 ${
                isLoading || !prompt.trim()
                  ? 'bg-blue-400 cursor-not-allowed'
                  : 'bg-blue-500 hover:bg-blue-600'
              }`}
            >
              {isLoading ? (
                <>
                  <Loader className="h-5 w-5 animate-spin" />
                  生成中...
                </>
              ) : (
                <>
                  <Send className="h-5 w-5" />
                  生成
                </>
              )}
            </button>
          </div>
        </form>

        {response && (
          <div className="mt-6">
            <h2 className="text-lg font-semibold mb-2">AI 回复:</h2>
            <div className="bg-gray-50 p-4 rounded-lg">
              <pre className="whitespace-pre-wrap font-mono text-sm">
                {response}
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}