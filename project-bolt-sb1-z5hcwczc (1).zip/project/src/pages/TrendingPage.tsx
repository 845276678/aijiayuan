import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/Tabs';
import type { Question, Tag } from '../lib/supabase';
import { TrendingUp, MessageSquare, ThumbsUp } from 'lucide-react';

export default function TrendingPage() {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [timeRange, setTimeRange] = useState<'day' | 'week' | 'month'>('week');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadTrendingContent();
  }, [timeRange]);

  async function loadTrendingContent() {
    setIsLoading(true);
    try {
      // Calculate date range
      const now = new Date();
      const startDate = new Date();
      switch (timeRange) {
        case 'day':
          startDate.setDate(now.getDate() - 1);
          break;
        case 'week':
          startDate.setDate(now.getDate() - 7);
          break;
        case 'month':
          startDate.setMonth(now.getMonth() - 1);
          break;
      }

      // Load trending questions
      const { data: questionsData } = await supabase
        .from('questions')
        .select(`
          *,
          author:profiles(*),
          answers(count),
          votes(count)
        `)
        .gte('created_at', startDate.toISOString())
        .order('views_count', { ascending: false })
        .limit(10);

      setQuestions(questionsData || []);

      // Load trending tags
      const { data: tagsData } = await supabase
        .from('tags')
        .select(`
          *,
          questions:project_tags(count)
        `)
        .order('questions', { ascending: false })
        .limit(10);

      setTags(tagsData || []);
    } catch (error) {
      console.error('Error loading trending content:', error);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pt-28">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <TrendingUp className="h-8 w-8 text-blue-500" />
          趋势
        </h1>
        <div className="flex gap-2">
          <button
            onClick={() => setTimeRange('day')}
            className={`px-4 py-2 rounded-full ${
              timeRange === 'day'
                ? 'bg-blue-500 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            今日
          </button>
          <button
            onClick={() => setTimeRange('week')}
            className={`px-4 py-2 rounded-full ${
              timeRange === 'week'
                ? 'bg-blue-500 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            本周
          </button>
          <button
            onClick={() => setTimeRange('month')}
            className={`px-4 py-2 rounded-full ${
              timeRange === 'month'
                ? 'bg-blue-500 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            本月
          </button>
        </div>
      </div>

      <Tabs defaultValue="questions" className="w-full">
        <TabsList>
          <TabsTrigger value="questions">热门问题</TabsTrigger>
          <TabsTrigger value="tags">热门话题</TabsTrigger>
        </TabsList>

        {isLoading ? (
          <div className="py-8 text-center text-gray-500">加载中...</div>
        ) : (
          <>
            <TabsContent value="questions">
              <div className="space-y-4">
                {questions.map((question, index) => (
                  <Link key={question.id} to={`/question/${question.id}`}>
                    <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                      <div className="flex items-start">
                        <div className="flex-shrink-0 w-8 text-2xl font-bold text-gray-300">
                          {index + 1}
                        </div>
                        <div className="flex-1">
                          <h2 className="text-xl font-semibold text-gray-900">{question.title}</h2>
                          <p className="mt-2 text-gray-600">{question.content.substring(0, 200)}...</p>
                          <div className="mt-4 flex items-center text-sm text-gray-500">
                            <img
                              src={question.author?.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${question.author?.username}`}
                              alt={question.author?.username}
                              className="w-6 h-6 rounded-full"
                            />
                            <span className="ml-2">{question.author?.username}</span>
                            <span className="mx-2">•</span>
                            <div className="flex items-center">
                              <MessageSquare className="h-4 w-4 mr-1" />
                              {question.answers?.length || 0}
                            </div>
                            <span className="mx-2">•</span>
                            <div className="flex items-center">
                              <ThumbsUp className="h-4 w-4 mr-1" />
                              {question.votes?.length || 0}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="tags">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {tags.map(tag => (
                  <Link key={tag.id} to={`/tag/${tag.slug}`}>
                    <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                      <h3 className="text-lg font-semibold text-gray-900">#{tag.name}</h3>
                      <p className="mt-2 text-sm text-gray-600">{tag.description || '暂无描述'}</p>
                      <div className="mt-4 text-sm text-gray-500">
                        {tag.questions?.length || 0} 个相关问题
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </TabsContent>
          </>
        )}
      </Tabs>
    </div>
  );
}