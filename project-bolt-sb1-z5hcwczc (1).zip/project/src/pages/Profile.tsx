import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import type { Profile, Question, Answer } from '../lib/supabase';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/Tabs';

export default function Profile() {
  const { username } = useParams<{ username: string }>();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isCurrentUser, setIsCurrentUser] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);
  const [followersCount, setFollowersCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);

  useEffect(() => {
    loadProfile();
  }, [username]);

  async function loadProfile() {
    if (!username) return;

    setIsLoading(true);
    try {
      // Load profile
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('username', username)
        .single();

      if (profileData) {
        setProfile(profileData);

        // Load questions
        const { data: questionsData } = await supabase
          .from('questions')
          .select('*, author:profiles(*)')
          .eq('author_id', profileData.id)
          .order('created_at', { ascending: false });

        setQuestions(questionsData || []);

        // Load answers
        const { data: answersData } = await supabase
          .from('answers')
          .select('*, question:questions(*), author:profiles(*)')
          .eq('author_id', profileData.id)
          .order('created_at', { ascending: false });

        setAnswers(answersData || []);

        // Check if current user
        const { data: { user } } = await supabase.auth.getUser();
        setIsCurrentUser(user?.id === profileData.id);

        // Load follow status
        if (user) {
          const { data: followData } = await supabase
            .from('follows')
            .select('*')
            .eq('follower_id', user.id)
            .eq('following_id', profileData.id)
            .single();

          setIsFollowing(!!followData);
        }

        // Load followers/following count
        const { count: followersCount } = await supabase
          .from('follows')
          .select('*', { count: 'exact' })
          .eq('following_id', profileData.id);

        const { count: followingCount } = await supabase
          .from('follows')
          .select('*', { count: 'exact' })
          .eq('follower_id', profileData.id);

        setFollowersCount(followersCount || 0);
        setFollowingCount(followingCount || 0);
      }
    } catch (error) {
      console.error('Error loading profile:', error);
    } finally {
      setIsLoading(false);
    }
  }

  async function handleFollow() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user || !profile) return;

    if (isFollowing) {
      await supabase
        .from('follows')
        .delete()
        .eq('follower_id', user.id)
        .eq('following_id', profile.id);
      setFollowersCount(prev => prev - 1);
    } else {
      await supabase
        .from('follows')
        .insert({
          follower_id: user.id,
          following_id: profile.id
        });
      setFollowersCount(prev => prev + 1);
    }
    setIsFollowing(!isFollowing);
  }

  if (isLoading) {
    return <div className="text-center py-8">Loading...</div>;
  }

  if (!profile) {
    return <div className="text-center py-8">User not found</div>;
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pt-28">
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="relative h-32 bg-gradient-to-r from-blue-500 to-purple-500">
          {isCurrentUser && (
            <button 
              className="absolute top-4 right-4 bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-full"
              onClick={() => window.location.href = '/settings'}
            >
              编辑个人资料
            </button>
          )}
        </div>
        
        <div className="px-6 pb-6">
          <div className="flex items-end -mt-12">
            <img
              src={profile.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${profile.username}`}
              alt={profile.username}
              className="w-24 h-24 rounded-full border-4 border-white bg-white"
            />
            <div className="ml-4 mb-2 flex-1">
              <h1 className="text-2xl font-bold">{profile.username}</h1>
              <p className="text-gray-600">{profile.bio || '这个用户很懒，还没有写简介'}</p>
            </div>
            {!isCurrentUser && (
              <button
                onClick={handleFollow}
                className={`px-6 py-2 rounded-full ${
                  isFollowing
                    ? 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                    : 'bg-blue-500 text-white hover:bg-blue-600'
                }`}
              >
                {isFollowing ? '取消关注' : '关注'}
              </button>
            )}
          </div>

          <div className="flex items-center space-x-6 mt-6 text-gray-600">
            <div>
              <span className="font-semibold text-gray-900">{questions.length}</span> 提问
            </div>
            <div>
              <span className="font-semibold text-gray-900">{answers.length}</span> 回答
            </div>
            <div>
              <span className="font-semibold text-gray-900">{followersCount}</span> 关注者
            </div>
            <div>
              <span className="font-semibold text-gray-900">{followingCount}</span> 正在关注
            </div>
          </div>
        </div>

        <Tabs defaultValue="questions" className="px-6">
          <TabsList>
            <TabsTrigger value="questions">提问</TabsTrigger>
            <TabsTrigger value="answers">回答</TabsTrigger>
          </TabsList>

          <TabsContent value="questions">
            <div className="space-y-4">
              {questions.map(question => (
                <div key={question.id} className="border-b pb-4">
                  <h3 className="text-lg font-semibold">
                    <a href={`/question/${question.id}`} className="hover:text-blue-500">
                      {question.title}
                    </a>
                  </h3>
                  <p className="text-gray-600 mt-2">{question.content.substring(0, 200)}...</p>
                  <div className="text-sm text-gray-500 mt-2">
                    发布于 {new Date(question.created_at).toLocaleDateString()}
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="answers">
            <div className="space-y-4">
              {answers.map(answer => (
                <div key={answer.id} className="border-b pb-4">
                  <div className="text-sm text-gray-500 mb-2">
                    回答了问题：
                    <a href={`/question/${answer.question?.id}`} className="text-blue-500 hover:underline">
                      {answer.question?.title}
                    </a>
                  </div>
                  <p className="text-gray-600">{answer.content.substring(0, 200)}...</p>
                  <div className="text-sm text-gray-500 mt-2">
                    发布于 {new Date(answer.created_at).toLocaleDateString()}
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}