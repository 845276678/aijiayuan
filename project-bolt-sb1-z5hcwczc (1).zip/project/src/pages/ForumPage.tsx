import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Link, useSearchParams } from 'react-router-dom';
import { MessageSquare, TrendingUp, Users, Star, Clock, Shield, Filter, Eye, Heart } from 'lucide-react';
import { updateMetaTags } from '../lib/seo';
import type { ForumPost, ForumCategory } from '../lib/types';

interface CategoryStats {
  posts_count: number;
  latest_post?: {
    title: string;
    id: string;
    created_at: string;
    author: {
      username: string;
      avatar_url: string;
    };
  };
}
import ForumPost from '../components/ForumPost';
import { useDebounce } from '../hooks/useDebounce';

interface TrendingUser {
  id: string;
  username: string;
  avatar_url: string;
  posts_count: number;
  followers_count: number;
}

export default function ForumPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get('category') || 'all');
  const [categories, setCategories] = useState<(ForumCategory & CategoryStats)[]>([]);
  const [latestPosts, setLatestPosts] = useState<ForumPost[]>([]);
  const [trendingPosts, setTrendingPosts] = useState<ForumPost[]>([]);
  const [trendingUsers, setTrendingUsers] = useState<TrendingUser[]>([]);
  const [posts, setPosts] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const debouncedCategory = useDebounce(selectedCategory, 300);

  useEffect(() => {
    updateMetaTags(
      'AI论坛 - 技术交流与问答',
      '分享AI开发经验，解答技术难题，交流学习心得',
      'AI论坛,技术交流,问答社区,经验分享'
    );
    loadContent();
  }, []);

  useEffect(() => {
    loadTrendingUsers();
  }, []);

  async function loadTrendingUsers() {
    try {
      const { data } = await supabase
        .from('profiles')
        .select(`
          id,
          username,
          avatar_url,
          posts:forum_posts(count),
          followers:follows(count)
        `)
        .order('posts', { ascending: false })
        .limit(5);

      if (data) {
        setTrendingUsers(data.map(user => ({
          id: user.id,
          username: user.username,
          avatar_url: user.avatar_url,
          posts_count: user.posts[0]?.count || 0,
          followers_count: user.followers[0]?.count || 0
        })));
      }
    } catch (error) {
      console.error('Error loading trending users:', error);
    }
  }

  useEffect(() => {
    loadPosts();
  }, [debouncedCategory]);

  async function loadContent() {
    setIsLoading(true);
    try {
      // Load categories with stats
      const { data: categoriesData } = await supabase
        .from('forum_categories')
        .select(`
          *,
          posts:forum_posts(count),
          latest_post:forum_posts(
            id,
            title,
            created_at,
            author:profiles!forum_posts_author_id_fkey(*)
          )
        `)
        .order('sort_order');

      if (categoriesData) {
        setCategories(categoriesData.map(category => ({
          ...category,
          posts_count: category.posts[0]?.count || 0,
          latest_post: category.latest_post[0]
        })));
      }

      // Load latest posts
      const { data: latest } = await supabase
        .from('forum_posts')
        .select(`
          *,
          author:profiles!forum_posts_author_id_fkey(*),
          category:forum_categories(*)
        `)
        .order('created_at', { ascending: false })
        .limit(5);

      setLatestPosts(latest || []);

      // Load trending posts
      const { data: trending } = await supabase
        .from('forum_posts')
        .select(`
          *,
          author:profiles!forum_posts_author_id_fkey(*),
          category:forum_categories(*)
        `)
        .order('views_count', { ascending: false })
        .limit(5);

      setTrendingPosts(trending || []);

      await loadPosts();
    } catch (error) {
      console.error('Error loading forum content:', error);
    } finally {
      setIsLoading(false);
    }
  }

  async function loadPosts() {
    let query = supabase
      .from('forum_posts')
      .select(`
        *,
        author:profiles(*),
        category:forum_categories(*)
      `)
      .order('is_pinned', { ascending: false })
      .order('created_at', { ascending: false });

    if (selectedCategory !== 'all') {
      query = query.eq('category_id', selectedCategory);
    }

    const { data } = await query;
    setPosts(data || []);
  }

  function handleCategoryChange(categoryId: string) {
    setSelectedCategory(categoryId);
    setSearchParams({ category: categoryId });
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 pt-28">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          AI论坛
        </h1>
        <div className="flex justify-center gap-4 mb-8">
          <Link
            to="/forum/rules"
            className="text-blue-500 hover:text-blue-600 flex items-center"
          >
            <Shield className="h-5 w-5 mr-2" />
            社区规则
          </Link>
        </div>
        <p className="text-xl text-gray-600 mb-8">
          分享AI开发经验，解答技术难题，交流学习心得
        </p>
      </div>
      <div className="grid grid-cols-12 gap-8">
        {/* Left Sidebar */}
        <div className="col-span-12 lg:col-span-3">
          <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
            <div className="p-4 border-b">
              <h2 className="text-lg font-semibold flex items-center">
                <TrendingUp className="h-5 w-5 text-red-500 mr-2" />
                热门主题
              </h2>
            </div>
            <div className="divide-y">
              {trendingPosts.slice(0, 5).map(post => (
                <Link key={post.id} to={`/forum/post/${post.id}`}>
                  <div className="p-4 hover:bg-gray-50">
                    <h3 className="font-medium text-gray-900 mb-1 line-clamp-1">
                      {post.title}
                    </h3>
                    <div className="flex items-center text-sm text-gray-500">
                      <Eye className="h-4 w-4 mr-1" />
                      <span>{post.views_count}</span>
                      <MessageSquare className="h-4 w-4 ml-3 mr-1" />
                      <span>{post.replies_count}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="p-4 border-b">
              <h2 className="text-lg font-semibold flex items-center">
                <Clock className="h-5 w-5 text-blue-500 mr-2" />
                最新主题
              </h2>
            </div>
            <div className="divide-y">
              {latestPosts.slice(0, 5).map(post => (
                <Link key={post.id} to={`/forum/post/${post.id}`}>
                  <div className="p-4 hover:bg-gray-50">
                    <h3 className="font-medium text-gray-900 mb-1 line-clamp-1">
                      {post.title}
                    </h3>
                    <div className="flex items-center text-sm text-gray-500">
                      <img
                        src={post.author?.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${post.author?.username}`}
                        alt={post.author?.username}
                        className="w-4 h-4 rounded-full mr-1"
                      />
                      <span>{post.author?.username}</span>
                      <span className="mx-2">•</span>
                      <span>{new Date(post.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="col-span-12 lg:col-span-6">
          {/* Categories */}
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b">
              <h2 className="text-xl font-bold">论坛版块</h2>
            </div>
            <div className="divide-y">
              {isLoading ? (
                <div className="p-6 text-center">加载中...</div>
              ) : (
                categories.map(category => (
                  <div key={category.id} className="p-6 hover:bg-gray-50">
                    <Link to={`/forum/category/${category.slug}`} className="flex items-start">
                      <MessageSquare className="h-6 w-6 text-primary-500 mt-1" />
                      <div className="ml-4 flex-1">
                        <h3 className="text-lg font-semibold hover:text-primary-500">
                          {category.name}
                        </h3>
                        <p className="text-gray-600 text-sm mt-1">
                          {category.description}
                        </p>
                        <div className="flex items-center mt-2 text-sm text-gray-500">
                          <span>{category.posts_count} 个主题</span>
                          {category.latest_post && (
                            <>
                              <span className="mx-2">•</span>
                              <span>最新: </span>
                            </>
                          )}
                        </div>
                      </div>
                    </Link>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="col-span-12 lg:col-span-4 space-y-6">
          {/* Quick Actions */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <Link
              to="/forum/post/new"
              className="block w-full bg-primary-500 text-white text-center px-4 py-2 rounded-lg hover:bg-primary-600"
            >
              发布新主题
            </Link>
          </div>

          {/* Forum Stats */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-semibold mb-4">论坛统计</h2>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-gray-600">主题数</span>
                <span className="font-medium">{categories.reduce((acc, cat) => acc + cat.posts_count, 0)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">今日发帖</span>
                <span className="font-medium">
                  {latestPosts.filter(post => 
                    new Date(post.created_at).toDateString() === new Date().toDateString()
                  ).length}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="col-span-12 lg:col-span-3">
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="p-4 border-b">
              <h2 className="text-lg font-semibold flex items-center">
                <Users className="h-5 w-5 text-green-500 mr-2" />
                活跃作者
              </h2>
            </div>
            <div className="divide-y">
              {trendingUsers.map(user => (
                <Link key={user.id} to={`/user/${user.username}`}>
                  <div className="p-4 hover:bg-gray-50">
                    <div className="flex items-center">
                      <img
                        src={user.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${user.username}`}
                        alt={user.username}
                        className="w-10 h-10 rounded-full"
                      />
                      <div className="ml-3">
                        <h3 className="font-medium text-gray-900">{user.username}</h3>
                        <div className="flex items-center text-sm text-gray-500">
                          <MessageSquare className="h-4 w-4 mr-1" />
                          <span>{user.posts_count} 主题</span>
                          <Heart className="h-4 w-4 ml-3 mr-1" />
                          <span>{user.followers_count} 关注</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}