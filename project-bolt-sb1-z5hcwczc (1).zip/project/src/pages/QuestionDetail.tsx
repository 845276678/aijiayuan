import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import type { Question, Answer, Profile } from '../lib/supabase';
import RichTextEditor from '../components/RichTextEditor';
import { ThumbsUp, ThumbsDown } from 'lucide-react';

export default function QuestionDetail() {
  const { id } = useParams<{ id: string }>();
  const [question, setQuestion] = useState<Question | null>(null);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [newAnswer, setNewAnswer] = useState('');
  const [user, setUser] = useState<Profile | null>(null);

  useEffect(() => {
    loadQuestion();
    loadAnswers();
    checkUser();
  }, [id]);

  async function checkUser() {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();
      setUser(data);
    }
  }

  async function loadQuestion() {
    if (!id) return;
    
    const { data, error } = await supabase
      .from('questions')
      .select(`
        *,
        author:profiles(*)
      `)
      .eq('id', id)
      .single();

    if (error) {
      console.error('Error loading question:', error);
      return;
    }

    setQuestion(data);
  }

  async function loadAnswers() {
    if (!id) return;

    const { data, error } = await supabase
      .from('answers')
      .select(`
        *,
        author:profiles(*),
        votes(*)
      `)
      .eq('question_id', id)
      .order('created_at', { ascending: true });

    if (error) {
      console.error('Error loading answers:', error);
      return;
    }

    // Calculate vote counts
    const answersWithVotes = data.map(answer => ({
      ...answer,
      vote_count: answer.votes.reduce((acc, vote) => acc + vote.value, 0)
    }));

    setAnswers(answersWithVotes);
  }

  async function handleSubmitAnswer() {
    if (!user || !newAnswer.trim()) return;

    const { error } = await supabase
      .from('answers')
      .insert({
        content: newAnswer,
        question_id: id,
        author_id: user.id
      });

    if (error) {
      console.error('Error submitting answer:', error);
      return;
    }

    setNewAnswer('');
    loadAnswers();
  }

  async function handleVote(answerId: string, value: number) {
    if (!user) return;

    const { error } = await supabase
      .from('votes')
      .upsert({
        user_id: user.id,
        answer_id: answerId,
        value
      }, {
        onConflict: 'user_id,answer_id'
      });

    if (error) {
      console.error('Error voting:', error);
      return;
    }

    loadAnswers();
  }

  if (!question) {
    return <div className="text-center mt-8">Loading...</div>;
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-4">{question.title}</h1>
      <div className="bg-white rounded-lg p-6 shadow-sm mb-8">
        <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: question.content }} />
        <div className="mt-4 text-sm text-gray-500">
          Asked by {question.author?.username} on {new Date(question.created_at).toLocaleDateString()}
        </div>
      </div>

      <h2 className="text-2xl font-bold mb-4">{answers.length} Answers</h2>
      
      <div className="space-y-6">
        {answers.map(answer => (
          <div key={answer.id} className="bg-white rounded-lg p-6 shadow-sm">
            <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: answer.content }} />
            <div className="mt-4 flex items-center justify-between">
              <div className="text-sm text-gray-500">
                Answered by {answer.author?.username} on {new Date(answer.created_at).toLocaleDateString()}
              </div>
              <div className="flex items-center gap-4">
                <button
                  onClick={() => handleVote(answer.id, 1)}
                  className="flex items-center gap-1 text-gray-600 hover:text-blue-500"
                >
                  <ThumbsUp className="h-5 w-5" />
                </button>
                <span className="text-lg font-semibold">{answer.vote_count}</span>
                <button
                  onClick={() => handleVote(answer.id, -1)}
                  className="flex items-center gap-1 text-gray-600 hover:text-red-500"
                >
                  <ThumbsDown className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {user ? (
        <div className="mt-8">
          <h3 className="text-xl font-bold mb-4">Your Answer</h3>
          <RichTextEditor
            content={newAnswer}
            onChange={setNewAnswer}
            placeholder="Write your answer..."
          />
          <button
            onClick={handleSubmitAnswer}
            className="mt-4 bg-blue-500 text-white px-6 py-2 rounded-full hover:bg-blue-600"
          >
            Post Answer
          </button>
        </div>
      ) : (
        <div className="mt-8 text-center">
          <p>Please log in to post an answer.</p>
        </div>
      )}
    </div>
  );
}