import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/Tabs';
import type { Question, Profile, Tag } from '../lib/supabase';

type SearchResult = {
  questions: Question[];
  users: Profile[];
  tags: Tag[];
  loading: boolean;
};

export default function Search() {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const [activeTab, setActiveTab] = useState('questions');
  const [results, setResults] = useState<SearchResult>({
    questions: [],
    users: [],
    tags: [],
    loading: true,
  });

  useEffect(() => {
    if (query) {
      searchContent();
    }
  }, [query]);

  async function searchContent() {
    setResults(prev => ({ ...prev, loading: true }));

    const questionPromise = supabase
      .from('questions')
      .select(`
        *,
        author:profiles(*),
        answers(count)
      `)
      .or(`title.ilike.%${query}%,content.ilike.%${query}%`)
      .order('created_at', { ascending: false });

    const userPromise = supabase
      .from('profiles')
      .select('*')
      .or(`username.ilike.%${query}%,full_name.ilike.%${query}%`)
      .order('username');

    const tagPromise = supabase
      .from('tags')
      .select('*')
      .ilike('name', `%${query}%`)
      .order('name');

    const [questionResult, userResult, tagResult] = await Promise.all([
      questionPromise,
      userPromise,
      tagPromise,
    ]);

    setResults({
      questions: questionResult.data || [],
      users: userResult.data || [],
      tags: tagResult.data || [],
      loading: false,
    });
  }

  function QuestionCard({ question }: { question: Question }) {
    return (
      <Link to={`/question/${question.id}`}>
        <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
          <h3 className="text-xl font-semibold text-gray-900">{question.title}</h3>
          <p className="mt-2 text-gray-600">
            {question.content.substring(0, 200)}...
          </p>
          <div className="mt-4 flex items-center text-sm text-gray-500">
            <img
              src={question.author?.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${question.author?.username}`}
              alt={question.author?.username}
              className="w-6 h-6 rounded-full"
            />
            <span className="ml-2">{question.author?.username}</span>
            <span className="mx-2">•</span>
            <span>{new Date(question.created_at).toLocaleDateString()}</span>
            <span className="mx-2">•</span>
            <span>{question.answers?.length || 0} 回答</span>
          </div>
        </div>
      </Link>
    );
  }

  function UserCard({ user }: { user: Profile }) {
    return (
      <Link to={`/user/${user.username}`}>
        <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center">
            <img
              src={user.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${user.username}`}
              alt={user.username}
              className="w-12 h-12 rounded-full"
            />
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-900">{user.username}</h3>
              <p className="text-sm text-gray-600">{user.bio || '这个用户很懒，还没有写简介'}</p>
            </div>
          </div>
        </div>
      </Link>
    );
  }

  function TagCard({ tag }: { tag: Tag }) {
    return (
      <Link to={`/tag/${tag.slug}`}>
        <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
          <h3 className="text-lg font-semibold text-gray-900">#{tag.name}</h3>
          <p className="mt-2 text-sm text-gray-600">{tag.description || '暂无描述'}</p>
        </div>
      </Link>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pt-28">
      <h1 className="text-2xl font-bold mb-6">
        搜索结果: "{query}"
      </h1>

      <Tabs defaultValue={activeTab} className="w-full" onChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="questions">
            问题 ({results.questions.length})
          </TabsTrigger>
          <TabsTrigger value="users">
            用户 ({results.users.length})
          </TabsTrigger>
          <TabsTrigger value="tags">
            标签 ({results.tags.length})
          </TabsTrigger>
        </TabsList>

        {results.loading ? (
          <div className="py-8 text-center text-gray-500">搜索中...</div>
        ) : (
          <>
            <TabsContent value="questions">
              <div className="space-y-4">
                {results.questions.length === 0 ? (
                  <div className="text-center text-gray-500 py-8">
                    未找到相关问题
                  </div>
                ) : (
                  results.questions.map(question => (
                    <QuestionCard key={question.id} question={question} />
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="users">
              <div className="space-y-4">
                {results.users.length === 0 ? (
                  <div className="text-center text-gray-500 py-8">
                    未找到相关用户
                  </div>
                ) : (
                  results.users.map(user => (
                    <UserCard key={user.id} user={user} />
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="tags">
              <div className="space-y-4">
                {results.tags.length === 0 ? (
                  <div className="text-center text-gray-500 py-8">
                    未找到相关标签
                  </div>
                ) : (
                  results.tags.map(tag => (
                    <TagCard key={tag.id} tag={tag} />
                  ))
                )}
              </div>
            </TabsContent>
          </>
        )}
      </Tabs>
    </div>
  );
}