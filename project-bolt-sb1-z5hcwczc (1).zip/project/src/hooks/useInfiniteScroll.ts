import { useState, useEffect, useCallback, useRef } from 'react';

interface UseInfiniteScrollOptions {
  threshold?: number;
  rootMargin?: string;
  enabled?: boolean;
}

export function useInfiniteScroll(
  callback: () => Promise<void>,
  options: UseInfiniteScrollOptions = {}
) {
  const [isFetching, setIsFetching] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const observerRef = useRef<IntersectionObserver | null>(null);
  const targetRef = useRef<HTMLDivElement | null>(null);

  const { threshold = 0.1, rootMargin = '100px', enabled = true } = options;

  const handleObserver = useCallback(async (entries: IntersectionObserverEntry[]) => {
    const target = entries[0];
    if (target.isIntersecting && !isFetching && hasMore && enabled) {
      setIsFetching(true);
      try {
        await callback();
      } catch (error) {
        console.error('Error fetching more data:', error);
      } finally {
        setIsFetching(false);
      }
    }
  }, [callback, isFetching, hasMore, enabled]);

  useEffect(() => {
    if (!enabled) return;

    const options = {
      root: null,
      rootMargin,
      threshold,
    };

    observerRef.current = new IntersectionObserver(handleObserver, options);

    return () => {
      if (observerRef.current) {
        observerRef.current.disconnect();
      }
    };
  }, [handleObserver, rootMargin, threshold, enabled]);

  const setTarget = useCallback((element: HTMLDivElement | null) => {
    if (targetRef.current) {
      observerRef.current?.unobserve(targetRef.current);
    }
    
    targetRef.current = element;
    
    if (element && observerRef.current) {
      observerRef.current.observe(element);
    }
  }, []);

  return { isFetching, hasMore, setHasMore, setTarget };
}