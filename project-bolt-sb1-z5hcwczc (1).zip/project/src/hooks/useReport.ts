import { useState } from 'react';
import { reportContent } from '../lib/supabase';

export function useReport() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleReport(
    contentType: 'question' | 'answer',
    contentId: string,
    reason: string
  ) {
    setIsLoading(true);
    setError(null);

    try {
      const reportId = await reportContent(contentType, contentId, reason);
      if (!reportId) {
        throw new Error('Failed to submit report');
      }
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      return false;
    } finally {
      setIsLoading(false);
    }
  }

  return {
    report: handleReport,
    isLoading,
    error
  };
}