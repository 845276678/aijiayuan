import { useState } from 'react';
import { moderateContent, type ContentStatus } from '../lib/supabase';

export function useModeration() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleModeration(
    contentType: 'question' | 'answer',
    contentId: string,
    action: ContentStatus,
    reason?: string
  ) {
    setIsLoading(true);
    setError(null);

    try {
      const success = await moderateContent(contentType, contentId, action, reason);
      if (!success) {
        throw new Error('Failed to moderate content');
      }
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      return false;
    } finally {
      setIsLoading(false);
    }
  }

  return {
    moderateContent: handleModeration,
    isLoading,
    error
  };
}