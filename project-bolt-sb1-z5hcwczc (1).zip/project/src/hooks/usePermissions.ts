import { useState, useEffect } from 'react';
import { checkPermission } from '../lib/supabase';

export function usePermission(permissionName: string) {
  const [hasPermission, setHasPermission] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function checkUserPermission() {
      const result = await checkPermission(permissionName);
      setHasPermission(result);
      setLoading(false);
    }

    checkUserPermission();
  }, [permissionName]);

  return { hasPermission, loading };
}

export function usePermissions(permissionNames: string[]) {
  const [permissions, setPermissions] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function checkUserPermissions() {
      const results = await Promise.all(
        permissionNames.map(async name => ({
          [name]: await checkPermission(name)
        }))
      );
      
      setPermissions(
        results.reduce((acc, curr) => ({ ...acc, ...curr }), {})
      );
      setLoading(false);
    }

    checkUserPermissions();
  }, [permissionNames.join(',')]);

  return { permissions, loading };
}