import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate, Navigate, useLocation } from 'react-router-dom';
import { Search, Home, TrendingUp, MessageSquare, User, Shield } from 'lucide-react';
import { supabase } from './lib/supabase';
import { trackPageView } from './utils/monitoring';
import { AuthProvider } from './context/AuthContext';

// Pages
import HomePage from './pages/HomePage';
import QuestionDetail from './pages/QuestionDetail';
import AskQuestion from './pages/AskQuestion';
import Profile from './pages/Profile';
import Settings from './pages/Settings';
import NotificationBell from './components/NotificationBell';
import SearchPage from './pages/Search';
import TagPage from './pages/TagPage';
import CategoryPage from './pages/CategoryPage';
import TrendingPage from './pages/TrendingPage';
import Moderation from './pages/Moderation';
import Auth from './pages/Auth';
import Academy from './pages/Academy';
import CourseDetail from './pages/CourseDetail';
import UserCenter from './pages/UserCenter';
import AIAssistant from './pages/AIAssistant';
import IdeasPage from './pages/ideas/IdeasPage';
import NewIdeaPage from './pages/ideas/NewIdeaPage';
import EditIdeaPage from './pages/ideas/EditIdeaPage';
import NewProjectPage from './pages/ideas/NewProjectPage';
import EditProjectPage from './pages/ideas/EditProjectPage';
import IdeaDetailPage from './pages/ideas/IdeaDetailPage';
import ProjectDetailPage from './pages/ideas/ProjectDetailPage';
import AIContentPage from './pages/content/AIContentPage';
import NewsPage from './pages/news/NewsPage';
import ForumPage from './pages/ForumPage';
import ForumRules from './pages/ForumRules';
import NewPost from './pages/forum/NewPost';
import ReportPost from './pages/forum/ReportPost';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      setUser(user);
      setLoading(false);
      if (!user) {
        navigate('/auth');
      }
    });
  }, [navigate]);

  if (loading) {
    return <div>Loading...</div>;
  }

  return user ? <>{children}</> : <Navigate to="/auth" />;
}

function Navbar() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [user, setUser] = useState<Profile | null>(null);

  useEffect(() => {
    checkUser();
    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (session) {
        const { data } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single();
        setUser(data);
      } else {
        setUser(null);
      }
    });

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, []);

  async function checkUser() {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();
      setUser(data);
    }
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    navigate('/auth');
  }

  async function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  }

  return (
    <nav className="fixed top-0 w-full bg-white shadow-sm z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <MessageSquare className="h-8 w-8 text-primary-500" />
              <span className="ml-2 text-xl font-bold text-gray-800">AI家园</span>
            </Link>
          </div>
          
          <form onSubmit={handleSearch} className="flex-1 max-w-2xl mx-8">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="搜索问题、话题或用户"
                className="w-full px-4 py-2 pl-10 pr-4 rounded-full border border-gray-300 focus:outline-none focus:border-primary-500"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </form>

          <div className="flex items-center space-x-6">
            <Link to="/" className="text-gray-600 hover:text-gray-900">
              <Home className="h-5 w-5" />
            </Link>
            <Link to="/trending" className="text-gray-600 hover:text-gray-900">
              <TrendingUp className="h-5 w-5" />
            </Link>
            {user?.role && ['moderator', 'admin'].includes(user.role) && (
              <Link to="/moderation" className="text-gray-600 hover:text-gray-900">
                <Shield className="h-5 w-5" />
              </Link>
            )}
            {user && <NotificationBell />}
            {user ? (
              <>
                <Link
                  to="/ask"
                  className="bg-primary-500 text-white px-4 py-2 rounded-full hover:bg-primary-600"
                >
                  提问
                </Link>
                <div className="relative group">
                  <button className="flex items-center space-x-2">
                    <img
                      src={user.avatar_url || `https://api.dicebear.com/7.x/initials/svg?seed=${user.username}`}
                      alt={user.username}
                      className="h-8 w-8 rounded-full"
                    />
                  </button>
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 hidden group-hover:block">
                    <Link
                      to={`/user/${user.username}`}
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      个人主页
                    </Link>
                    <Link
                      to="/settings"
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      设置
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      退出登录
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <Link
                to="/auth"
                className="text-gray-600 hover:text-gray-900"
              >
                登录
              </Link>
            )}
          </div>
        </div>
        
        <div className="flex items-center space-x-8 h-12 text-gray-600">
          <Link to="/academy" className="hover:text-primary-500 hover:border-b-2 hover:border-primary-500 h-full flex items-center">AI学院</Link>
          <Link to="/forum" className="hover:text-primary-500 hover:border-b-2 hover:border-primary-500 h-full flex items-center">论坛</Link>
          <Link to="/ideas" className="hover:text-primary-500 hover:border-b-2 hover:border-primary-500 h-full flex items-center">创新想法</Link>
          <Link to="/assistant" className="hover:text-primary-500 hover:border-b-2 hover:border-primary-500 h-full flex items-center">AI助手</Link>
          <Link to="/life" className="hover:text-primary-500 hover:border-b-2 hover:border-primary-500 h-full flex items-center">人生指南</Link>
          <Link to="/content" className="hover:text-primary-500 hover:border-b-2 hover:border-primary-500 h-full flex items-center">AI内容</Link>
          <Link to="/news" className="hover:text-primary-500 hover:border-b-2 hover:border-primary-500 h-full flex items-center">AI新闻</Link>
        </div>
      </div>
    </nav>
  );
}

function AppContent() {
  const location = useLocation();
  
  useEffect(() => {
    trackPageView(location.pathname);
  }, [location]);

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/auth" element={<Auth />} />
        <Route path="/search" element={<SearchPage />} />
        <Route path="/trending" element={<TrendingPage />} />
        <Route path="/forum/post/new" element={<ProtectedRoute><NewPost /></ProtectedRoute>} />
        <Route path="/forum/post/:id/report" element={<ProtectedRoute><ReportPost /></ProtectedRoute>} />
        <Route path="/question/:id" element={<QuestionDetail />} />
        <Route path="/academy" element={<Academy />} />
        <Route path="/forum" element={<ForumPage />} />
        <Route path="/forum/rules" element={<ForumRules />} />
        <Route path="/assistant" element={<AIAssistant />} />
        <Route path="/course/:courseId" element={<CourseDetail />} />
        <Route path="/user-center" element={<UserCenter />} />
        <Route 
          path="/ask" 
          element={
            <ProtectedRoute>
              <AskQuestion />
            </ProtectedRoute>
          } 
        />
        <Route path="/user/:username" element={<Profile />} />
        <Route 
          path="/settings" 
          element={
            <ProtectedRoute>
              <Settings />
            </ProtectedRoute>
          } 
        />
        <Route path="/tag/:slug" element={<TagPage />} />
        <Route path="/category/:slug" element={<CategoryPage />} />
        <Route 
          path="/moderation" 
          element={
            <ProtectedRoute>
              <Moderation />
            </ProtectedRoute>
          } 
        />
        <Route path="/ideas" element={<IdeasPage />} />
        <Route path="/ideas/:id" element={<IdeaDetailPage />} />
        <Route path="/projects/:id" element={<ProjectDetailPage />} />
        <Route path="/content" element={<AIContentPage />} />
        <Route path="/news" element={<NewsPage />} />
        <Route 
          path="/ideas/new" 
          element={
            <ProtectedRoute>
              <NewIdeaPage />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/ideas/:id/edit" 
          element={
            <ProtectedRoute>
              <EditIdeaPage />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/projects/new" 
          element={
            <ProtectedRoute>
              <NewProjectPage />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/projects/:id/edit" 
          element={
            <ProtectedRoute>
              <EditProjectPage />
            </ProtectedRoute>
          } 
        />
      </Routes>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <AppContent />
      </Router>
    </AuthProvider>
  );
}

export default App;