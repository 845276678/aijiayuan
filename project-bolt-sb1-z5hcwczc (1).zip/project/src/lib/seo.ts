export function updateMetaTags(title: string, description?: string, keywords?: string) {
  document.title = title ? `${title} - AI家园` : 'AI家园 - 专业的人工智能技术交流社区';
  
  if (description) {
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', description);
    }
  }

  if (keywords) {
    const metaKeywords = document.querySelector('meta[name="keywords"]');
    if (metaKeywords) {
      metaKeywords.setAttribute('content', keywords);
    }
  }
}