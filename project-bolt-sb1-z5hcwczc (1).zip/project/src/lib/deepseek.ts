import { supabase } from './supabase';

const DEEPSEEK_API_KEY = 'sk-be03b6dac71247e88ceecbb18d1deb01';
const DEEPSEEK_API_URL = 'https://api.deepseek.com/v1';

export async function callDeepSeek(prompt: string, options: {
  maxTokens?: number;
  temperature?: number;
  model?: string;
} = {}) {
  const {
    maxTokens = 1000,
    temperature = 0.7,
    model = 'deepseek-chat'
  } = options;

  try {
    const response = await fetch(`${DEEPSEEK_API_URL}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${DEEPSEEK_API_KEY}`
      },
      body: JSON.stringify({
        model,
        messages: [{ role: 'user', content: prompt }],
        max_tokens: maxTokens,
        temperature
      })
    });

    if (!response.ok) {
      throw new Error(`DeepSeek API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  } catch (error) {
    console.error('Error calling DeepSeek:', error);
    throw error;
  }
}

export async function generateCode(prompt: string) {
  return callDeepSeek(prompt, {
    model: 'deepseek-coder',
    temperature: 0.3,
    maxTokens: 2000
  });
}

export async function generateContent(prompt: string) {
  return callDeepSeek(prompt, {
    model: 'deepseek-chat',
    temperature: 0.7,
    maxTokens: 1500
  });
}