export type UserRole = 'user' | 'moderator' | 'admin';
export type UserRoleType = 'judge' | 'observer' | 'executor';

export type ContentStatus = 'pending' | 'approved' | 'rejected' | 'flagged';
export type ReportStatus = 'pending' | 'resolved' | 'dismissed';

export type UserStats = {
  experience: number;
  level: number;
  role_type: UserRoleType;
};

export interface Profile {
  id: string;
  username: string;
  avatar_url: string | null;
  created_at: string;
  bio?: string;
  full_name?: string;
  user_role?: {
    role: UserRole;
  };
  stats?: UserStats;
}

export interface Question {
  id: string;
  title: string;
  content: string;
  author_id: string;
  blood_points: number;
  created_at: string;
  updated_at: string;
  author?: Profile;
  category_id?: string;
  tags?: Tag[];
  answers?: { length: number };
  excerpt?: string;
  status: ContentStatus;
  moderation_reason?: string;
  moderated_at?: string;
  moderated_by?: string;
  reports_count: number;
}

export interface Answer {
  id: string;
  content: string;
  question_id: string;
  author_id: string;
  created_at: string;
  updated_at: string;
  author?: Profile;
  votes?: Vote[];
  vote_count?: number;
  status: ContentStatus;
  moderation_reason?: string;
  moderated_at?: string;
  moderated_by?: string;
  reports_count: number;
}

export interface Tag {
  id: string;
  name: string;
  slug: string;
  description?: string;
}

export interface Vote {
  id: string;
  user_id: string;
  answer_id: string;
  value: number;
  created_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  content: string;
  type: 'answer' | 'comment' | 'vote' | 'follow';
  read: boolean;
  created_at: string;
}

export interface FollowStats {
  followers_count: number;
  following_count: number;
}

export interface ForumCategory {
  id: string;
  name: string;
  slug: string;
  description: string;
  icon: string;
  sort_order: number;
  created_at: string;
}

export interface ForumPost {
  id: string;
  title: string;
  content: string;
  category_id: string;
  author_id: string;
  status: string;
  is_pinned: boolean;
  views_count: number;
  replies_count: number;
  last_reply_at: string | null;
  created_at: string;
  updated_at: string;
  author: Profile;
  category: ForumCategory;
}

export interface ForumReply {
  id: string;
  post_id: string;
  content: string;
  author_id: string;
  parent_id: string | null;
  created_at: string;
  updated_at: string;
  author: Profile;
}

export interface ForumReaction {
  id: string;
  user_id: string;
  post_id: string | null;
  reply_id: string | null;
  reaction_type: string;
  created_at: string;
}

export interface UserGroup {
  id: string;
  name: string;
  description: string;
  avatar_url: string | null;
  created_by: string;
  is_official: boolean;
  member_count: number;
  created_at: string;
  updated_at: string;
}

export interface GroupMember {
  group_id: string;
  user_id: string;
  role: string;
  joined_at: string;
  user: Profile;
}

export interface MentorshipProgram {
  id: string;
  title: string;
  description: string;
  mentor_id: string;
  expertise: string[];
  max_mentees: number;
  duration_weeks: number;
  status: string;
  created_at: string;
  updated_at: string;
  mentor: Profile;
}

export interface MentorshipApplication {
  id: string;
  program_id: string;
  mentee_id: string;
  motivation: string;
  status: string;
  created_at: string;
  updated_at: string;
  mentee: Profile;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: string;
  points: number;
  created_at: string;
}

export interface UserAchievement {
  user_id: string;
  achievement_id: string;
  earned_at: string;
  achievement: Achievement;
}