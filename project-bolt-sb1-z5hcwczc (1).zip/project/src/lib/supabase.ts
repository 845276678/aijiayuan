import { createClient } from '@supabase/supabase-js';
import { trackError } from '../utils/monitoring';
import type { Profile, Question, Answer, Tag, Vote, Notification, FollowStats, UserRole, UserRoleType, ContentStatus } from './types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

console.log('Initializing Supabase client with:', {
  url: supabaseUrl,
  hasAnonKey: !!supabaseAnonKey
});

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  },
  global: {
    headers: {
      'x-application-name': 'ai-home',
      'x-application-version': '1.0.0'
    }
  },
  realtime: {
    params: {
      eventsPerSecond: 10
    }
  }
});

// Add error tracking to Supabase client
const originalQuery = supabase.from;
supabase.from = function(...args: Parameters<typeof originalQuery>) {
  const query = originalQuery.apply(this, args);
  const originalExecute = query.execute;
  
  query.execute = async function() {
    try {
      const result = await originalExecute.apply(this);
      if (result.error) {
        trackError(new Error(result.error.message), `Supabase query: ${args[0]}`);
      }
      return result;
    } catch (error) {
      trackError(error as Error, `Supabase query: ${args[0]}`);
      throw error;
    }
  };
  
  return query;
};

export function subscribeToNotifications(userId: string, callback: (notification: Notification) => void) {
  return supabase
    .channel('public:notifications:user_id=eq.' + userId)
    .on(
      'postgres_changes',
      { 
        event: 'INSERT', 
        schema: 'public', 
        table: 'notifications', 
        filter: 'user_id=eq.' + userId 
      },
      (payload) => {
        callback(payload.new as Notification);
      }
    )
    .subscribe();
}

export async function moderateContent(
  contentType: 'question' | 'answer',
  contentId: string,
  action: ContentStatus,
  reason?: string
): Promise<boolean> {
  const tableName = contentType === 'question' ? 'questions' : 'answers';

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return false;

  const { error: updateError } = await supabase
    .from(tableName)
    .update({
      status: action,
      moderation_reason: reason,
      moderated_at: new Date().toISOString(),
      moderated_by: user.id
    })
    .eq('id', contentId);

  if (updateError) {
    trackError(updateError, `Error moderating ${contentType}`);
    return false;
  }

  // Create moderation log
  const { error: logError } = await supabase
    .from('moderation_logs')
    .insert({
      content_type: contentType,
      content_id: contentId,
      action: action,
      reason: reason,
      moderator_id: user.id
    });

  if (logError) {
    trackError(logError, `Error creating moderation log`);
  }

  return true;
}

export async function checkPermission(permissionName: string): Promise<boolean> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return false;

  // First check user_roles
  const { data: userRole, error: roleError } = await supabase
    .from('user_roles')
    .select('role')
    .eq('user_id', user.id)
    .single();

  if (roleError) {
    trackError(roleError, 'Error fetching user role');
    return false;
  }

  if (!userRole) return false;

  // Then check role_permissions
  const { data: permissions, error: permError } = await supabase
    .from('role_permissions')
    .select('permission_id')
    .eq('role', userRole.role);

  if (permError) {
    trackError(permError, 'Error fetching role permissions');
    return false;
  }

  if (!permissions?.length) return false;

  // Finally check if the permission exists for this role
  const { data: permission, error: permNameError } = await supabase
    .from('permissions')
    .select('id')
    .eq('name', permissionName)
    .in('id', permissions.map(p => p.permission_id))
    .single();

  if (permNameError) {
    trackError(permNameError, 'Error checking permission');
    return false;
  }

  return !!permission;
}

export type { Profile, Question, Answer, Tag, Vote, Notification, FollowStats, UserRole, UserRoleType, ContentStatus };